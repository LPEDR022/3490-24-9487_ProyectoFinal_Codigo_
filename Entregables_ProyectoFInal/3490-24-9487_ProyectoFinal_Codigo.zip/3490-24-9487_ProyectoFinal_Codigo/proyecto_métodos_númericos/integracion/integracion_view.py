"""
Vista de Integración y Derivación
Métodos: Regla del Punto Medio · Regla Trapezoidal · Regla de Simpson 1/3 · Dif. Finitas
Cada método muestra solo los campos que necesita.
"""
import tkinter as tk
import customtkinter as ctk
import numpy as np
from ui.themes import get_theme
from ui.components import (
    themed_frame, section_label, primary_button, danger_button, success_button,
    IterationTable, ProcedimientoBox, ResultadoBox, ModuleBanner
)
from ui.ayuda_formulas import EJEMPLOS
from integracion.metodos import punto_medio, trapecio, simpson, diferencias_finitas
from utils.validators import parse_function, safe_float, safe_int

# Métodos de integración (comparten campos: a, b, n, valor_real)
METODOS_INT = ("Regla del Punto Medio", "Regla Trapezoidal", "Regla de Simpson 1/3")


class IntegracionView(ctk.CTkFrame):
    def __init__(self, parent, export_callback=None):
        t = get_theme()
        super().__init__(parent, fg_color=t["bg_main"], corner_radius=0)
        self.t = t
        self.export_callback = export_callback
        self._last_result = None
        self._ayuda_win = None
        self._active_entry = None
        self._build()

    # ─────────────────────────────────────────────────────────────────
    def _build(self):
        t = self.t
        ModuleBanner(self, "Integración y Derivación",
                     "Punto Medio · Trapezoidal · Simpson 1/3 · Diferencias Finitas",
                     "∫").pack(fill="x", padx=12, pady=(6, 3))

        self.scroll = ctk.CTkScrollableFrame(self, fg_color=t["bg_main"])
        self.scroll.pack(fill="both", expand=True, padx=12, pady=3)

        # ── Selector de método ──────────────────────────────────────
        mf = themed_frame(self.scroll)
        mf.pack(fill="x", pady=(0, 6))
        section_label(mf, "Método:").pack(side="left", padx=10, pady=6)
        self.method_var = ctk.StringVar(value="Regla del Punto Medio")
        for m in ["Regla del Punto Medio", "Regla Trapezoidal",
                  "Regla de Simpson 1/3", "Dif. Finitas"]:
            ctk.CTkRadioButton(
                mf, text=m, value=m, variable=self.method_var,
                text_color=t["text_primary"], fg_color=t["accent"],
                font=ctk.CTkFont(size=12),
                radiobutton_width=16, radiobutton_height=16,
                command=self._on_method_change
            ).pack(side="left", padx=8)

        # ── Ejemplos ────────────────────────────────────────────────
        ej_frame = themed_frame(self.scroll)
        ej_frame.pack(fill="x", pady=(0, 6))
        section_label(ej_frame, "📂 Ejemplos:").pack(side="left", padx=10, pady=4)
        for ej in EJEMPLOS["integracion"]:
            ctk.CTkButton(
                ej_frame, text=ej["nombre"], width=175, height=26,
                fg_color=t["bg_input"], hover_color=t["accent"],
                text_color=t["text_primary"], corner_radius=8,
                font=ctk.CTkFont(size=11),
                command=lambda e=ej: self._cargar_ejemplo(e)
            ).pack(side="left", padx=4, pady=6)

        # ── Panel de parámetros ─────────────────────────────────────
        self.pf = themed_frame(self.scroll)
        self.pf.pack(fill="x", pady=(0, 6))

        # Título dinámico del método
        self.metodo_label = ctk.CTkLabel(
            self.pf, text="Regla del Punto Medio",
            text_color=t["accent"],
            font=ctk.CTkFont(size=15, weight="bold")
        )
        self.metodo_label.pack(anchor="w", padx=14, pady=(8, 4))

        section_label(self.pf, "⚙️ Parámetros").pack(anchor="w", padx=10, pady=(0, 2))
        grid = ctk.CTkFrame(self.pf, fg_color="transparent")
        grid.pack(fill="x", padx=8, pady=(0, 4))

        # f(x) siempre visible
        fx_row = ctk.CTkFrame(grid, fg_color="transparent")
        fx_row.grid(row=0, column=0, columnspan=6, sticky="w", padx=8, pady=(4, 8))
        ctk.CTkLabel(fx_row, text="f(x) =", text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=12)).pack(side="left", padx=(0, 6))
        self.entry_fx = ctk.CTkEntry(
            fx_row, placeholder_text="ej: sin(x)  o  x**6 - x**3",
            width=310, fg_color=t["bg_input"],
            border_color=t["border"], text_color=t["text_primary"]
        )
        self.entry_fx.pack(side="left")
        self.entry_fx.insert(0, "sin(x)")
        self.entry_fx.bind("<FocusIn>", lambda e: self._set_active(self.entry_fx))
        ctk.CTkButton(
            fx_row, text="❓ Ayuda", width=78, height=30,
            fg_color=t["accent2"], hover_color=t["accent"],
            text_color="#fff", corner_radius=6, font=ctk.CTkFont(size=11),
            command=self._abrir_ayuda
        ).pack(side="left", padx=10)

        def mk(parent, lbl, ph, r, c, w=130):
            lbl_w = ctk.CTkLabel(parent, text=lbl, text_color=t["text_secondary"],
                                 font=ctk.CTkFont(size=11))
            lbl_w.grid(row=r, column=c, sticky="w", padx=8, pady=(2, 0))
            e = ctk.CTkEntry(parent, placeholder_text=ph, width=w,
                             fg_color=t["bg_input"], border_color=t["border"],
                             text_color=t["text_primary"])
            e.grid(row=r+1, column=c, sticky="w", padx=8, pady=(0, 6))
            return lbl_w, e

        # Fila integración: a · b · n · valor_real
        lbl_a,     self.entry_a     = mk(grid, "a  (límite inferior)", "0",        2, 0)
        lbl_b,     self.entry_b     = mk(grid, "b  (límite superior)", "3.14159",  2, 1)
        lbl_n,     self.entry_n     = mk(grid, "n  (rectángulos)",     "10",       2, 2)

        # Fila derivación: x₀ · h · orden
        lbl_x0,  self.entry_x0   = mk(grid, "x₀  (punto)", "1.0",   4, 0)
        lbl_hdf, self.entry_h_df = mk(grid, "h   (paso)",  "0.001", 4, 1)
        of = ctk.CTkFrame(grid, fg_color="transparent")
        of.grid(row=4, column=2, rowspan=2, padx=8, pady=4, sticky="w")
        ctk.CTkLabel(of, text="Orden de la derivada:",
                     text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=11)).pack(anchor="w")
        self.orden_var = ctk.IntVar(value=1)
        for o in [1, 2]:
            ctk.CTkRadioButton(
                of, text=f"f{''.join([chr(39)]*o)}(x)", value=o,
                variable=self.orden_var,
                text_color=t["text_primary"], fg_color=t["accent"],
                font=ctk.CTkFont(size=12),
                radiobutton_width=16, radiobutton_height=16,
            ).pack(anchor="w")
        # listas incluyendo labels para ocultar/mostrar completamente
        self._df_widgets  = [lbl_x0, self.entry_x0, lbl_hdf, self.entry_h_df, of]
        self._int_widgets = [lbl_a, self.entry_a, lbl_b, self.entry_b,
                             lbl_n, self.entry_n]

        # Botones
        btn_row = ctk.CTkFrame(self.pf, fg_color="transparent")
        btn_row.pack(anchor="w", padx=8, pady=(2, 8))
        primary_button(btn_row, "▶  Calcular",     self._calcular, width=150).pack(side="left", padx=4)
        danger_button (btn_row, "🗑  Limpiar",      self._limpiar,  width=120).pack(side="left", padx=4)
        success_button(btn_row, "📄  Exportar PDF", self._exportar, width=160).pack(side="left", padx=4)

        # ── Resultado principal ─────────────────────────────────────
        section_label(self.scroll, "✅ Resultado").pack(anchor="w", pady=(4, 1))
        self.resultado_box = ResultadoBox(self.scroll)
        self.resultado_box.pack(fill="x", pady=(0, 4))

        # ── Panel de errores (solo integración) ─────────────────────
        self.err_panel = ctk.CTkFrame(self.scroll, fg_color=t["bg_card"], corner_radius=10)
        self.err_panel.pack(fill="x", pady=(0, 6))

        err_title = ctk.CTkLabel(self.err_panel, text="📐 Análisis de Error",
                                 text_color=t["accent2"],
                                 font=ctk.CTkFont(size=13, weight="bold"))
        err_title.pack(anchor="w", padx=14, pady=(10, 6))

        err_grid = ctk.CTkFrame(self.err_panel, fg_color="transparent")
        err_grid.pack(fill="x", padx=10, pady=(0, 10))

        # Tarjetas de error
        self._ea_card  = self._mk_err_card(err_grid, "Error Absoluto",   "Ea = |x - x̂|",  "#D29922", 0)
        self._er_card  = self._mk_err_card(err_grid, "Error Relativo",   "Er = Ea / x",   "#1F6FEB", 1)
        self._ep_card  = self._mk_err_card(err_grid, "Error Porcentual", "E% = Er × 100", "#3FB950", 2)

        # ── Tabla ───────────────────────────────────────────────────
        section_label(self.scroll, "📊 Tabla de Valores").pack(anchor="w", pady=(3, 1))
        self.tabla = IterationTable(self.scroll, columns=["NO", "xi", "xi+1", "x̄", "f(x̄)", "Ai"])
        self.tabla.pack(fill="x", pady=(0, 4))

        # ── Procedimiento ───────────────────────────────────────────
        section_label(self.scroll, "🧾 Procedimiento Paso a Paso").pack(anchor="w", pady=(3, 1))
        self.proc_box = ProcedimientoBox(self.scroll)
        self.proc_box.pack(fill="x", pady=(0, 6))
        self.proc_box.configure(height=210)

        self._on_method_change()

    def _mk_err_card(self, parent, titulo, formula, color, col):
        """Crea una tarjeta de error con título, fórmula y valor."""
        t = self.t
        card = ctk.CTkFrame(parent, fg_color=t["bg_input"], corner_radius=8)
        card.grid(row=0, column=col, padx=6, pady=2, sticky="ew")
        parent.grid_columnconfigure(col, weight=1)
        ctk.CTkLabel(card, text=titulo, text_color=color,
                     font=ctk.CTkFont(size=11, weight="bold")).pack(anchor="w", padx=10, pady=(8, 0))
        ctk.CTkLabel(card, text=formula, text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=10)).pack(anchor="w", padx=10, pady=(0, 4))
        val_lbl = ctk.CTkLabel(card, text="—", text_color=color,
                               font=ctk.CTkFont(size=14, weight="bold"))
        val_lbl.pack(anchor="w", padx=10, pady=(0, 8))
        return val_lbl   # devolvemos la label del valor para actualizarla

    # ─────────────────────────────────────────────────────────────────
    def _on_method_change(self):
        m = self.method_var.get()
        nombres = {
            "Regla del Punto Medio": "Regla del Punto Medio",
            "Regla Trapezoidal":     "Regla Trapezoidal",
            "Regla de Simpson 1/3":  "Regla de Simpson 1/3",
            "Dif. Finitas":          "Diferencias Finitas",
        }
        try:
            self.metodo_label.configure(text=nombres.get(m, m))
        except Exception:
            pass

        is_df = m == "Dif. Finitas"

        # Mostrar/ocultar filas de campos según el método
        for w in self._int_widgets:
            try:
                if is_df:
                    w.grid_remove()
                    # también ocultar la label encima (row-1)
                else:
                    w.grid()
            except Exception:
                pass

        for w in self._df_widgets:
            try:
                if is_df:
                    w.grid()
                else:
                    w.grid_remove()
            except Exception:
                pass

        # Panel de errores: solo para integración
        if is_df:
            self.err_panel.pack_forget()
        else:
            self.err_panel.pack(fill="x", pady=(0, 6),
                                before=self.tabla if self.tabla.winfo_ismapped() else None)
            try:
                self.err_panel.pack(fill="x", pady=(0, 6))
            except Exception:
                pass

    # ─────────────────────────────────────────────────────────────────
    def _cargar_ejemplo(self, ej):
        self.entry_fx.delete(0, "end");   self.entry_fx.insert(0, ej.get("fx", ""))
        self.entry_a.delete(0, "end");    self.entry_a.insert(0, ej.get("a", ""))
        self.entry_b.delete(0, "end");    self.entry_b.insert(0, ej.get("b", ""))
        self.entry_n.delete(0, "end");    self.entry_n.insert(0, ej.get("n", "10"))
        self.entry_x0.delete(0, "end");   self.entry_x0.insert(0, ej.get("x0", ""))
        self.entry_h_df.delete(0, "end"); self.entry_h_df.insert(0, "0.001")
        self.orden_var.set(ej.get("orden", 1))
        self.proc_box.set_text(f"Ejemplo cargado: {ej['nombre']}\n{ej.get('desc','')}")

    def _set_active(self, e): self._active_entry = e

    def _abrir_ayuda(self):
        try:
            if self._ayuda_win is not None and self._ayuda_win.winfo_exists():
                self._ayuda_win.deiconify(); self._ayuda_win.lift(); return
        except Exception:
            pass
        m = self.method_var.get()
        self._ayuda_win = _AyudaIntegracion(self, m)
        self._ayuda_win.protocol("WM_DELETE_WINDOW", self._cerrar_ayuda)

    def _cerrar_ayuda(self):
        try:
            if self._ayuda_win: self._ayuda_win.destroy()
        except Exception:
            pass
        finally:
            self._ayuda_win = None

    # ─────────────────────────────────────────────────────────────────
    def _calcular(self):
        t = self.t
        fx_str = self.entry_fx.get().strip()
        f, _, err = parse_function(fx_str)
        if err:
            self.resultado_box.set_result(f"❌ Error en f(x): {err}", color=t["accent3"]); return

        method = self.method_var.get()
        try:
            if method in METODOS_INT:
                a = safe_float(self.entry_a.get())
                b = safe_float(self.entry_b.get())
                n = safe_int(self.entry_n.get()) or 10
                if a is None or b is None:
                    raise ValueError("Ingrese los límites a y b")

                if method == "Regla del Punto Medio":
                    result = punto_medio(f, a, b, n)
                elif method == "Regla Trapezoidal":
                    result = trapecio(f, a, b, n)
                else:
                    result = simpson(f, a, b, n)

                aprox = result["resultado"]
                self.resultado_box.set_result(
                    f"∫ f(x) dx  ≈  {aprox:.3f}"
                )

                # Errores automáticos desde scipy
                real = result.get("real")
                ea   = result.get("ea")
                er   = result.get("er")
                ep   = result.get("ep")
                if real is not None:
                    self._ea_card.configure(text=f"{ea:.3f}")
                    self._er_card.configure(text=f"{er:.3f}")
                    self._ep_card.configure(text=f"{ep:.3f} %")
                else:
                    self._ea_card.configure(text="—")
                    self._er_card.configure(text="—")
                    self._ep_card.configure(text="—")

                self.tabla.update_data(result["tabla"], new_columns=result["tabla_headers"])
                self.proc_box.set_text(result["procedimiento"])

            else:   # Diferencias Finitas
                x0    = safe_float(self.entry_x0.get())
                h_df  = safe_float(self.entry_h_df.get()) or 0.001
                orden = self.orden_var.get()
                if x0 is None:
                    raise ValueError("Ingrese x₀")
                result = diferencias_finitas(f, x0, h_df, orden)
                primes = "'" * orden
                self.resultado_box.set_result(
                    f"f{primes}({x0})  ≈  {result['resultado']:.3f}"
                )
                self.tabla.update_data(result["tabla"], new_columns=result["tabla_headers"])
                self.proc_box.set_text(result["procedimiento"])

            self._last_result = {**result, "metodo": method, "fx_str": fx_str}

        except Exception as exc:
            self.resultado_box.set_result(f"❌ Error: {exc}", color=t["accent3"])

    def _limpiar(self):
        # Limpiar salidas
        self.resultado_box.set_result("—")
        self.tabla.update_data([])
        self.proc_box.set_text("")
        self._ea_card.configure(text="—")
        self._er_card.configure(text="—")
        self._ep_card.configure(text="—")
        self._last_result = None
        # Limpiar campos de entrada
        for entry in [self.entry_fx, self.entry_a, self.entry_b,
                      self.entry_n, self.entry_x0, self.entry_h_df]:
            try: entry.delete(0, "end")
            except Exception: pass
        self.orden_var.set(1)

    def _exportar(self):
        if self._last_result is None:
            self.resultado_box.set_result("⚠️ Calcule primero", color=self.t["accent3"]); return
        if self.export_callback:
            self.export_callback(self._last_result, None, "Integracion y Derivacion")


# ─────────────────────────────────────────────────────────────────
#  Ventana de ayuda específica para integración
# ─────────────────────────────────────────────────────────────────

_AYUDA_CONTENIDO = {
    "Regla del Punto Medio": {
        "titulo": "Regla del Punto Medio",
        "formula": "∫f(x)dx ≈ Σ Δx · f(X̄i)   donde  X̄i = (Xi + Xi+1) / 2",
        "params": [
            ("f(x)", "La función a integrar.", "Ejemplos: sin(x)  |  x**2 + 1  |  exp(x)  |  x**6 - x**3"),
            ("a",    "Límite inferior del intervalo de integración.", "Ejemplo: 0"),
            ("b",    "Límite superior del intervalo de integración.", "Ejemplo: 3.14159  (para π)"),
            ("n",    "Número de rectángulos (subintervalos).", "Más rectángulos = mayor precisión.  Ejemplo: 10"),
        ],
        "nota": "El valor real exacto se calcula automáticamente.\nLos errores Ea, Er y E% se muestran al calcular."
    },
    "Regla Trapezoidal": {
        "titulo": "Regla Trapezoidal",
        "formula": "∫f(x)dx ≈ (Δx/2) [f(x₀) + 2·Σf(xᵢ) + f(xₙ)]",
        "params": [
            ("f(x)", "La función a integrar.", "Ejemplos: sin(x)  |  cos(x)  |  x**3 - 2*x"),
            ("a",    "Límite inferior del intervalo.", "Ejemplo: 0"),
            ("b",    "Límite superior del intervalo.", "Ejemplo: 3.14159"),
            ("n",    "Número de trapecios.", "Factor: 1 en extremos, 2 en puntos interiores.  Ejemplo: 10"),
        ],
        "nota": "El valor real exacto se calcula automáticamente.\nLos errores Ea, Er y E% se muestran al calcular."
    },
    "Regla de Simpson 1/3": {
        "titulo": "Regla de Simpson 1/3",
        "formula": "∫f(x)dx ≈ (Δx/3) [f(x₀) + 4·Σ(impares) + 2·Σ(pares) + f(xₙ)]",
        "params": [
            ("f(x)", "La función a integrar.", "Ejemplos: sin(x)  |  x**4  |  log(x+1)"),
            ("a",    "Límite inferior del intervalo.", "Ejemplo: 0"),
            ("b",    "Límite superior del intervalo.", "Ejemplo: 3.14159"),
            ("n",    "Número de subintervalos (debe ser par).", "Si ingresas impar, se ajusta automáticamente.  Ejemplo: 10"),
        ],
        "nota": "El valor real exacto se calcula automáticamente.\nFactores: 1 extremos · 4 impares · 2 pares."
    },
    "Dif. Finitas": {
        "titulo": "Diferencias Finitas",
        "formula": "f'(x)  ≈ [f(x+h) - f(x-h)] / (2h)\nf''(x) ≈ [f(x+h) - 2f(x) + f(x-h)] / h²",
        "params": [
            ("f(x)", "La función a derivar.", "Ejemplos: sin(x)  |  x**3  |  exp(x)"),
            ("x₀",  "Punto donde se evalúa la derivada.", "Ejemplo: 1.0"),
            ("h",   "Paso (tamaño del incremento).", "Valores pequeños = mayor precisión.  Ejemplo: 0.001"),
            ("Orden", "Orden de la derivada.", "1 = primera derivada f'(x)\n2 = segunda derivada f''(x)"),
        ],
        "nota": "Usa diferencias centradas de orden 2.\nNo calcula errores (no aplica valor real exacto)."
    },
}


class _AyudaIntegracion(ctk.CTkToplevel):
    def __init__(self, parent, metodo):
        super().__init__(parent)
        t = get_theme()
        info = _AYUDA_CONTENIDO.get(metodo, _AYUDA_CONTENIDO["Regla del Punto Medio"])
        self.title(f"Ayuda — {info['titulo']}")
        self.geometry("560x480")
        self.resizable(False, False)
        self.configure(fg_color=t["bg_main"])
        self.lift(); self.focus_force()

        # Título
        ctk.CTkLabel(self, text=f"❓  {info['titulo']}",
                     text_color=t["accent"],
                     font=ctk.CTkFont(size=15, weight="bold")
                     ).pack(anchor="w", padx=20, pady=(16, 4))

        # Fórmula
        ctk.CTkLabel(self, text="Fórmula:", text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=11, weight="bold")).pack(anchor="w", padx=20, pady=(6, 0))
        ctk.CTkLabel(self, text=info["formula"],
                     text_color=t["accent2"],
                     font=ctk.CTkFont(family="Courier", size=12),
                     justify="left").pack(anchor="w", padx=30, pady=(2, 10))

        # Parámetros
        ctk.CTkLabel(self, text="Parámetros:", text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=11, weight="bold")).pack(anchor="w", padx=20, pady=(0, 4))

        scroll = ctk.CTkScrollableFrame(self, fg_color=t["bg_card"], corner_radius=8, height=240)
        scroll.pack(fill="x", padx=20, pady=(0, 8))

        for nombre, desc, ejemplo in info["params"]:
            row = ctk.CTkFrame(scroll, fg_color=t["bg_input"], corner_radius=6)
            row.pack(fill="x", padx=6, pady=4)
            ctk.CTkLabel(row, text=nombre, text_color=t["accent"],
                         font=ctk.CTkFont(size=12, weight="bold"), width=70,
                         anchor="w").grid(row=0, column=0, padx=(10, 6), pady=(8, 0), sticky="w")
            ctk.CTkLabel(row, text=desc, text_color=t["text_primary"],
                         font=ctk.CTkFont(size=11), anchor="w",
                         justify="left").grid(row=0, column=1, padx=4, pady=(8, 0), sticky="w")
            ctk.CTkLabel(row, text=ejemplo, text_color=t["text_secondary"],
                         font=ctk.CTkFont(size=10), anchor="w",
                         justify="left").grid(row=1, column=0, columnspan=2, padx=10, pady=(0, 8), sticky="w")

        # Nota
        ctk.CTkLabel(self, text=info["nota"],
                     text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=10),
                     justify="left").pack(anchor="w", padx=20, pady=(0, 8))

        ctk.CTkButton(self, text="Cerrar", width=100, fg_color=t["accent"],
                      command=self.destroy).pack(pady=(0, 16))
