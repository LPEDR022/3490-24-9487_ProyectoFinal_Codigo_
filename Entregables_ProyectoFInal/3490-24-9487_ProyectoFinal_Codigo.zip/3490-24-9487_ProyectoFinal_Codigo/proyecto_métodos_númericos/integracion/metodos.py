import numpy as np
from scipy import integrate as sci_int


def _valor_real(f, a, b):
    """Calcula valor real exacto con scipy (error < 1e-10)."""
    try:
        val, _ = sci_int.quad(f, a, b)
        return float(val)
    except Exception:
        return None


def _errores_proc(aprox, real):
    """Retorna líneas de procedimiento para errores y los valores."""
    if real is None:
        return ["  (No se pudo calcular el valor real)"], None, None, None
    ea = abs(real - aprox)
    er = ea / abs(real) if real != 0 else float("inf")
    ep = er * 100
    lines = [
        "",
        "─" * 50,
        "  VALOR REAL EXACTO",
        "─" * 50,
        f"  Se calcula integrando analíticamente f(x) de ['{a}'] a ['{b}']:",
        f"  Valor real  x   = {real:.3f}",
        f"  Valor aprox x̂  = {aprox:.3f}",
        "",
        f"  Error absoluto   Ea = |x - x̂| = |{real:.3f} - {aprox:.3f}| = {ea:.3f}",
        f"  Error relativo   Er = Ea / x   = {ea:.3f} / {real:.3f} = {er:.3f}",
        f"  Error porcentual E% = Er × 100 = {ep:.3f} %",
    ]
    return lines, ea, er, ep


def punto_medio(f, a, b, n):
    h = (b - a) / n
    xs_izq = np.array([a + i * h     for i in range(n)])
    xs_der = np.array([a + (i+1) * h for i in range(n)])
    xs_med = (xs_izq + xs_der) / 2
    fxm    = np.array([f(xm) for xm in xs_med])
    Ai     = h * fxm
    resultado = float(np.sum(Ai))
    real = _valor_real(f, a, b)

    tabla = [[i+1, round(float(xs_izq[i]),3), round(float(xs_der[i]),3),
              round(float(xs_med[i]),3), round(float(fxm[i]),3), round(float(Ai[i]),3)]
             for i in range(n)]

    err_lines, ea, er, ep = _errores_proc(resultado, real)
    # reemplazar placeholders
    err_lines = [l.replace("{a}", str(a)).replace("{b}", str(b)) for l in err_lines]

    proc = ["="*64, "REGLA DEL PUNTO MEDIO", "="*64,
            f"\n  Fórmula:  Ai = Δx · f(X̄i)   |   X̄i = (Xi + Xi+1) / 2",
            f"            ∫f(x)dx ≈ Σ Ai\n",
            f"  Datos:    a = {a}   b = {b}   n = {n} rectángulos",
            f"            Δx = ({b} - {a}) / {n} = {h:.3f}\n",
            f"{'NO':>4}  {'Xi':>7}  {'Xi+1':>7}  {'X̄':>7}  {'f(X̄)':>8}  {'Ai':>8}",
            "-"*50]
    for row in tabla:
        proc.append(f"{row[0]:>4}  {row[1]:>7.3f}  {row[2]:>7.3f}  {row[3]:>7.3f}  {row[4]:>8.3f}  {row[5]:>8.3f}")
    proc += ["-"*50, f"{'TOTAL':>44}  {resultado:>8.3f}"]
    proc += err_lines
    proc.append("="*64)

    return {"resultado": resultado, "real": real, "ea": ea, "er": er, "ep": ep,
            "xs": xs_med, "ys": fxm, "h": h,
            "tabla_headers": ["NO","Xi","Xi+1","X\u0305","f(X\u0305)","Ai"],
            "tabla": tabla, "procedimiento": "\n".join(proc)}


def trapecio(f, a, b, n):
    h = (b - a) / n
    xs = np.linspace(a, b, n+1)
    ys = np.array([f(xi) for xi in xs])
    factores = np.full(n+1, 2); factores[0] = 1; factores[-1] = 1
    contrib  = (h/2) * factores * ys
    resultado = float(np.sum(contrib))
    real = _valor_real(f, a, b)

    tabla = [[i, round(h,3), round(float(xs[i]),3), round(float(ys[i]),3),
              int(factores[i]), round(float(contrib[i]),3)]
             for i in range(n+1)]

    err_lines, ea, er, ep = _errores_proc(resultado, real)
    err_lines = [l.replace("{a}", str(a)).replace("{b}", str(b)) for l in err_lines]

    proc = ["="*64, "REGLA TRAPEZOIDAL", "="*64,
            f"\n  Fórmula:  ∫f(x)dx ≈ (Δx/2)[f(x₀) + 2·Σf(xᵢ) + f(xₙ)]\n",
            f"  Datos:    a = {a}   b = {b}   n = {n} rectángulos",
            f"            Δx = ({b} - {a}) / {n} = {h:.3f}\n",
            f"{'NO':>4}  {'Δx':>6}  {'Xi':>7}  {'f(Xi)':>8}  {'Factor':>6}  {'(Δx/2)·f(Xi)':>13}",
            "-"*55]
    for row in tabla:
        proc.append(f"{row[0]:>4}  {row[1]:>6.3f}  {row[2]:>7.3f}  {row[3]:>8.3f}  {row[4]:>6}  {row[5]:>13.3f}")
    proc += ["-"*55, f"{'TOTAL':>48}  {resultado:>8.3f}"]
    proc += err_lines
    proc.append("="*64)

    return {"resultado": resultado, "real": real, "ea": ea, "er": er, "ep": ep,
            "xs": xs, "ys": ys, "h": h,
            "tabla_headers": ["NO","Δx","Xi","f(Xi)","Factor","(Δx/2)·f(Xi)"],
            "tabla": tabla, "procedimiento": "\n".join(proc)}


def simpson(f, a, b, n):
    if n % 2 != 0: n += 1
    h = (b - a) / n
    xs = np.linspace(a, b, n+1)
    ys = np.array([f(xi) for xi in xs])
    factores = np.full(n+1, 2); factores[0] = 1; factores[-1] = 1
    for i in range(1, n, 2): factores[i] = 4
    contrib  = (h/3) * factores * ys
    resultado = float(np.sum(contrib))
    real = _valor_real(f, a, b)

    tabla = [[i, round(h,3), round(float(xs[i]),3), round(float(ys[i]),3),
              int(factores[i]), round(float(contrib[i]),3)]
             for i in range(n+1)]

    err_lines, ea, er, ep = _errores_proc(resultado, real)
    err_lines = [l.replace("{a}", str(a)).replace("{b}", str(b)) for l in err_lines]

    proc = ["="*64, "REGLA DE SIMPSON 1/3", "="*64,
            f"\n  Fórmula:  ∫f(x)dx ≈ (Δx/3)[f(x₀) + 4·Σ(imp.) + 2·Σ(par) + f(xₙ)]\n",
            f"  Datos:    a = {a}   b = {b}   n = {n} (par)",
            f"            Δx = ({b} - {a}) / {n} = {h:.3f}\n",
            f"{'NO':>4}  {'Δx':>6}  {'Xi':>7}  {'f(Xi)':>8}  {'Factor':>6}  {'(Δx/3)·f(Xi)':>13}",
            "-"*55]
    for row in tabla:
        proc.append(f"{row[0]:>4}  {row[1]:>6.3f}  {row[2]:>7.3f}  {row[3]:>8.3f}  {row[4]:>6}  {row[5]:>13.3f}")
    proc += ["-"*55, f"{'TOTAL':>48}  {resultado:>8.3f}"]
    proc += err_lines
    proc.append("="*64)

    return {"resultado": resultado, "real": real, "ea": ea, "er": er, "ep": ep,
            "xs": xs, "ys": ys, "h": h,
            "tabla_headers": ["NO","Δx","Xi","f(Xi)","Factor","(Δx/3)·f(Xi)"],
            "tabla": tabla, "procedimiento": "\n".join(proc)}


def diferencias_finitas(f, x0, h=0.001, orden=1):
    proc = ["="*60, "DIFERENCIAS FINITAS", "="*60]
    if orden == 1:
        resultado = (f(x0+h) - f(x0-h)) / (2*h)
        proc += [f"\n  Fórmula:  f'(x) ≈ [f(x+h) - f(x-h)] / (2h)",
                 f"  Parámetros:  x₀ = {x0},  h = {h}\n",
                 f"  f(x₀+h) = f({x0+h:.3f}) = {f(x0+h):.3f}",
                 f"  f(x₀-h) = f({x0-h:.3f}) = {f(x0-h):.3f}",
                 f"\n  f'({x0}) ≈ ({f(x0+h):.3f} - {f(x0-h):.3f}) / (2·{h}) = {resultado:.3f}"]
    else:
        resultado = (f(x0+h) - 2*f(x0) + f(x0-h)) / (h**2)
        proc += [f"\n  Fórmula:  f''(x) ≈ [f(x+h) - 2f(x) + f(x-h)] / h²",
                 f"  Parámetros:  x₀ = {x0},  h = {h}\n",
                 f"  f(x₀+h) = f({x0+h:.3f}) = {f(x0+h):.3f}",
                 f"  f(x₀)   = f({x0:.3f}) = {f(x0):.3f}",
                 f"  f(x₀-h) = f({x0-h:.3f}) = {f(x0-h):.3f}",
                 f"\n  f''({x0}) ≈ {resultado:.3f}"]
    primes = "'"*orden
    proc += [f"\n{'='*60}", f"RESULTADO:  f{primes}({x0}) ≈ {resultado:.3f}", "="*60]
    tabla = [[round(xi,3), round(f(xi),3)] for xi in [x0-h, x0, x0+h]]
    return {"resultado": resultado, "orden": orden, "real": None, "ea": None, "er": None, "ep": None,
            "tabla_headers": ["x","f(x)"], "tabla": tabla, "procedimiento": "\n".join(proc)}
