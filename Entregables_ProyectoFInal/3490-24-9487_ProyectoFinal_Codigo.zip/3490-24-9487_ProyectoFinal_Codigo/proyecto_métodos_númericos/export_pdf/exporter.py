"""
Exportador de resultados a PDF usando ReportLab
100% compatible con caracteres especiales y sin emojis problemáticos
"""
import os
import io
import re
import datetime
import numpy as np

from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    HRFlowable, PageBreak, Image, KeepTogether
)
from reportlab.platypus.flowables import Flowable


# ── Limpieza de texto ────────────────────────────────────────────────────────

def _clean(text: str) -> str:
    """Elimina emojis y caracteres no ASCII para PDF."""
    # Reemplazar emojis comunes usados en la app
    replacements = {
        "📥": "", "✅": "[OK]", "📊": "", "🧾": "",
        "📉": "", "🎓": "", "⚠️": "[!]", "❌": "[X]",
        "▶": ">", "✔": "[OK]", "🔢": "", "📈": "",
        "🧩": "", "∫": "INT", "⚖️": "", "📌": "",
        "📋": "", "▶️": ">", "⚙️": "", "📄": "",
        "🗑": "", "🌙": "", "☀️": "", "🎨": "",
        "📂": "", "❓": "?", "👤": "", "🧮": "",
        "📐": "",
    }
    for emoji, rep in replacements.items():
        text = text.replace(emoji, rep)
    # Eliminar cualquier caracter fuera de Latin-1
    text = re.sub(r'[^\x00-\xFF]', '', text)
    return text.strip()


# ── Colores ──────────────────────────────────────────────────────────────────

AZUL       = colors.HexColor("#1F6FEB")
AZUL_CLARO = colors.HexColor("#DCF0FF")
VERDE      = colors.HexColor("#2EA043")
VERDE_CLR  = colors.HexColor("#E6F4EA")
MORADO     = colors.HexColor("#7B2FBE")
ROJO       = colors.HexColor("#B84040")
GRIS       = colors.HexColor("#555555")
GRIS_CLR   = colors.HexColor("#F6F8FA")
BLANCO     = colors.white
NEGRO      = colors.black

PAGE_W, PAGE_H = A4


# ── Estilos ──────────────────────────────────────────────────────────────────

def _get_styles():
    base = getSampleStyleSheet()
    styles = {}

    styles["titulo"] = ParagraphStyle(
        "titulo", parent=base["Normal"],
        fontName="Helvetica-Bold", fontSize=15,
        textColor=AZUL, spaceAfter=4
    )
    styles["subtitulo"] = ParagraphStyle(
        "subtitulo", parent=base["Normal"],
        fontName="Helvetica", fontSize=10,
        textColor=GRIS, spaceAfter=10
    )
    styles["seccion"] = ParagraphStyle(
        "seccion", parent=base["Normal"],
        fontName="Helvetica-Bold", fontSize=11,
        textColor=BLANCO, spaceAfter=4,
        backColor=AZUL, leftIndent=6, rightIndent=6,
        borderPad=4
    )
    styles["body"] = ParagraphStyle(
        "body", parent=base["Normal"],
        fontName="Helvetica", fontSize=10,
        textColor=NEGRO, spaceAfter=4
    )
    styles["resultado"] = ParagraphStyle(
        "resultado", parent=base["Normal"],
        fontName="Helvetica-Bold", fontSize=12,
        textColor=AZUL, backColor=AZUL_CLARO,
        borderColor=AZUL, borderWidth=1,
        borderPad=8, spaceAfter=6
    )
    styles["code"] = ParagraphStyle(
        "code", parent=base["Normal"],
        fontName="Courier", fontSize=8.5,
        textColor=NEGRO, backColor=GRIS_CLR,
        spaceAfter=2, leftIndent=4
    )
    styles["footer"] = ParagraphStyle(
        "footer", parent=base["Normal"],
        fontName="Helvetica-Oblique", fontSize=8,
        textColor=GRIS, alignment=TA_CENTER
    )
    return styles


def _section_block(title: str, color=AZUL):
    """Retorna una tabla de 1 celda que simula un header de sección coloreado."""
    return Table(
        [[Paragraph(_clean(title), ParagraphStyle(
            "sh", fontName="Helvetica-Bold", fontSize=11,
            textColor=BLANCO))]],
        colWidths=[17.5 * cm],
        style=TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), color),
            ("TOPPADDING",    (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("LEFTPADDING",   (0, 0), (-1, -1), 10),
        ])
    )


# ── Header / Footer callbacks ─────────────────────────────────────────────────

class _HeaderFooter:
    def __init__(self, modulo, dev1, dev2):
        self.modulo = _clean(modulo)
        self.dev1   = _clean(dev1)
        self.dev2   = _clean(dev2)

    def __call__(self, canvas, doc):
        canvas.saveState()
        W = PAGE_W

        # Header
        canvas.setFillColor(AZUL)
        canvas.rect(0, PAGE_H - 48, W, 48, fill=True, stroke=False)
        canvas.setFillColor(BLANCO)
        canvas.setFont("Helvetica-Bold", 14)
        canvas.drawString(18, PAGE_H - 22, "Metodos Numericos con Python")
        canvas.setFont("Helvetica", 9)
        canvas.drawString(18, PAGE_H - 36, self.modulo)

        # Footer
        canvas.setFillColor(colors.HexColor("#EEF2F7"))
        canvas.rect(0, 0, W, 28, fill=True, stroke=False)
        canvas.setFillColor(GRIS)
        canvas.setFont("Helvetica-Oblique", 8)
        date_str = datetime.datetime.now().strftime("%d/%m/%Y %H:%M")
        footer_text = (
            f"Universidad Mariano Galvez  |  {self.dev1} y {self.dev2}"
            f"  |  {date_str}  |  Pagina {doc.page}"
        )
        canvas.drawCentredString(W / 2, 10, footer_text)
        canvas.restoreState()


# ── Exportar ─────────────────────────────────────────────────────────────────

def exportar_pdf(
    metodo: str,
    datos_entrada: dict,
    resultado_str: str,
    tabla_headers: list,
    tabla_rows: list,
    procedimiento: str,
    fig=None,
    nombre_archivo: str = "resultado.pdf",
    desarrolladores: tuple = ("___________________", "___________________"),
):
    st = _get_styles()
    d1, d2 = desarrolladores
    hf = _HeaderFooter(metodo, d1, d2)

    doc = SimpleDocTemplate(
        nombre_archivo,
        pagesize=A4,
        leftMargin=2*cm, rightMargin=2*cm,
        topMargin=3.2*cm, bottomMargin=2.2*cm,
    )

    story = []

    # ── Título ──────────────────────────────────────────────────────────────
    story.append(Paragraph(_clean(metodo), st["titulo"]))
    story.append(Paragraph("Metodos Numericos con Python – Universidad Mariano Galvez",
                           st["subtitulo"]))
    story.append(HRFlowable(width="100%", thickness=1, color=AZUL, spaceAfter=8))

    # ── Datos de entrada ─────────────────────────────────────────────────────
    story.append(_section_block("DATOS DE ENTRADA", VERDE))
    story.append(Spacer(1, 4))
    for key, val in datos_entrada.items():
        story.append(Paragraph(f"<b>{_clean(str(key))}:</b>  {_clean(str(val))}",
                               st["body"]))
    story.append(Spacer(1, 8))

    # ── Resultado ────────────────────────────────────────────────────────────
    story.append(_section_block("RESULTADO FINAL", AZUL))
    story.append(Spacer(1, 4))
    res_para = Paragraph(f">> {_clean(resultado_str)}", st["resultado"])
    story.append(res_para)
    story.append(Spacer(1, 10))

    # ── Tabla ────────────────────────────────────────────────────────────────
    if tabla_headers and tabla_rows:
        story.append(_section_block("TABLA DE ITERACIONES / VALORES", MORADO))
        story.append(Spacer(1, 4))

        n_cols = len(tabla_headers)
        col_w = (17.0 / n_cols) * cm

        # Cabecera
        data = [[_clean(str(h)) for h in tabla_headers]]
        for row in tabla_rows[:80]:
            r = []
            for cell in row:
                if isinstance(cell, float):
                    r.append(f"{cell:.6g}")
                elif isinstance(cell, (int, np.integer)):
                    r.append(str(cell))
                else:
                    r.append(_clean(str(cell))[:20])
            data.append(r)

        tbl = Table(data, colWidths=[col_w] * n_cols, repeatRows=1)
        tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0, 0),  (-1, 0),  AZUL),
            ("TEXTCOLOR",     (0, 0),  (-1, 0),  BLANCO),
            ("FONTNAME",      (0, 0),  (-1, 0),  "Helvetica-Bold"),
            ("FONTSIZE",      (0, 0),  (-1, 0),  9),
            ("FONTSIZE",      (0, 1),  (-1, -1), 8),
            ("FONTNAME",      (0, 1),  (-1, -1), "Helvetica"),
            ("ROWBACKGROUNDS",(0, 1),  (-1, -1), [colors.HexColor("#EEF5FF"), BLANCO]),
            ("GRID",          (0, 0),  (-1, -1), 0.4, colors.HexColor("#CCCCCC")),
            ("ALIGN",         (0, 0),  (-1, -1), "CENTER"),
            ("TOPPADDING",    (0, 0),  (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0),  (-1, -1), 4),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 10))

    # ── Procedimiento ─────────────────────────────────────────────────────────
    if procedimiento:
        story.append(_section_block("PROCEDIMIENTO PASO A PASO", ROJO))
        story.append(Spacer(1, 4))
        for line in procedimiento.split("\n"):
            safe = _clean(line)
            if len(safe) > 130:
                safe = safe[:127] + "..."
            story.append(Paragraph(safe or " ", st["code"]))
        story.append(Spacer(1, 10))

    # ── Gráfica ───────────────────────────────────────────────────────────────
    if fig is not None:
        story.append(PageBreak())
        story.append(_section_block("GRAFICA", AZUL))
        story.append(Spacer(1, 8))
        try:
            buf = io.BytesIO()
            fig.savefig(buf, format="png", dpi=130, bbox_inches="tight",
                        facecolor=fig.get_facecolor())
            buf.seek(0)
            img = Image(buf, width=16*cm, height=9*cm)
            story.append(img)
        except Exception as e:
            story.append(Paragraph(f"No se pudo insertar la grafica: {e}", st["body"]))
        story.append(Spacer(1, 10))

    # ── Info institucional ────────────────────────────────────────────────────
    story.append(PageBreak())
    story.append(_section_block("INFORMACION INSTITUCIONAL", GRIS))
    story.append(Spacer(1, 6))
    story.append(Paragraph("<b>Universidad Mariano Galvez</b>", st["body"]))
    story.append(Paragraph(f"Desarrollado por: {_clean(d1)}  y  {_clean(d2)}", st["body"]))
    story.append(Paragraph(
        f"Fecha: {datetime.datetime.now().strftime('%d/%m/%Y %H:%M')}", st["body"]))
    story.append(Paragraph("Curso: Metodos Numericos", st["body"]))
    story.append(Paragraph(f"Metodo utilizado: {_clean(metodo)}", st["body"]))

    doc.build(story, onFirstPage=hf, onLaterPages=hf)
    return nombre_archivo
