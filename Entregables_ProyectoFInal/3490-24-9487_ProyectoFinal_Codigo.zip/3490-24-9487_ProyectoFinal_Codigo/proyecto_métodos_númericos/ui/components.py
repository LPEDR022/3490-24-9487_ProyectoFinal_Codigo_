"""
Componentes reutilizables de la UI
"""
import tkinter as tk
import customtkinter as ctk
from ui.themes import get_theme
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
import numpy as np


# ─────────────────────────────────────────────
#  HELPERS
# ─────────────────────────────────────────────

def themed_frame(parent, **kwargs):
    t = get_theme()
    kwargs.setdefault("fg_color", t["bg_card"])
    kwargs.setdefault("corner_radius", 12)
    return ctk.CTkFrame(parent, **kwargs)


def section_label(parent, text, **kwargs):
    """Etiqueta de seccion con tipografia consistente en todos los modulos."""
    t = get_theme()
    kwargs.setdefault("text_color", t["text_accent"])
    kwargs.setdefault("font", ctk.CTkFont(size=12, weight="bold"))
    kwargs.setdefault("anchor", "w")
    return ctk.CTkLabel(parent, text=text, **kwargs)


def body_label(parent, text, **kwargs):
    t = get_theme()
    kwargs.setdefault("text_color", t["text_primary"])
    kwargs.setdefault("font", ctk.CTkFont(size=13))
    return ctk.CTkLabel(parent, text=text, **kwargs)


def primary_button(parent, text, command, width=150, **kwargs):
    t = get_theme()
    kwargs.setdefault("fg_color", t["btn_primary"])
    kwargs.setdefault("hover_color", t["btn_primary_hover"])
    kwargs.setdefault("text_color", "#FFFFFF")
    kwargs.setdefault("corner_radius", 7)
    kwargs.setdefault("font", ctk.CTkFont(size=12, weight="bold"))
    kwargs.setdefault("height", 32)
    return ctk.CTkButton(parent, text=text, command=command, width=width, **kwargs)


def danger_button(parent, text, command, width=120, **kwargs):
    t = get_theme()
    kwargs.setdefault("fg_color", t["btn_danger"])
    kwargs.setdefault("hover_color", "#FF6B6B")
    kwargs.setdefault("text_color", "#FFFFFF")
    kwargs.setdefault("corner_radius", 7)
    kwargs.setdefault("font", ctk.CTkFont(size=12, weight="bold"))
    kwargs.setdefault("height", 32)
    return ctk.CTkButton(parent, text=text, command=command, width=width, **kwargs)


def success_button(parent, text, command, width=150, **kwargs):
    t = get_theme()
    kwargs.setdefault("fg_color", t["btn_success"])
    kwargs.setdefault("hover_color", "#26A65B")
    kwargs.setdefault("text_color", "#FFFFFF")
    kwargs.setdefault("corner_radius", 7)
    kwargs.setdefault("font", ctk.CTkFont(size=12, weight="bold"))
    kwargs.setdefault("height", 32)
    return ctk.CTkButton(parent, text=text, command=command, width=width, **kwargs)


def warning_button(parent, text, command, width=130, **kwargs):
    t = get_theme()
    kwargs.setdefault("fg_color", t["btn_warning"])
    kwargs.setdefault("hover_color", "#E6A817")
    kwargs.setdefault("text_color", "#FFFFFF")
    kwargs.setdefault("corner_radius", 7)
    kwargs.setdefault("font", ctk.CTkFont(size=12, weight="bold"))
    kwargs.setdefault("height", 32)
    return ctk.CTkButton(parent, text=text, command=command, width=width, **kwargs)


def labeled_entry(parent, label_text, placeholder="", width=220, row=0, col=0, padx=8, pady=6):
    t = get_theme()
    lbl = ctk.CTkLabel(parent, text=label_text,
                       text_color=t["text_secondary"],
                       font=ctk.CTkFont(size=12))
    lbl.grid(row=row, column=col, sticky="w", padx=padx, pady=(pady, 0))
    ent = ctk.CTkEntry(parent, placeholder_text=placeholder, width=width,
                       fg_color=t["bg_input"], border_color=t["border"],
                       text_color=t["text_primary"], corner_radius=8)
    ent.grid(row=row + 1, column=col, sticky="w", padx=padx, pady=(0, pady))
    return ent


# ─────────────────────────────────────────────
#  TABLA DE ITERACIONES
# ─────────────────────────────────────────────

class IterationTable(ctk.CTkFrame):
    """
    Tabla con scrollbar para mostrar iteraciones.
    columns: list[str]  → cabeceras
    rows   : list[list] → filas
    """
    def __init__(self, parent, columns, rows=None, **kwargs):
        t = get_theme()
        kwargs.setdefault("fg_color", t["bg_card"])
        kwargs.setdefault("corner_radius", 10)
        super().__init__(parent, **kwargs)
        self.t = t
        self.columns = columns
        self._build(rows or [])

    def _build(self, rows):
        t = self.t
        n_cols = max(len(self.columns), 1)
        n_rows = len(rows)

        # Calcular altura dinamica: header(34) + filas(26 c/u) + padding(12)
        # Minimo 60 (solo header), maximo 260 (scroll activo sobre eso)
        dynamic_h = min(260, max(60, 34 + n_rows * 26 + 12))
        self.configure(height=dynamic_h)

        # Scrollable solo si hay muchas filas
        self.scrollable = ctk.CTkScrollableFrame(
            self, fg_color=t["bg_card"], corner_radius=6,
            scrollbar_button_color=t["border"],
            scrollbar_button_hover_color=t["accent"],
        )
        self.scrollable.pack(fill="both", expand=True, padx=3, pady=3)

        # Ancho de columnas: usa todo el espacio disponible proporcionalmente
        col_width = max(88, int(550 / n_cols))

        # Header con borde definido y padding interno
        for ci, col in enumerate(self.columns):
            h = ctk.CTkLabel(
                self.scrollable, text=col,
                fg_color=t["bg_table_head"],
                text_color="#FFFFFF",
                font=ctk.CTkFont(size=11, weight="bold"),
                width=col_width, height=30, corner_radius=4,
                anchor="center",
            )
            h.grid(row=0, column=ci, padx=1, pady=(0, 2), sticky="nsew")

        # Filas con padding interno, fuente adecuada y alineacion centrada
        for ri, row in enumerate(rows):
            bg = t["bg_table_even"] if ri % 2 == 0 else t["bg_table_odd"]
            for ci, val in enumerate(row):
                if isinstance(val, float):
                    display = f"{val:.6g}"
                elif val == "—" or val == "":
                    display = "—"
                else:
                    display = str(val)
                c = ctk.CTkLabel(
                    self.scrollable,
                    text=display,
                    fg_color=bg, text_color=t["text_primary"],
                    font=ctk.CTkFont(size=11),
                    width=col_width, height=25,
                    corner_radius=3,
                    anchor="center",
                )
                c.grid(row=ri + 1, column=ci, padx=1, pady=1, sticky="nsew")

    def update_data(self, rows, new_columns=None):
        """
        Actualiza filas y (opcionalmente) columnas.
        Redimensiona la tabla automaticamente segun la cantidad de datos.
        """
        if new_columns is not None:
            self.columns = new_columns
        # Destruir widgets internos y reconstruir con nueva altura dinamica
        for w in self.scrollable.winfo_children():
            w.destroy()
        self.scrollable.pack_forget()
        self.scrollable.destroy()
        self._build(rows)


# ─────────────────────────────────────────────
#  CAJA DE PROCEDIMIENTO
# ─────────────────────────────────────────────

class ProcedimientoBox(ctk.CTkFrame):
    def __init__(self, parent, **kwargs):
        t = get_theme()
        kwargs.setdefault("fg_color", t["bg_card"])
        kwargs.setdefault("corner_radius", 10)
        super().__init__(parent, **kwargs)
        self.t = t
        header = ctk.CTkLabel(self, text="📋 Procedimiento Paso a Paso",
                              text_color=t["accent2"],
                              font=ctk.CTkFont(size=14, weight="bold"))
        header.pack(anchor="w", padx=12, pady=(10, 4))
        self.text_box = ctk.CTkTextbox(self, fg_color=t["bg_input"],
                                       text_color=t["text_primary"],
                                       border_color=t["border"],
                                       font=ctk.CTkFont(family="Courier", size=12),
                                       corner_radius=8, wrap="word")
        self.text_box.pack(fill="both", expand=True, padx=10, pady=(0, 10))

    def set_text(self, text: str):
        self.text_box.configure(state="normal")
        self.text_box.delete("0.0", "end")
        self.text_box.insert("0.0", text)
        self.text_box.configure(state="disabled")


# ─────────────────────────────────────────────
#  CAJA DE RESULTADO
# ─────────────────────────────────────────────

class ResultadoBox(ctk.CTkFrame):
    def __init__(self, parent, **kwargs):
        t = get_theme()
        kwargs.setdefault("fg_color", t["bg_card"])
        kwargs.setdefault("corner_radius", 8)
        super().__init__(parent, **kwargs)
        self.t = t

        inner = ctk.CTkFrame(self, fg_color="transparent")
        inner.pack(fill="x", padx=12, pady=8)

        # Indicador visual izquierdo
        self._dot = ctk.CTkLabel(inner, text="●", width=16,
                                  font=ctk.CTkFont(size=14),
                                  text_color=t["accent"])
        self._dot.pack(side="left", padx=(0, 8))

        self.label = ctk.CTkLabel(inner, text="—",
                                   text_color=t["accent"],
                                   font=ctk.CTkFont(size=14, weight="bold"),
                                   wraplength=800, anchor="w", justify="left")
        self.label.pack(side="left", fill="x", expand=True)

    def set_result(self, text: str, color=None):
        c = color or self.t["accent"]
        self.label.configure(text=text, text_color=c)
        self._dot.configure(text_color=c)


# ─────────────────────────────────────────────
#  GRÁFICA EMBEBIDA
# ─────────────────────────────────────────────

class GraphFrame(ctk.CTkFrame):
    def __init__(self, parent, figsize=(7, 4), **kwargs):
        t = get_theme()
        kwargs.setdefault("fg_color", t["bg_card"])
        kwargs.setdefault("corner_radius", 10)
        super().__init__(parent, **kwargs)
        self.t = t
        self.fig = plt.Figure(figsize=figsize, facecolor=t["graph_bg"])
        self.ax = self.fig.add_subplot(111)
        self._style_ax()
        self.canvas = FigureCanvasTkAgg(self.fig, master=self)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=6)
        toolbar_frame = tk.Frame(self, bg=t["bg_card"])
        toolbar_frame.pack(fill="x", padx=6, pady=(0, 4))
        toolbar = NavigationToolbar2Tk(self.canvas, toolbar_frame)
        toolbar.config(bg=t["bg_card"])
        toolbar.update()

    def _style_ax(self):
        t = self.t
        self.ax.set_facecolor(t["graph_bg"])
        self.ax.tick_params(colors=t["graph_fg"])
        self.ax.xaxis.label.set_color(t["graph_fg"])
        self.ax.yaxis.label.set_color(t["graph_fg"])
        self.ax.title.set_color(t["graph_fg"])
        for spine in self.ax.spines.values():
            spine.set_color(t["border"])
        self.ax.grid(True, color=t["graph_grid"], linestyle="--", linewidth=0.5, alpha=0.6)

    def clear(self):
        self.ax.cla()
        self._style_ax()

    def refresh(self):
        self.canvas.draw()


# ─────────────────────────────────────────────
#  BANNER DE MÓDULO
# ─────────────────────────────────────────────

class ModuleBanner(ctk.CTkFrame):
    def __init__(self, parent, title, subtitle="", icon="🔢", **kwargs):
        t = get_theme()
        kwargs.setdefault("fg_color", t["bg_card"])
        kwargs.setdefault("corner_radius", 10)
        super().__init__(parent, **kwargs)

        # Contenedor principal centrado
        outer = ctk.CTkFrame(self, fg_color="transparent")
        outer.pack(fill="x", padx=14, pady=(8, 6))

        # Barra de acento izquierda
        accent_bar = ctk.CTkFrame(outer, width=4, fg_color=t["accent"], corner_radius=2)
        accent_bar.pack(side="left", fill="y", padx=(0, 12), pady=2)

        # Icono + texto en columna
        text_col = ctk.CTkFrame(outer, fg_color="transparent")
        text_col.pack(side="left", fill="x", expand=True)

        title_row = ctk.CTkFrame(text_col, fg_color="transparent")
        title_row.pack(fill="x")

        ctk.CTkLabel(title_row, text=icon,
                     font=ctk.CTkFont(size=18)).pack(side="left", padx=(0, 8))
        ctk.CTkLabel(title_row, text=title,
                     font=ctk.CTkFont(size=16, weight="bold"),
                     text_color=t["text_primary"],
                     anchor="w").pack(side="left", fill="x")

        if subtitle:
            ctk.CTkLabel(text_col, text=subtitle,
                         font=ctk.CTkFont(size=10),
                         text_color=t["text_secondary"],
                         anchor="w").pack(anchor="w", padx=(0, 4))
