"""
ayuda_formulas.py
Ventana de ayuda con formulas y ejemplos.
Correccion: ventana siempre visible, manejo robusto de ciclo de vida.
"""
import customtkinter as ctk
from ui.themes import get_theme


# ─── Ejemplos por módulo ─────────────────────────────────────────────────────

EJEMPLOS = {
    "raices": [
        {
            "nombre": "Polinomio cubico",
            "fx": "x**3 - x - 2",
            "a": "1", "b": "2", "x0": "1.5", "x1": "2.0",
            "tol": "1e-6", "desc": "Raiz real de x^3 - x - 2 = 0  =>  x ≈ 1.5214"
        },
        {
            "nombre": "Funcion trigonometrica",
            "fx": "cos(x) - x",
            "a": "0", "b": "1.5", "x0": "1.0", "x1": "1.2",
            "tol": "1e-8", "desc": "Punto fijo de cos(x) = x  =>  x ≈ 0.7391"
        },
        {
            "nombre": "Exponencial",
            "fx": "exp(x) - 3*x",
            "a": "0", "b": "2", "x0": "1.5", "x1": "1.8",
            "tol": "1e-7", "desc": "e^x = 3x  =>  x ≈ 1.5121"
        },
        {
            "nombre": "Logaritmo",
            "fx": "log(x) - x + 2",
            "a": "0.1", "b": "3", "x0": "2.0", "x1": "2.5",
            "tol": "1e-6", "desc": "ln(x) - x + 2 = 0  =>  x ≈ 0.1585 o x ≈ 3.146"
        },
        {
            "nombre": "🔺 Secante: sin(x)-√x+1",
            "fx": "sin(x) - x**(1/2) + 1",
            "a": "2.0", "b": "3.0", "x0": "2.5", "x1": "3.0",
            "tol": "0.00001", "desc": "sen(x) - x^(1/2) + 1 = 0  (Tol=0.00001)  =>  x ≈ 2.7369"
        },
    ],
    "interpolacion": [
        {
            "nombre": "Funcion exponencial e^x",
            "puntos": "0, 1\n1, 2.71828\n2, 7.38906\n3, 20.0855",
            "xeval": "1.5",
            "desc": "Interpolacion de e^x en [0,3].  P(1.5) ≈ 4.4817"
        },
        {
            "nombre": "Funcion seno",
            "puntos": "0, 0\n0.5236, 0.5\n1.0472, 0.866\n1.5708, 1.0",
            "xeval": "0.7854",
            "desc": "Interpolacion de sin(x). P(pi/4) ≈ 0.7071"
        },
        {
            "nombre": "Datos de temperatura",
            "puntos": "0, 20\n1, 22\n2, 27\n3, 35\n4, 30",
            "xeval": "2.5",
            "desc": "Interpolacion de mediciones de temperatura"
        },
    ],
    "sistemas": [
        {
            "nombre": "Sistema 3x3 (GS convergente)",
            "n": 3,
            "A": [[10, -1, 2], [3, 10, -1], [2, 3, 10]],
            "b": [6, 7, 8],
            "desc": "Diagonal dominante. Sol: x1≈0.556, x2≈0.585, x3≈0.513"
        },
        {
            "nombre": "Sistema 2x2 simple",
            "n": 2,
            "A": [[4, 1], [2, 3]],
            "b": [9, 8],
            "desc": "Sol exacta: x1 = 1.9, x2 = 1.4"
        },
        {
            "nombre": "Sistema 4x4",
            "n": 4,
            "A": [[10, -1, 2, 0], [3, 10, -1, 1], [2, 3, 10, -1], [0, 2, 3, 10]],
            "b": [6, 7, 8, 9],
            "desc": "Sistema 4x4 diagonal dominante"
        },
    ],
    "integracion": [
        {
            "nombre": "Ejercicio 1 – sin(x) · n=10",
            "fx": "sin(x)", "a": "0", "b": "3.14159265", "n": "10",
            "xreal": "2.0",
            "x0": "1.5708", "h": "0.001", "orden": 1,
            "desc": "y = sen(x)  de [0, π]  con 10 rectángulos. Valor real = 2.0"
        },
        {
            "nombre": "Ejercicio 2 – x^6-x^3 · n=100",
            "fx": "x**6 - x**3", "a": "-1", "b": "1", "n": "100",
            "xreal": "0.2857142857",
            "x0": "0.0", "h": "0.001", "orden": 1,
            "desc": "y = x⁶ - x³  de [-1, 1]  con 100 rectángulos. Valor real = 2/7 ≈ 0.2857"
        },
    ],
    "diferenciales": [
        {
            "nombre": "dy/dx = y  (sol: e^x)",
            "fxy": "y", "x0": "0", "y0": "1", "xf": "2", "h": "0.1",
            "desc": "y(0)=1, sol exacta: y = e^x. y(2) ≈ 7.389"
        },
        {
            "nombre": "dy/dx = x + y",
            "fxy": "x + y", "x0": "0", "y0": "1", "xf": "1", "h": "0.1",
            "desc": "Sol: y = 2e^x - x - 1. y(1) ≈ 3.436"
        },
        {
            "nombre": "dy/dx = -2xy  (gaussiana)",
            "fxy": "-2*x*y", "x0": "0", "y0": "1", "xf": "2", "h": "0.1",
            "desc": "Sol exacta: y = e^(-x^2)."
        },
    ],
    "diferenciales_euler": [
        {
            "nombre": "dy/dx = y  (sol: eˣ)",
            "fxy": "y", "x0": "0", "y0": "1", "xf": "2", "h": "0.25",
            "desc": "y(0)=1. h grande evidencia el error acumulado de Euler."
        },
        {
            "nombre": "dy/dx = 2x  (parábola)",
            "fxy": "2*x", "x0": "0", "y0": "0", "xf": "3", "h": "0.5",
            "desc": "Sol exacta: y=x². Euler es exacto para f(x) lineal en x."
        },
        {
            "nombre": "dy/dx = x + y",
            "fxy": "x + y", "x0": "0", "y0": "1", "xf": "1", "h": "0.2",
            "desc": "Sol: y=2eˣ-x-1. y(1)≈3.436. Compara con h pequeño."
        },
    ],
    "diferenciales_rk4": [
        {
            "nombre": "dy/dx = -2xy  (gaussiana)",
            "fxy": "-2*x*y", "x0": "0", "y0": "1", "xf": "2", "h": "0.2",
            "desc": "Sol: y=e^(-x²). RK4 alcanza alta precisión con pocos pasos."
        },
        {
            "nombre": "dy/dx = sin(x)·y",
            "fxy": "sin(x)*y", "x0": "0", "y0": "1", "xf": "3.14159", "h": "0.1",
            "desc": "Sol: y=e^(1-cos x). No lineal: RK4 supera a Euler."
        },
        {
            "nombre": "dy/dx = (y-x)/(y+x)",
            "fxy": "(y-x)/(y+x)", "x0": "0", "y0": "1", "xf": "1.5", "h": "0.1",
            "desc": "EDO no lineal. Muestra precisión de RK4 sobre Euler."
        },
    ],
    "sistemas_gs": [
        {
            "nombre": "3x3 Diagonal dominante",
            "n": 3, "A": [[10,-1,2],[3,10,-1],[2,3,10]], "b": [6,7,8],
            "desc": "GS converge. x1≈0.556, x2≈0.585, x3≈0.513"
        },
        {
            "nombre": "2x2 Simple",
            "n": 2, "A": [[4,1],[2,3]], "b": [9,8],
            "desc": "Sol exacta: x1=1.9, x2=1.4"
        },
        {
            "nombre": "4x4 Grande",
            "n": 4, "A": [[10,-1,2,0],[3,10,-1,1],[2,3,10,-1],[0,2,3,10]], "b": [6,7,8,9],
            "desc": "Sistema 4x4 diag. dominante."
        },
    ],
    "sistemas_lu": [
        {
            "nombre": "3x3 Clásico LU",
            "n": 3, "A": [[2,1,-1],[4,3,-1],[2,1,2]], "b": [8,14,10],
            "desc": "Sol: x1=2, x2=3, x3=-1. Factorización exacta."
        },
        {
            "nombre": "2x2 LU simple",
            "n": 2, "A": [[3,2],[6,6]], "b": [5,6],
            "desc": "Sol: x1=1, x2=1"
        },
        {
            "nombre": "3x3 Simétrica",
            "n": 3, "A": [[4,3,0],[3,4,-1],[0,-1,4]], "b": [24,30,-11],
            "desc": "Sol: x1=3, x2=4, x3=-1. Matriz simétrica."
        },
    ],
}

# ─── Funciones matematicas disponibles ───────────────────────────────────────

FORMULAS_PYTHON = [
    ("Potencia",       "x**n",            "x elevado a n  (NO usar ^)"),
    ("Raiz cuadrada",  "sqrt(x)",          "raiz cuadrada de x"),
    ("Exponencial",    "exp(x)",           "numero e elevado a x"),
    ("Log. natural",   "log(x)",           "logaritmo natural ln(x)"),
    ("Log base 10",    "log10(x)",         "logaritmo base 10"),
    ("Seno",           "sin(x)",           "seno de x (radianes)"),
    ("Coseno",         "cos(x)",           "coseno de x (radianes)"),
    ("Tangente",       "tan(x)",           "tangente de x"),
    ("Arcoseno",       "asin(x)",          "arcoseno de x"),
    ("Arcocoseno",     "acos(x)",          "arcocoseno de x"),
    ("Arcotangente",   "atan(x)",          "arcotangente de x"),
    ("Val. absoluto",  "Abs(x)",           "valor absoluto de x"),
    ("Pi",             "pi",               "π = 3.14159265..."),
    ("Euler e",        "E",                "e = 2.71828182..."),
    ("Polinomio",      "a*x**2 + b*x + c", "polinomio grado 2"),
    ("Fraccion",       "(x+1)/(x-1)",      "funcion racional"),
    ("Hiperbolico",    "sinh(x)",          "seno hiperbolico"),
    ("Cosh",           "cosh(x)",          "coseno hiperbolico"),
]

EJEMPLOS_FUNCIONES = [
    "x**3 - 2*x - 5",
    "sin(x)**2 + cos(x)**2 - 1",
    "exp(-x) - x",
    "x**4 - 3*x**2 + x + 1",
    "log(x) + x - 3",
    "x**2 - 5*x + 6",
    "tan(x) - x",
    "1/(1 + x**2)",
    "x*exp(-x)",
    "cos(x) - x**2",
]


# ─── Fórmulas por método ─────────────────────────────────────────────────────

FORMULAS_METODOS = {
    "Bisección": {
        "titulo": "Método de Bisección",
        "formula": "xᵣ = (a + b) / 2\n\nCriterio de signo:\n  f(a)·f(xᵣ) < 0  →  raíz en [a, xᵣ]\n  f(xᵣ)·f(b) < 0  →  raíz en [xᵣ, b]\n\nError relativo: εₐ = |xᵣⁿᵉʷ - xᵣᵒˡᵈ| / |xᵣⁿᵉʷ| × 100%",
        "params": [
            ("f(x)",  "Función continua donde f(a)·f(b) < 0.",   "Ej: x**3 - x - 2"),
            ("a",     "Extremo izquierdo del intervalo.",          "f(a) y f(b) con signos opuestos."),
            ("b",     "Extremo derecho del intervalo.",            "Verificar: f(a)·f(b) < 0"),
            ("Tol",   "Tolerancia de parada.",                     "Ej: 1e-6"),
        ],
        "nota": "Convergencia garantizada si f es continua y f(a)·f(b)<0.\nVelocidad: ~0.3 bits de precisión por iteración.",
    },
    "Newton-Raphson": {
        "titulo": "Método de Newton-Raphson",
        "formula": "x_{n+1} = x_n - f(x_n) / f'(x_n)\n\nDerivada numérica (diferencias centradas):\n  f'(x) ≈ [f(x+h) - f(x-h)] / (2h)\n\nError: εₐ = |x_{n+1} - x_n| / |x_{n+1}| × 100%",
        "params": [
            ("f(x)", "Función a resolver: f(x) = 0.",             "Ej: cos(x) - x"),
            ("x₀",  "Valor inicial (cerca de la raíz).",           "Debe estar en zona de convergencia."),
            ("Tol",  "Tolerancia.",                                 "Ej: 1e-8"),
        ],
        "nota": "Convergencia cuadrática si f'(x₀)≠0.\nDivergencia si x₀ está lejos o f'(x)≈0.",
    },
    "Secante": {
        "titulo": "Método de la Secante",
        "formula": "x_{n+1} = x_n - f(x_n)·(x_n - x_{n-1}) / (f(x_n) - f(x_{n-1}))\n\nNo requiere derivada analítica.\nError: εₐ = |x_{n+1} - x_n| / |x_{n+1}| × 100%",
        "params": [
            ("f(x)", "Función a resolver.",                        "Ej: sin(x) - x**(1/2) + 1"),
            ("x₀",  "Primer punto inicial.",                       "Ej: 2.5"),
            ("x₁",  "Segundo punto inicial.",                      "Ej: 3.0"),
            ("Tol",  "Tolerancia.",                                 "Ej: 1e-5"),
        ],
        "nota": "Usa diferencias finitas en lugar de derivada analítica.\nOrden de convergencia ≈ 1.618 (razón áurea).",
    },
    "Lagrange": {
        "titulo": "Interpolación de Lagrange",
        "formula": "P(x) = Σᵢ  yᵢ · Lᵢ(x)\n\nPolinomios base:\n  Lᵢ(x) = Π_{j≠i} (x - xⱼ) / (xᵢ - xⱼ)\n\nGrado del polinomio = n − 1  (n = número de puntos)",
        "params": [
            ("Puntos", "Pares (x, y) uno por línea, separados por coma.", "Ej:\n  0, 1\n  1, 2.71828\n  2, 7.389"),
        ],
        "nota": "El polinomio pasa exactamente por todos los puntos.\nNo requiere ingresar x para evaluar — calcula toda la curva.",
    },
    "Newton": {
        "titulo": "Interpolación de Newton (Diferencias Divididas)",
        "formula": "P(x) = f[x₀] + f[x₀,x₁](x−x₀) + f[x₀,x₁,x₂](x−x₀)(x−x₁) + …\n\nDiferencias divididas:\n  f[xᵢ,xⱼ] = (f[xⱼ] − f[xᵢ]) / (xⱼ − xᵢ)",
        "params": [
            ("Puntos",     "Pares (x, y) uno por línea.",          "Ej:\n  0, 1\n  1, 2.718\n  2, 7.389"),
            ("Evaluar x",  "Punto donde calcular P(x).",           "Ej: 1.5  →  P(1.5) ≈ 4.4817"),
        ],
        "nota": "Más eficiente que Lagrange para agregar nuevos puntos.\nLa tabla de diferencias divididas aparece en el procedimiento.",
    },
    "Euler": {
        "titulo": "Método de Euler (EDO de 1er orden)",
        "formula": "y_{n+1} = y_n + h · f(x_n, y_n)\n  x_{n+1} = x_n + h\n\nCondición inicial: y(x₀) = y₀\nError local: O(h²)  |  Error global: O(h)",
        "params": [
            ("f(x,y)", "Función del lado derecho de  dy/dx = f(x,y).", "Ej: x + y  |  -2*x*y  |  y"),
            ("x₀",    "Valor inicial de x.",                            "Ej: 0"),
            ("y₀",    "Condición inicial y(x₀).",                       "Ej: 1"),
            ("xf",    "Valor final de x.",                              "Ej: 2"),
            ("h",     "Tamaño de paso.",                                "Valores pequeños = más precisión. Ej: 0.1"),
        ],
        "nota": "Método explícito de orden 1. Simple pero menos preciso.\nReducir h mejora la precisión pero aumenta los pasos.",
    },
    "Runge-Kutta 4": {
        "titulo": "Runge-Kutta Orden 4 (RK4)",
        "formula": "k₁ = h · f(xₙ,      yₙ)\nk₂ = h · f(xₙ+h/2,  yₙ+k₁/2)\nk₃ = h · f(xₙ+h/2,  yₙ+k₂/2)\nk₄ = h · f(xₙ+h,    yₙ+k₃)\n\ny_{n+1} = yₙ + (k₁ + 2k₂ + 2k₃ + k₄) / 6",
        "params": [
            ("f(x,y)", "Función dy/dx = f(x,y).",                      "Ej: -2*x*y  |  sin(x)*y  |  (y-x)/(y+x)"),
            ("x₀",    "Valor inicial de x.",                            "Ej: 0"),
            ("y₀",    "Condición inicial.",                             "Ej: 1"),
            ("xf",    "Valor final.",                                   "Ej: 2"),
            ("h",     "Tamaño de paso.",                                "RK4 es preciso con h moderado. Ej: 0.2"),
        ],
        "nota": "Error local O(h⁵), error global O(h⁴).\nMucho más preciso que Euler con el mismo tamaño de paso h.",
    },
    "Gauss-Seidel": {
        "titulo": "Método de Gauss-Seidel",
        "formula": "xᵢ^(k+1) = (bᵢ − Σⱼ<ᵢ aᵢⱼ·xⱼ^(k+1) − Σⱼ>ᵢ aᵢⱼ·xⱼ^(k)) / aᵢᵢ\n\nCriterio de parada:\n  max|xᵢ^(k+1) − xᵢ^(k)| < tolerancia",
        "params": [
            ("Matriz A",  "Coeficientes del sistema Ax = b.",           "Debe ser diagonalmente dominante."),
            ("Vector b",  "Términos independientes.",                    "Columna derecha del sistema."),
            ("Tolerancia","Error máximo entre iteraciones sucesivas.",   "Ej: 1e-6"),
            ("Máx. iter.","Límite de iteraciones.",                      "Ej: 100"),
        ],
        "nota": "Convergencia garantizada si A es diagonalmente dominante.\nUsa los valores más recientes en cada iteración (Jacobi no).",
    },
    "Factorización LU": {
        "titulo": "Factorización LU",
        "formula": "A = L · U\n\nPaso 1: Factorizar  A  →  L (triang. inferior) y U (triang. superior)\nPaso 2: Resolver    L·y = b  (sustitución hacia adelante)\nPaso 3: Resolver    U·x = y  (sustitución hacia atrás)",
        "params": [
            ("Matriz A", "Coeficientes del sistema Ax = b.",             "No requiere ser diagonalmente dominante."),
            ("Vector b", "Términos independientes.",                      "Columna derecha del sistema."),
        ],
        "nota": "Solución exacta (sin iteraciones).\nEficiente para resolver varios sistemas con la misma matriz A.",
    },
}

# ─── Ventana de ayuda ────────────────────────────────────────────────────────

class AyudaFormulasDialog(ctk.CTkToplevel):
    """
    Ventana flotante de ayuda. Siempre aparece al frente.
    on_insert(texto): callback para insertar en el campo activo.
    """

    def __init__(self, parent, on_insert=None, modulo=None, metodo=None):
        super().__init__(parent)
        t = get_theme()
        self.on_insert = on_insert
        self.modulo = modulo
        self.metodo = metodo

        # ── Configuracion de la ventana ──────────────────────────────────────
        titulo = f"Ayuda – {metodo}" if metodo else "Ayuda – Fórmulas y Sintaxis"
        self.title(titulo)
        self.geometry("780x600")
        self.minsize(620, 460)
        self.configure(fg_color=t["bg_main"])
        self.resizable(True, True)

        # Garantizar que aparezca al frente siempre
        self.attributes("-topmost", True)   # siempre encima
        self.after(100, self._bring_to_front)  # forzar foco despues del render

        # Manejar cierre correcto
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self._build(t)

    def _bring_to_front(self):
        """Lleva la ventana al frente y le da foco."""
        try:
            self.deiconify()
            self.lift()
            self.focus_force()
            # Mantener topmost solo 800ms para no molestar con otras apps
            self.after(800, lambda: self.attributes("-topmost", False))
        except Exception:
            pass

    def _on_close(self):
        """Cierre limpio."""
        try:
            self.destroy()
        except Exception:
            pass

    def _build(self, t):
        # Encabezado
        hdr = ctk.CTkFrame(self, fg_color=t["bg_card"], corner_radius=0)
        hdr.pack(fill="x")

        titulo_txt = f"📚  Ayuda – {self.metodo}" if self.metodo else "📚  Ayuda – Fórmulas y Sintaxis Python"
        ctk.CTkLabel(hdr, text=titulo_txt,
                     font=ctk.CTkFont(size=15, weight="bold"),
                     text_color=t["text_accent"]
                     ).pack(side="left", padx=14, pady=10)

        ctk.CTkLabel(hdr,
                     text="Clic en cualquier fórmula para insertarla directamente",
                     font=ctk.CTkFont(size=10), text_color=t["text_secondary"]
                     ).pack(side="left", padx=4, pady=10)

        # Tabs
        tabs = ctk.CTkTabview(
            self,
            fg_color=t["bg_card"],
            segmented_button_fg_color=t["bg_input"],
            segmented_button_selected_color=t["accent"],
            segmented_button_unselected_color=t["bg_input"],
            segmented_button_selected_hover_color=t["accent_hover"],
            text_color=t["text_primary"],
            text_color_disabled=t["text_secondary"],
        )
        tabs.pack(fill="both", expand=True, padx=10, pady=(4, 10))

        _tiene_formula = self.metodo and self.metodo in FORMULAS_METODOS
        if _tiene_formula:
            tabs.add("📐  Fórmula")
        tabs.add("⚙  Funciones")
        tabs.add("📋  Ejemplos")
        tabs.add("🔣  Operadores")

        if _tiene_formula:
            self._build_formula(tabs.tab("📐  Fórmula"), t)
            tabs.set("📐  Fórmula")
        self._build_funciones(tabs.tab("⚙  Funciones"), t)
        self._build_ejemplos(tabs.tab("📋  Ejemplos"), t)
        self._build_operadores(tabs.tab("🔣  Operadores"), t)

    # ── Tab Fórmula ───────────────────────────────────────────────────────────

    def _build_formula(self, parent, t):
        info = FORMULAS_METODOS[self.metodo]
        scroll = ctk.CTkScrollableFrame(parent, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=4, pady=4)

        # Título del método
        ctk.CTkLabel(scroll, text=f"📐  {info['titulo']}",
                     text_color=t["accent"], font=ctk.CTkFont(size=14, weight="bold")
                     ).pack(anchor="w", padx=6, pady=(8, 4))

        # Bloque fórmula
        ctk.CTkLabel(scroll, text="Fórmula matemática:",
                     text_color=t["text_secondary"], font=ctk.CTkFont(size=11, weight="bold")
                     ).pack(anchor="w", padx=6, pady=(4, 0))
        f_frame = ctk.CTkFrame(scroll, fg_color=t["bg_card"], corner_radius=8,
                               border_width=1, border_color=t["accent"])
        f_frame.pack(fill="x", padx=6, pady=(2, 10))
        ctk.CTkLabel(f_frame, text=info["formula"],
                     text_color=t["accent2"],
                     font=ctk.CTkFont(family="Courier", size=12),
                     justify="left").pack(anchor="w", padx=16, pady=10)

        # Parámetros
        ctk.CTkLabel(scroll, text="Parámetros:",
                     text_color=t["text_secondary"], font=ctk.CTkFont(size=11, weight="bold")
                     ).pack(anchor="w", padx=6, pady=(0, 4))
        for nombre, desc, ejemplo in info["params"]:
            row = ctk.CTkFrame(scroll, fg_color=t["bg_input"], corner_radius=6)
            row.pack(fill="x", padx=6, pady=3)
            ctk.CTkLabel(row, text=nombre, width=90, text_color=t["accent"],
                         font=ctk.CTkFont(size=12, weight="bold"), anchor="w"
                         ).grid(row=0, column=0, padx=(10, 4), pady=(8, 0), sticky="w")
            ctk.CTkLabel(row, text=desc, text_color=t["text_primary"],
                         font=ctk.CTkFont(size=11), anchor="w", justify="left"
                         ).grid(row=0, column=1, padx=4, pady=(8, 0), sticky="w")
            ctk.CTkLabel(row, text=ejemplo, text_color=t["text_secondary"],
                         font=ctk.CTkFont(size=10), anchor="w", justify="left"
                         ).grid(row=1, column=0, columnspan=2, padx=10, pady=(0, 8), sticky="w")

        # Nota
        n_frame = ctk.CTkFrame(scroll, fg_color=t["bg_card"], corner_radius=8)
        n_frame.pack(fill="x", padx=6, pady=(8, 4))
        ctk.CTkLabel(n_frame, text="ℹ️  " + info["nota"],
                     text_color=t["text_secondary"], font=ctk.CTkFont(size=10),
                     justify="left").pack(anchor="w", padx=12, pady=8)

    # ── Tab 1: Funciones ─────────────────────────────────────────────────────

    def _build_funciones(self, parent, t):
        scroll = ctk.CTkScrollableFrame(parent, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=4, pady=4)

        es_fxy = self.modulo == "diferenciales"
        campo = "f(x,y)" if es_fxy else "f(x)"
        nota_txt = (f"Funciones disponibles para el campo  {campo}  —  dy/dx = f(x,y):"
                    if es_fxy else
                    f"Funciones disponibles para el campo  {campo}:")

        ctk.CTkLabel(scroll, text=nota_txt,
                     font=ctk.CTkFont(size=11), text_color=t["text_secondary"]
                     ).pack(anchor="w", pady=(2, 8))

        for nombre, formula, desc in FORMULAS_PYTHON:
            row = ctk.CTkFrame(scroll, fg_color=t["bg_input"], corner_radius=7)
            row.pack(fill="x", pady=2, padx=1)
            row.configure(cursor="hand2")

            ctk.CTkLabel(row, text=nombre, width=130,
                         text_color=t["text_secondary"],
                         font=ctk.CTkFont(size=11), anchor="w"
                         ).pack(side="left", padx=(10, 2), pady=5)

            code_lbl = ctk.CTkLabel(row, text=formula, width=190,
                                    text_color=t["accent"],
                                    font=ctk.CTkFont(family="Courier", size=12, weight="bold"),
                                    anchor="w")
            code_lbl.pack(side="left", padx=4, pady=5)

            ctk.CTkLabel(row, text=desc,
                         text_color=t["text_secondary"],
                         font=ctk.CTkFont(size=10), anchor="w"
                         ).pack(side="left", padx=6, pady=5, fill="x", expand=True)

            btn = ctk.CTkButton(
                row, text="Insertar", width=72, height=26,
                fg_color=t["accent"], hover_color=t["accent_hover"],
                text_color="#fff", corner_radius=5,
                font=ctk.CTkFont(size=10),
                command=lambda f=formula: self._insert(f)
            )
            btn.pack(side="right", padx=8, pady=4)

            # Clic en toda la fila tambien inserta
            for w in (row, code_lbl):
                w.bind("<Button-1>", lambda e, f=formula: self._insert(f))

    # ── Tab 2: Ejemplos ──────────────────────────────────────────────────────

    def _build_ejemplos(self, parent, t):
        scroll = ctk.CTkScrollableFrame(parent, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=4, pady=4)

        # Determinar qué conjuntos de ejemplos mostrar
        if self.modulo is None:
            # Compatibilidad: mostrar todos
            modulos = [
                ("Raíces",                  EJEMPLOS["raices"],           "fx"),
                ("Interpolación",           EJEMPLOS["interpolacion"],    None),
                ("Integración",             EJEMPLOS["integracion"],      "fx"),
                ("Ecuaciones Diferenciales",EJEMPLOS["diferenciales"],    "fxy"),
            ]
        elif self.modulo == "raices":
            modulos = [("Ejemplos – Raíces", EJEMPLOS["raices"], "fx")]
        elif self.modulo == "interpolacion":
            modulos = [("Ejemplos – Interpolación", EJEMPLOS["interpolacion"], None)]
        elif self.modulo == "integracion":
            modulos = [("Ejemplos – Integración", EJEMPLOS["integracion"], "fx")]
        elif self.modulo == "diferenciales":
            key = "diferenciales_euler" if self.metodo == "Euler" else "diferenciales_rk4"
            label = f"Ejemplos – {self.metodo}"
            modulos = [(label, EJEMPLOS[key], "fxy")]
        else:
            modulos = []

        for mod_name, ejemplos, campo in modulos:
            ctk.CTkLabel(scroll, text=f"  {mod_name}",
                         text_color=t["accent2"],
                         font=ctk.CTkFont(size=12, weight="bold"),
                         fg_color=t["bg_input"], corner_radius=6, anchor="w"
                         ).pack(fill="x", pady=(10, 3), padx=1, ipady=3)

            for ej in ejemplos:
                card = ctk.CTkFrame(scroll, fg_color=t["bg_card"],
                                    corner_radius=8, border_width=1,
                                    border_color=t["border"])
                card.pack(fill="x", pady=2, padx=1)

                top = ctk.CTkFrame(card, fg_color="transparent")
                top.pack(fill="x", padx=10, pady=(6, 2))
                ctk.CTkLabel(top, text=ej["nombre"], text_color=t["text_primary"],
                             font=ctk.CTkFont(size=12, weight="bold"), anchor="w"
                             ).pack(side="left")
                ctk.CTkLabel(top, text=ej.get("desc", ""), text_color=t["text_secondary"],
                             font=ctk.CTkFont(size=9), anchor="w"
                             ).pack(side="left", padx=(8, 0))

                params_parts = []
                if "fx"  in ej: params_parts.append(f"f(x) = {ej['fx']}")
                if "fxy" in ej: params_parts.append(f"f(x,y) = {ej['fxy']}")
                if "a"   in ej: params_parts.append(f"[{ej['a']}, {ej['b']}]")
                if "puntos" in ej:
                    lines = ej["puntos"].strip().split("\n")
                    params_parts.append(f"{len(lines)} puntos")
                if params_parts:
                    ctk.CTkLabel(card, text="  " + "   |   ".join(params_parts),
                                 text_color=t["accent"],
                                 font=ctk.CTkFont(family="Courier", size=10), anchor="w"
                                 ).pack(fill="x", padx=10, pady=(0, 4))

                btn_row = ctk.CTkFrame(card, fg_color="transparent")
                btn_row.pack(anchor="w", padx=10, pady=(0, 6))
                if "fx" in ej:
                    ctk.CTkButton(btn_row, text="Insertar f(x)", width=105, height=24,
                                  fg_color=t["accent"], hover_color=t["accent_hover"],
                                  text_color="#fff", corner_radius=5, font=ctk.CTkFont(size=10),
                                  command=lambda f=ej["fx"]: self._insert(f)
                                  ).pack(side="left", padx=(0, 6))
                if "fxy" in ej:
                    ctk.CTkButton(btn_row, text="Insertar f(x,y)", width=115, height=24,
                                  fg_color=t["accent"], hover_color=t["accent_hover"],
                                  text_color="#fff", corner_radius=5, font=ctk.CTkFont(size=10),
                                  command=lambda f=ej["fxy"]: self._insert(f)
                                  ).pack(side="left", padx=(0, 6))

        # Funciones de ejemplo completas (solo módulos con campo f(x)/f(x,y))
        if self.modulo in (None, "raices", "integracion", "diferenciales"):
            ctk.CTkLabel(scroll, text="  Funciones de ejemplo completas",
                         text_color=t["accent2"], font=ctk.CTkFont(size=12, weight="bold"),
                         fg_color=t["bg_input"], corner_radius=6, anchor="w"
                         ).pack(fill="x", pady=(14, 4), padx=1, ipady=3)
            for ex in EJEMPLOS_FUNCIONES:
                row = ctk.CTkFrame(scroll, fg_color=t["bg_card"], corner_radius=7,
                                   border_width=1, border_color=t["border"])
                row.pack(fill="x", pady=2, padx=1)
                row.configure(cursor="hand2")
                lbl = ctk.CTkLabel(row, text=f"  {ex}", text_color=t["accent"],
                                   font=ctk.CTkFont(family="Courier", size=11), anchor="w")
                lbl.pack(side="left", padx=4, pady=6, fill="x", expand=True)
                ctk.CTkButton(row, text="Insertar", width=72, height=26,
                              fg_color=t["accent"], hover_color=t["accent_hover"],
                              text_color="#fff", corner_radius=5, font=ctk.CTkFont(size=10),
                              command=lambda f=ex: self._insert(f)
                              ).pack(side="right", padx=8, pady=4)
                for w in (row, lbl):
                    w.bind("<Button-1>", lambda e, f=ex: self._insert(f))

    # ── Tab 3: Operadores ────────────────────────────────────────────────────

    def _build_operadores(self, parent, t):
        scroll = ctk.CTkScrollableFrame(parent, fg_color="transparent")
        scroll.pack(fill="both", expand=True, padx=4, pady=4)

        # Aviso principal
        aviso = ctk.CTkFrame(scroll, fg_color="#2D1B00", corner_radius=8)
        aviso.pack(fill="x", pady=(2, 12), padx=1)
        ctk.CTkLabel(aviso,
                     text="⚠   IMPORTANTE: En Python se usa ** para potencia,  NO el símbolo ^",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color="#E3B341", anchor="w"
                     ).pack(anchor="w", padx=12, pady=8)
        ctk.CTkLabel(aviso,
                     text="     Correcto: x**2  |  Incorrecto: x^2",
                     font=ctk.CTkFont(family="Courier", size=11),
                     text_color="#C9AA71", anchor="w"
                     ).pack(anchor="w", padx=12, pady=(0, 8))

        operadores = [
            ("+",  "Suma",           "x + 3",         "a mas b"),
            ("-",  "Resta",          "x - 1",         "a menos b"),
            ("*",  "Multiplicacion", "2*x",           "SIEMPRE escribir el asterisco"),
            ("/",  "Division",       "x/2",           "a dividido b"),
            ("**", "Potencia",       "x**3",          "a elevado a b  (NO usar ^)"),
            ("()", "Agrupacion",     "(x+1)*(x-1)",   "usar parentesis para agrupar"),
            ("%",  "Modulo",         "x % 2",         "resto de la division"),
        ]

        ctk.CTkLabel(scroll, text="Operadores aritméticos:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=t["text_primary"]
                     ).pack(anchor="w", pady=(0, 6))

        for op, nombre, ejemplo, nota in operadores:
            row = ctk.CTkFrame(scroll, fg_color=t["bg_input"], corner_radius=7)
            row.pack(fill="x", pady=2, padx=1)

            ctk.CTkLabel(row, text=op, width=50,
                         text_color=t["accent"],
                         font=ctk.CTkFont(family="Courier", size=16, weight="bold"),
                         anchor="center"
                         ).pack(side="left", padx=(8, 2), pady=6)

            ctk.CTkLabel(row, text=nombre, width=130,
                         text_color=t["text_primary"],
                         font=ctk.CTkFont(size=11, weight="bold"), anchor="w"
                         ).pack(side="left", padx=4)

            ctk.CTkLabel(row, text=ejemplo, width=140,
                         text_color=t["accent"],
                         font=ctk.CTkFont(family="Courier", size=11), anchor="w"
                         ).pack(side="left", padx=4)

            ctk.CTkLabel(row, text=nota,
                         text_color=t["text_secondary"],
                         font=ctk.CTkFont(size=10), anchor="w"
                         ).pack(side="left", padx=6, fill="x", expand=True)

            ctk.CTkButton(
                row, text="Copiar", width=62, height=24,
                fg_color=t["bg_card"], hover_color=t["accent"],
                text_color=t["text_primary"], corner_radius=5,
                font=ctk.CTkFont(size=10),
                command=lambda o=op: self._insert(o)
            ).pack(side="right", padx=8, pady=4)

        # Constantes
        ctk.CTkLabel(scroll, text="Constantes matemáticas:",
                     font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=t["text_primary"]
                     ).pack(anchor="w", pady=(14, 6))

        constantes = [
            ("pi",  "Pi",       "π = 3.14159265358979..."),
            ("E",   "Euler e",  "e = 2.71828182845904..."),
            ("oo",  "Infinito", "∞  (solo para limites con SymPy)"),
        ]

        for const, nombre, desc in constantes:
            row = ctk.CTkFrame(scroll, fg_color=t["bg_input"], corner_radius=7)
            row.pack(fill="x", pady=2, padx=1)
            row.configure(cursor="hand2")

            ctk.CTkLabel(row, text=const, width=60,
                         text_color=t["accent"],
                         font=ctk.CTkFont(family="Courier", size=14, weight="bold"),
                         anchor="center"
                         ).pack(side="left", padx=(8, 2), pady=6)

            ctk.CTkLabel(row, text=nombre, width=90,
                         text_color=t["text_primary"],
                         font=ctk.CTkFont(size=11, weight="bold"), anchor="w"
                         ).pack(side="left", padx=4)

            ctk.CTkLabel(row, text=desc,
                         text_color=t["text_secondary"],
                         font=ctk.CTkFont(size=10), anchor="w"
                         ).pack(side="left", padx=6, fill="x", expand=True)

            ctk.CTkButton(
                row, text="Insertar", width=72, height=24,
                fg_color=t["accent"], hover_color=t["accent_hover"],
                text_color="#fff", corner_radius=5, font=ctk.CTkFont(size=10),
                command=lambda c=const: self._insert(c)
            ).pack(side="right", padx=8, pady=4)

            row.bind("<Button-1>", lambda e, c=const: self._insert(c))

    # ── Insertar ─────────────────────────────────────────────────────────────

    def _insert(self, text: str):
        """Llama el callback con el texto a insertar."""
        if self.on_insert:
            self.on_insert(text)
