"""
Sistema de Temas – Métodos Numéricos con Python
Soporta: Claro, Oscuro y Personalizado
"""

THEMES = {
    "dark": {
        "name": "Oscuro 🌙",
        "bg_main":        "#0D1117",
        "bg_sidebar":     "#161B22",
        "bg_card":        "#21262D",
        "bg_input":       "#2D333B",
        "bg_table_head":  "#1F6FEB",
        "bg_table_even":  "#21262D",
        "bg_table_odd":   "#2D333B",
        "accent":         "#1F6FEB",
        "accent_hover":   "#388BFD",
        "accent2":        "#3FB950",
        "accent3":        "#F78166",
        "text_primary":   "#E6EDF3",
        "text_secondary": "#8B949E",
        "text_accent":    "#79C0FF",
        "border":         "#30363D",
        "sidebar_active": "#1F2D40",
        "sidebar_active_bar": "#1F6FEB",
        "btn_primary":    "#1F6FEB",
        "btn_primary_hover": "#388BFD",
        "btn_danger":     "#DA3633",
        "btn_success":    "#2EA043",
        "btn_warning":    "#D29922",
        "graph_bg":       "#0D1117",
        "graph_fg":       "#E6EDF3",
        "graph_grid":     "#30363D",
        "graph_colors":   ["#1F6FEB", "#3FB950", "#F78166", "#D2A679", "#9E6EFF"],
        "tag_bg":         "#1F6FEB",
        "shadow":         "#000000",
        "mode":           "dark",
    },
    "light": {
        "name": "Claro ☀️",
        "bg_main":        "#F6F8FA",
        "bg_sidebar":     "#FFFFFF",
        "bg_card":        "#FFFFFF",
        "bg_input":       "#F0F2F5",
        "bg_table_head":  "#0969DA",
        "bg_table_even":  "#F6F8FA",
        "bg_table_odd":   "#EAEEF2",
        "accent":         "#0969DA",
        "accent_hover":   "#0550AE",
        "accent2":        "#1A7F37",
        "accent3":        "#CF222E",
        "text_primary":   "#1F2328",
        "text_secondary": "#656D76",
        "text_accent":    "#0969DA",
        "border":         "#D0D7DE",
        "sidebar_active": "#DDF4FF",
        "sidebar_active_bar": "#0969DA",
        "btn_primary":    "#0969DA",
        "btn_primary_hover": "#0550AE",
        "btn_danger":     "#CF222E",
        "btn_success":    "#1A7F37",
        "btn_warning":    "#9A6700",
        "graph_bg":       "#FFFFFF",
        "graph_fg":       "#1F2328",
        "graph_grid":     "#D0D7DE",
        "graph_colors":   ["#0969DA", "#1A7F37", "#CF222E", "#9A6700", "#6639BA"],
        "tag_bg":         "#0969DA",
        "shadow":         "#D0D7DE",
        "mode":           "light",
    },
    "custom": {
        "name": "Personalizado 🎨",
        "bg_main":        "#1A0533",
        "bg_sidebar":     "#210840",
        "bg_card":        "#2C0F55",
        "bg_input":       "#3A1460",
        "bg_table_head":  "#7B2FBE",
        "bg_table_even":  "#2C0F55",
        "bg_table_odd":   "#3A1460",
        "accent":         "#C77DFF",
        "accent_hover":   "#E040FB",
        "accent2":        "#00E5FF",
        "accent3":        "#FF6E40",
        "text_primary":   "#F3E5FF",
        "text_secondary": "#CE93D8",
        "text_accent":    "#E040FB",
        "border":         "#7B2FBE",
        "sidebar_active": "#3A1460",
        "sidebar_active_bar": "#C77DFF",
        "btn_primary":    "#7B2FBE",
        "btn_primary_hover": "#C77DFF",
        "btn_danger":     "#FF6E40",
        "btn_success":    "#00E5FF",
        "btn_warning":    "#FFCA28",
        "graph_bg":       "#1A0533",
        "graph_fg":       "#F3E5FF",
        "graph_grid":     "#7B2FBE",
        "graph_colors":   ["#C77DFF", "#00E5FF", "#FF6E40", "#FFCA28", "#69F0AE"],
        "tag_bg":         "#7B2FBE",
        "shadow":         "#000000",
        "mode":           "dark",
    },
}

current_theme = "dark"


def get_theme():
    return THEMES[current_theme]


def set_theme(name: str):
    global current_theme
    if name in THEMES:
        current_theme = name


def get_ctk_appearance():
    t = get_theme()
    return "Dark" if t["mode"] == "dark" else "Light"
