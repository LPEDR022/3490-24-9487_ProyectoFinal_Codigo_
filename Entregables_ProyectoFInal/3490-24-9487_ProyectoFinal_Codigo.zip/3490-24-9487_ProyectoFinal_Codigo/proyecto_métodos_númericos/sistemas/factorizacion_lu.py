"""
Factorización LU (método de Doolittle)
"""
import numpy as np


def factorizacion_lu(A, b):
    """
    Factorización LU de Doolittle: A = L·U
    Resuelve Ax = b.
    """
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    n = len(b)

    L = np.zeros((n, n))
    U = np.zeros((n, n))

    procedimiento = []
    procedimiento.append("=" * 60)
    procedimiento.append("FACTORIZACIÓN LU – MÉTODO DE DOOLITTLE")
    procedimiento.append("=" * 60)
    procedimiento.append("\nA = L · U\nDonde L es triangular inferior y U triangular superior\n")
    procedimiento.append("-" * 60)

    for i in range(n):
        L[i, i] = 1.0  # Diagonal de L = 1

        # Calcular U fila i
        procedimiento.append(f"\n▶ Fila {i+1} de U (u_{i+1},j):")
        for j in range(i, n):
            s = sum(L[i, k] * U[k, j] for k in range(i))
            U[i, j] = A[i, j] - s
            procedimiento.append(
                f"   u_{i+1}{j+1} = {A[i,j]:.6g} - {s:.6g} = {U[i,j]:.8g}"
            )

        # Calcular L columna i
        procedimiento.append(f"\n▶ Columna {i+1} de L (l_i,{i+1}):")
        for j in range(i + 1, n):
            if abs(U[i, i]) < 1e-14:
                raise ZeroDivisionError(f"U[{i},{i}] = 0. No se puede factorizar.")
            s = sum(L[j, k] * U[k, i] for k in range(i))
            L[j, i] = (A[j, i] - s) / U[i, i]
            procedimiento.append(
                f"   l_{j+1}{i+1} = ({A[j,i]:.6g} - {s:.6g}) / {U[i,i]:.6g} = {L[j,i]:.8g}"
            )

    # Mostrar matrices L y U
    procedimiento.append("\n" + "=" * 60)
    procedimiento.append("MATRIZ L (Triangular Inferior):")
    for row in L:
        procedimiento.append("   " + "  ".join(f"{v:.6g}" for v in row))

    procedimiento.append("\nMATRIZ U (Triangular Superior):")
    for row in U:
        procedimiento.append("   " + "  ".join(f"{v:.6g}" for v in row))

    # Paso 2: Resolver Ly = b (sustitución hacia adelante)
    procedimiento.append("\n" + "=" * 60)
    procedimiento.append("PASO 2: Resolver L·y = b (sustitución hacia adelante)")
    y = np.zeros(n)
    for i in range(n):
        s = sum(L[i, j] * y[j] for j in range(i))
        y[i] = (b[i] - s) / L[i, i]
        procedimiento.append(f"   y{i+1} = ({b[i]:.6g} - {s:.6g}) / {L[i,i]:.6g} = {y[i]:.8g}")

    # Paso 3: Resolver Ux = y (sustitución hacia atrás)
    procedimiento.append("\n" + "=" * 60)
    procedimiento.append("PASO 3: Resolver U·x = y (sustitución hacia atrás)")
    x = np.zeros(n)
    for i in range(n - 1, -1, -1):
        s = sum(U[i, j] * x[j] for j in range(i + 1, n))
        if abs(U[i, i]) < 1e-14:
            raise ZeroDivisionError(f"U[{i},{i}] = 0")
        x[i] = (y[i] - s) / U[i, i]
        procedimiento.append(f"   x{i+1} = ({y[i]:.6g} - {s:.6g}) / {U[i,i]:.6g} = {x[i]:.8g}")

    procedimiento.append(f"\n{'='*60}")
    procedimiento.append("RESULTADO FINAL:")
    for i, xi in enumerate(x):
        procedimiento.append(f"   x{i+1} = {xi:.10g}")
    procedimiento.append("=" * 60)

    # Tabla L
    tabla_L = [[f"Fila {i+1}"] + list(L[i]) for i in range(n)]
    tabla_U = [[f"Fila {i+1}"] + list(U[i]) for i in range(n)]

    headers_L = [""] + [f"col {j+1}" for j in range(n)]
    headers_U = headers_L[:]

    return {
        "solucion": x,
        "L": L,
        "U": U,
        "y": y,
        "tabla_L_headers": headers_L,
        "tabla_L": tabla_L,
        "tabla_U_headers": headers_U,
        "tabla_U": tabla_U,
        "procedimiento": "\n".join(procedimiento),
    }
