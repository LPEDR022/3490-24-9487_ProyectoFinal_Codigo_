"""
Método de Gauss-Seidel
"""
import numpy as np


def gauss_seidel(A, b, x0=None, tol=1e-6, max_iter=100):
    """
    Método iterativo de Gauss-Seidel para Ax = b.

    Parámetros:
        A       : matriz de coeficientes (n x n)
        b       : vector de términos independientes
        x0      : solución inicial (default: ceros)
        tol     : tolerancia
        max_iter: máximo de iteraciones
    """
    A = np.array(A, dtype=float)
    b = np.array(b, dtype=float)
    n = len(b)

    if x0 is None:
        x0 = np.zeros(n)
    x = np.array(x0, dtype=float)

    # Verificar diagonal dominante
    dominante = all(
        abs(A[i, i]) >= sum(abs(A[i, j]) for j in range(n) if j != i)
        for i in range(n)
    )

    tabla = []
    procedimiento = []
    procedimiento.append("=" * 60)
    procedimiento.append("MÉTODO DE GAUSS-SEIDEL")
    procedimiento.append("=" * 60)
    procedimiento.append(f"\nSistema Ax = b")
    procedimiento.append(f"Diagonal dominante: {'✅ Sí' if dominante else '⚠️ No garantizado'}\n")

    # Mostrar despeje
    procedimiento.append("Despeje de variables:")
    for i in range(n):
        otros = []
        for j in range(n):
            if j != i:
                coef = -A[i, j] / A[i, i]
                sign = "+" if coef >= 0 else ""
                otros.append(f"{sign}{coef:.6g}·x{j+1}")
        procedimiento.append(
            f"   x{i+1} = ({b[i]:.6g} {''.join(otros)}) / {A[i,i]:.6g}"
        )

    procedimiento.append(f"\nx₀ = {x0.tolist()}")
    procedimiento.append(f"Tolerancia: {tol}\n")
    procedimiento.append("-" * 60)

    convergio = False

    for it in range(1, max_iter + 1):
        x_old = x.copy()
        paso = [f"\n▶ Iteración {it}:"]

        for i in range(n):
            sigma = sum(A[i, j] * x[j] for j in range(n) if j != i)
            x[i] = (b[i] - sigma) / A[i, i]
            paso.append(
                f"   x{i+1} = ({b[i]:.6g} - ({sigma:.6g})) / {A[i,i]:.6g} = {x[i]:.8g}"
            )

        err = np.max(np.abs(x - x_old))
        paso.append(f"   Error máximo = {err:.8g}")
        procedimiento.append("\n".join(paso))

        row = [it] + list(x) + [err]
        tabla.append(row)

        if err < tol:
            procedimiento.append(f"\n✅ Convergencia en iteración {it}")
            convergio = True
            break

    if not convergio:
        procedimiento.append(f"\n⚠️ Máximo de iteraciones alcanzado ({max_iter})")

    procedimiento.append(f"\n{'='*60}")
    for i, xi in enumerate(x):
        procedimiento.append(f"   x{i+1} = {xi:.10g}")
    procedimiento.append("=" * 60)

    headers = ["n"] + [f"x{i+1}" for i in range(n)] + ["Error máx."]

    return {
        "solucion": x,
        "iteraciones": len(tabla),
        "convergio": convergio,
        "tabla_headers": headers,
        "tabla": tabla,
        "procedimiento": "\n".join(procedimiento),
    }
