"""
Vista del Modulo de Sistemas de Ecuaciones
Gauss-Seidel y Factorizacion LU – con ejemplos predefinidos
"""
import tkinter as tk
import customtkinter as ctk
import numpy as np
from ui.themes import get_theme
from ui.components import (
    themed_frame, section_label, primary_button, danger_button, success_button,
    IterationTable, ProcedimientoBox, ResultadoBox, ModuleBanner
)
from ui.ayuda_formulas import EJEMPLOS
from sistemas.gauss_seidel import gauss_seidel
from sistemas.factorizacion_lu import factorizacion_lu
from utils.validators import safe_float, safe_int


class SistemasView(ctk.CTkFrame):
    def __init__(self, parent, export_callback=None):
        t = get_theme()
        super().__init__(parent, fg_color=t["bg_main"], corner_radius=0)
        self.t = t
        self.export_callback = export_callback
        self._last_result = None
        self.n_vars = 3
        self._build()

    def _build(self):
        t = self.t

        banner = ModuleBanner(self, "Sistemas de Ecuaciones",
                              "Gauss-Seidel · Factorización LU", "🧩")
        banner.pack(fill="x", padx=12, pady=(6, 3))

        scroll = ctk.CTkScrollableFrame(self, fg_color=t["bg_main"])
        scroll.pack(fill="both", expand=True, padx=12, pady=3)

        # ── Método ──────────────────────────────────────────────────────────
        mf = themed_frame(scroll)
        mf.pack(fill="x", pady=(0, 4))
        section_label(mf, "Método:").pack(side="left", padx=10, pady=6)
        self.method_var = ctk.StringVar(value="Gauss-Seidel")
        for m in ["Gauss-Seidel", "Factorización LU"]:
            ctk.CTkRadioButton(
                mf, text=m, value=m,
                variable=self.method_var,
                text_color=t["text_primary"],
                fg_color=t["accent"],
                font=ctk.CTkFont(size=12),
                radiobutton_width=16, radiobutton_height=16,
                command=self._on_method_change
            ).pack(side="left", padx=10)

        # ── Ejemplos ────────────────────────────────────────────────────────
        self.ej_frame = themed_frame(scroll)
        self.ej_frame.pack(fill="x", pady=(0, 4))
        self._rebuild_ejemplos()

        # ── Tamaño del sistema ───────────────────────────────────────────────
        sf = themed_frame(scroll)
        sf.pack(fill="x", pady=(0, 4))
        section_label(sf, "Tamaño del sistema:").pack(side="left", padx=14, pady=10)
        self.size_var = ctk.IntVar(value=3)
        for n in [2, 3, 4]:
            ctk.CTkRadioButton(
                sf, text=f"{n}×{n}", value=n,
                variable=self.size_var,
                text_color=t["text_primary"],
                fg_color=t["accent"],
                font=ctk.CTkFont(size=12),
                radiobutton_width=16, radiobutton_height=16,
                command=self._rebuild_matrix
            ).pack(side="left", padx=8)

        # ── Matriz dinámica ──────────────────────────────────────────────────
        self.matrix_frame = themed_frame(scroll)
        self.matrix_frame.pack(fill="x", pady=(0, 4))
        self.matrix_entries = []
        self.b_entries = []
        self._rebuild_matrix()

        # ── Parámetros GS ────────────────────────────────────────────────────
        self.gs_frame = themed_frame(scroll)
        self.gs_frame.pack(fill="x", pady=(0, 4))
        section_label(self.gs_frame, "⚙️ Parámetros Gauss-Seidel").pack(anchor="w", padx=14, pady=(10, 4))
        gs_g = ctk.CTkFrame(self.gs_frame, fg_color="transparent")
        gs_g.pack(fill="x", padx=8, pady=(0, 6))

        ctk.CTkLabel(gs_g, text="Tolerancia:", text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=12)).grid(row=0, column=0, sticky="w", padx=8)
        self.entry_tol = ctk.CTkEntry(gs_g, placeholder_text="1e-6", width=120,
                                      fg_color=t["bg_input"], border_color=t["border"],
                                      text_color=t["text_primary"])
        self.entry_tol.grid(row=0, column=1, padx=8)

        ctk.CTkLabel(gs_g, text="Máx. Iteraciones:", text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=12)).grid(row=0, column=2, sticky="w", padx=8)
        self.entry_maxit = ctk.CTkEntry(gs_g, placeholder_text="100", width=100,
                                        fg_color=t["bg_input"], border_color=t["border"],
                                        text_color=t["text_primary"])
        self.entry_maxit.grid(row=0, column=3, padx=8)

        # ── Botones ──────────────────────────────────────────────────────────
        btn_row = ctk.CTkFrame(scroll, fg_color="transparent")
        btn_row.pack(anchor="w", pady=(0, 8))
        primary_button(btn_row, "▶  Calcular",    self._calcular, width=150).pack(side="left", padx=4)
        danger_button (btn_row, "🗑  Limpiar",     self._limpiar,  width=120).pack(side="left", padx=4)
        success_button(btn_row, "📄  Exportar PDF",self._exportar, width=160).pack(side="left", padx=4)

        # ── Resultado ────────────────────────────────────────────────────────
        section_label(scroll, "✅ Resultado").pack(anchor="w", pady=(5, 1))
        self.resultado_box = ResultadoBox(scroll)
        self.resultado_box.pack(fill="x", pady=(0, 4))

        # ── Tabla ────────────────────────────────────────────────────────────
        section_label(scroll, "📊 Tabla").pack(anchor="w", pady=(3, 1))
        self.tabla = IterationTable(scroll, columns=["n", "x1", "x2", "x3", "Error"])
        self.tabla.pack(fill="x", pady=(0, 4))

        # ── Procedimiento ─────────────────────────────────────────────────────
        section_label(scroll, "🧾 Procedimiento Paso a Paso").pack(anchor="w", pady=(3, 1))
        self.proc_box = ProcedimientoBox(scroll)
        self.proc_box.pack(fill="x", pady=(0, 6))
        self.proc_box.configure(height=320)

    # ── Reconstruir ejemplos por método ──────────────────────────────────────
    def _rebuild_ejemplos(self):
        t = self.t
        key = "sistemas_gs" if self.method_var.get() == "Gauss-Seidel" else "sistemas_lu"
        for w in self.ej_frame.winfo_children():
            w.destroy()
        section_label(self.ej_frame, "📂 Ejemplos:").pack(side="left", padx=10, pady=4)
        for ej in EJEMPLOS[key]:
            nm = ej["nombre"]
            ctk.CTkButton(self.ej_frame,
                          text=nm[:22]+"…" if len(nm) > 22 else nm,
                          width=200, height=26,
                          fg_color=t["bg_input"], hover_color=t["accent"],
                          text_color=t["text_primary"], corner_radius=8,
                          font=ctk.CTkFont(size=11),
                          command=lambda e=ej: self._cargar_ejemplo(e)
                          ).pack(side="left", padx=4, pady=6)

    # ── Cargar ejemplo ────────────────────────────────────────────────────────
    def _cargar_ejemplo(self, ej):
        n = ej["n"]
        self.size_var.set(n)
        self._rebuild_matrix()
        A = ej["A"]; b_vals = ej["b"]
        for i in range(n):
            for j in range(n):
                self.matrix_entries[i][j].delete(0, "end")
                self.matrix_entries[i][j].insert(0, str(A[i][j]))
            self.b_entries[i].delete(0, "end")
            self.b_entries[i].insert(0, str(b_vals[i]))
        self.proc_box.set_text(f"Ejemplo cargado: {ej['nombre']}\n{ej.get('desc', '')}")

    # ── Reconstruir matriz ────────────────────────────────────────────────────
    def _rebuild_matrix(self):
        t = self.t
        n = self.size_var.get()
        self.n_vars = n
        for w in self.matrix_frame.winfo_children():
            w.destroy()

        section_label(self.matrix_frame,
                      f"📐 Matriz A ({n}×{n}) y vector b — ingrese los coeficientes"
                      ).pack(anchor="w", padx=14, pady=(10, 6))

        hint = ctk.CTkLabel(self.matrix_frame,
                            text="Ejemplo: para 2x₁ + 3x₂ = 5, ingrese 2 y 3 en la fila, y 5 en b",
                            text_color=t["text_secondary"], font=ctk.CTkFont(size=10))
        hint.pack(anchor="w", padx=10, pady=(0, 2))

        grid = ctk.CTkFrame(self.matrix_frame, fg_color="transparent")
        grid.pack(anchor="w", padx=14, pady=(0, 12))

        # Headers
        ctk.CTkLabel(grid, text="Ec.", width=32, text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=11, weight="bold")
                     ).grid(row=0, column=0, padx=3)
        for j in range(n):
            ctk.CTkLabel(grid, text=f"x{j+1}", width=80, text_color=t["accent"],
                         font=ctk.CTkFont(size=11, weight="bold")
                         ).grid(row=0, column=j+1, padx=3)
        ctk.CTkLabel(grid, text="  |  b", width=80, text_color=t["accent2"],
                     font=ctk.CTkFont(size=11, weight="bold")
                     ).grid(row=0, column=n+1, padx=3)

        defaults_A = {
            2: [[4, 1], [2, 3]],
            3: [[10, -1, 2], [3, 10, -1], [2, 3, 10]],
            4: [[10, -1, 2, 0], [3, 10, -1, 1], [2, 3, 10, -1], [0, 2, 3, 10]],
        }
        defaults_b = {2: [5, 4], 3: [6, 7, 8], 4: [6, 7, 8, 9]}

        self.matrix_entries = []
        self.b_entries = []

        for i in range(n):
            row_e = []
            ctk.CTkLabel(grid, text=f"Ec.{i+1}", width=32,
                         text_color=t["text_secondary"], font=ctk.CTkFont(size=11)
                         ).grid(row=i+1, column=0, padx=3, pady=3)
            for j in range(n):
                e = ctk.CTkEntry(grid, width=76, fg_color=t["bg_input"],
                                 border_color=t["border"], text_color=t["text_primary"],
                                 font=ctk.CTkFont(size=12))
                e.grid(row=i+1, column=j+1, padx=3, pady=3)
                e.insert(0, str(defaults_A[n][i][j]))
                row_e.append(e)
            self.matrix_entries.append(row_e)

            be = ctk.CTkEntry(grid, width=76, fg_color=t["bg_input"],
                              border_color=t["border"], text_color=t["accent2"],
                              font=ctk.CTkFont(size=12, weight="bold"))
            be.grid(row=i+1, column=n+1, padx=3, pady=3)
            be.insert(0, str(defaults_b[n][i]))
            self.b_entries.append(be)

    def _on_method_change(self):
        if self.method_var.get() == "Gauss-Seidel":
            self.gs_frame.pack(fill="x", pady=(0, 4))
        else:
            self.gs_frame.pack_forget()
        self._rebuild_ejemplos()

    def _get_matrix(self):
        n = self.n_vars
        A, b = [], []
        for i in range(n):
            row = [safe_float(self.matrix_entries[i][j].get()) for j in range(n)]
            if None in row:
                raise ValueError(f"Fila {i+1} tiene valores inválidos")
            A.append(row)
            bv = safe_float(self.b_entries[i].get())
            if bv is None:
                raise ValueError(f"b[{i+1}] inválido")
            b.append(bv)
        return A, b

    def _calcular(self):
        t = self.t
        try:
            A, b = self._get_matrix()
            method = self.method_var.get()

            if method == "Gauss-Seidel":
                tol    = safe_float(self.entry_tol.get())   or 1e-6
                max_it = safe_int(self.entry_maxit.get())   or 100
                result = gauss_seidel(A, b, tol=tol, max_iter=max_it)
                # Actualizar headers de tabla según dimensión
                n = self.n_vars
                hdrs = ["n"] + [f"x{i+1}" for i in range(n)] + ["Error máx."]
                self.tabla.columns = hdrs
                self.tabla.update_data(result["tabla"])
            else:
                result = factorizacion_lu(A, b)
                # Mostrar L y U concatenadas
                n = self.n_vars
                L = result["L"]; U = result["U"]
                hdrs = [f"L_col{j+1}" for j in range(n)] + [f"U_col{j+1}" for j in range(n)]
                rows = [list(L[i]) + list(U[i]) for i in range(n)]
                self.tabla.columns = hdrs
                self.tabla.update_data(rows)

            self._last_result = result
            self._last_result["metodo"] = method

            sol = result["solucion"]
            sol_str = "  |  ".join([f"x{i+1} = {v:.8g}" for i, v in enumerate(sol)])
            self.resultado_box.set_result(f"✅ Solución:  {sol_str}")
            self.proc_box.set_text(result["procedimiento"])

        except Exception as exc:
            self.resultado_box.set_result(f"❌ Error: {exc}", color=t["accent3"])

    def _limpiar(self):
        self._rebuild_matrix()
        self.resultado_box.set_result("—")
        self.tabla.update_data([])
        self.proc_box.set_text("")
        self._last_result = None

    def _exportar(self):
        if self._last_result is None:
            self.resultado_box.set_result("⚠️ Calcule primero", color=self.t["accent3"]); return
        if self.export_callback:
            self.export_callback(self._last_result, None, "Sistemas de Ecuaciones")
