"""
Utilidades: validación de datos y helpers matemáticos
"""
import numpy as np
import sympy as sp


def parse_function(expr_str: str):
    """
    Convierte un string a función Python usando sympy.
    Devuelve (func_callable, expr_sympy, error_str).
    """
    try:
        x = sp.Symbol("x")
        expr = sp.sympify(expr_str, locals={"x": x, "e": sp.E, "pi": sp.pi})
        func = sp.lambdify(x, expr, modules=["numpy"])
        return func, expr, None
    except Exception as e:
        return None, None, str(e)


def parse_function_xy(expr_str: str):
    """
    Función f(x, y) para EDOs.
    """
    try:
        x, y = sp.symbols("x y")
        expr = sp.sympify(expr_str, locals={"x": x, "y": y, "e": sp.E, "pi": sp.pi})
        func = sp.lambdify((x, y), expr, modules=["numpy"])
        return func, expr, None
    except Exception as e:
        return None, None, str(e)


def safe_float(value_str: str, default=None):
    """Convierte string a float de forma segura."""
    try:
        return float(value_str.strip().replace(",", "."))
    except (ValueError, AttributeError):
        return default


def safe_int(value_str: str, default=None):
    """Convierte string a int de forma segura."""
    try:
        return int(value_str.strip())
    except (ValueError, AttributeError):
        return default


def validate_interval(a, b):
    """Verifica que a < b."""
    return a is not None and b is not None and a < b


def validate_positive(val):
    return val is not None and val > 0


def format_number(val, decimals=10):
    """Formatea un número con precisión."""
    if isinstance(val, (int, np.integer)):
        return str(val)
    try:
        return f"{val:.{decimals}g}"
    except Exception:
        return str(val)


def relative_error(new, old):
    """Error relativo porcentual."""
    if old == 0:
        return float("inf")
    return abs((new - old) / old) * 100


def absolute_error(new, old):
    """Error absoluto."""
    return abs(new - old)
