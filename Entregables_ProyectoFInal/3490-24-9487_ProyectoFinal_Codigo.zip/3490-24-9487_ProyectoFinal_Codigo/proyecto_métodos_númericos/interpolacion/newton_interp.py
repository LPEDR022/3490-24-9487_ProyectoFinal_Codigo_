"""
Interpolación de Newton – Diferencias Divididas
Procedimiento detallado paso a paso
"""
import numpy as np


def _fmt(v):
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    if isinstance(v, (int, float)):
        return f"{v:g}"
    return str(v)


def newton_interpolacion(xs, ys, x_eval=None):
    """
    Polinomio de Newton usando Diferencias Divididas.
    Procedimiento paso a paso con tabla completa.
    """
    n   = len(xs)
    g   = n - 1
    lns = []

    nombre_grado = {1: "Lineal", 2: "Cuadrático", 3: "Cúbico",
                    4: "Cuártico", 5: "Quíntico"}.get(g, f"Grado {g}")

    # ── Tabla de diferencias divididas ──────────────────────────────────────
    dd = np.zeros((n, n))
    dd[:, 0] = ys

    for j in range(1, n):
        for i in range(n - j):
            dd[i, j] = (dd[i+1, j-1] - dd[i, j-1]) / (xs[i+j] - xs[i])

    coefs = dd[0, :]

    # ═══════════════════════════════════════════════════════════
    lns += [
        "=" * 62,
        "   INTERPOLACIÓN DE NEWTON  (Diferencias Divididas)",
        "=" * 62,
        "",
        f"   Número de puntos (n+1) : {n}   →   n = {g}",
        f"   Grado del polinomio    : {g}  ({nombre_grado})",
        "",
    ]

    # ── PASO 1: tabla de puntos ──────────────────────────────────────────────
    lns += [
        "─" * 62,
        "  PASO 1 │ Identificar los puntos dados",
        "─" * 62,
        "",
        f"   {'i':>3}   {'x_i':>10}   {'y_i  =  f[x_i]':>18}",
        f"   {'─'*3}   {'─'*10}   {'─'*18}",
    ]
    for i, (xi, yi) in enumerate(zip(xs, ys)):
        lns.append(f"   {i:>3}   {_fmt(xi):>10}   {_fmt(yi):>18}")
    lns.append("")

    # ── PASO 2: fórmula general ──────────────────────────────────────────────
    lns += [
        "─" * 62,
        "  PASO 2 │ Fórmula General de Newton",
        "─" * 62,
        "",
        "   P(x) = b₀  +  b₁(x-x₀)  +  b₂(x-x₀)(x-x₁)  +  …",
        "",
        "   Donde los coeficientes bₖ son las diferencias divididas:",
        "   b₀ = f[x₀]",
        "   b₁ = f[x₀, x₁]",
        "   b₂ = f[x₀, x₁, x₂]",
        "   …",
        "",
        "   Diferencia dividida de orden k:",
        "   f[xᵢ, …, xᵢ₊ₖ] = (f[xᵢ₊₁,…,xᵢ₊ₖ] - f[xᵢ,…,xᵢ₊ₖ₋₁]) / (xᵢ₊ₖ - xᵢ)",
        "",
    ]

    # ── PASO 3: construir tabla de diferencias divididas ─────────────────────
    lns += [
        "─" * 62,
        "  PASO 3 │ Tabla de Diferencias Divididas",
        "─" * 62,
        "",
    ]

    # Cabecera de la tabla
    header = f"   {'i':>3} │ {'xᵢ':>8} │ {'f[xᵢ]':>10}"
    for j in range(1, n):
        header += f" │ {'Orden '+str(j):>12}"
    lns.append(header)
    lns.append("   " + "─" * (len(header) - 3))

    for i in range(n):
        row = f"   {i:>3} │ {_fmt(xs[i]):>8} │ {_fmt(ys[i]):>10}"
        for j in range(1, n):
            if i + j < n:
                row += f" │ {dd[i,j]:>12.6g}"
            else:
                row += f" │ {'':>12}"
        lns.append(row)
    lns.append("")

    # ── Cálculo detallado de cada diferencia ──────────────────────────────
    lns += [
        "─" * 62,
        "  PASO 4 │ Cálculo Detallado de las Diferencias",
        "─" * 62,
        "",
    ]
    for j in range(1, n):
        lns.append(f"  ── Orden {j} ──────────────────────────────────────────")
        for i in range(n - j):
            num = dd[i+1, j-1] - dd[i, j-1]
            den = xs[i+j] - xs[i]
            lns += [
                f"   f[x_{i},...,x_{i+j}]",
                f"     = (f[x_{i+1},...,x_{i+j}]  -  f[x_{i},...,x_{i+j-1}]) / (x_{i+j} - x_{i})",
                f"     = ({dd[i+1,j-1]:.8g}  -  {dd[i,j-1]:.8g}) / ({_fmt(xs[i+j])} - {_fmt(xs[i])})",
                f"     = {num:.8g} / {den:.8g}",
                f"     = {dd[i,j]:.8g}",
                "",
            ]

    # ── PASO 5: coeficientes ─────────────────────────────────────────────────
    lns += [
        "─" * 62,
        "  PASO 5 │ Coeficientes del Polinomio de Newton",
        "─" * 62,
        "",
        "   (Primera fila diagonal de la tabla de diferencias divididas)",
        "",
    ]
    for k in range(n):
        if k == 0:
            lns.append(f"   b₀ = f[x₀]          = {coefs[k]:.10g}")
        else:
            xs_label = ",".join([f"x_{j}" for j in range(k+1)])
            lns.append(f"   b{k} = f[{xs_label}]  = {coefs[k]:.10g}")
    lns.append("")

    # ── PASO 6: forma del polinomio ──────────────────────────────────────────
    lns += [
        "─" * 62,
        "  PASO 6 │ Polinomio de Newton (Forma Factorizada)",
        "─" * 62,
        "",
        "   P(x) =",
    ]
    terms = [f"   {coefs[0]:.6g}"]
    for i in range(1, n):
        xterms = " · ".join([f"(x - {_fmt(xs[j])})" for j in range(i)])
        sign = "+" if coefs[i] >= 0 else ""
        terms.append(f"   {sign}{coefs[i]:.6g} · {xterms}")
    lns.append("\n".join(terms))
    lns.append("")

    # Forma expandida aproximada
    coef_total = np.zeros(n)
    p_acc = np.array([1.0])
    for k in range(n):
        if k == 0:
            coef_total[0] += coefs[0]
        else:
            p_acc = np.polymul(p_acc, [1.0, -xs[k-1]])
            p_rev = p_acc[::-1]
            for d, c in enumerate(p_rev):
                if d < n:
                    coef_total[d] += coefs[k] * c

    terms_exp = []
    for k in range(n-1, -1, -1):
        c = coef_total[k]
        if abs(c) < 1e-12:
            continue
        c_str = f"{c:.6g}"
        if k == 0:
            terms_exp.append(c_str)
        elif k == 1:
            terms_exp.append(f"{c_str}x")
        else:
            terms_exp.append(f"{c_str}x^{k}")
    polinomio_str = " + ".join(terms_exp).replace("+ -", "- ") if terms_exp else "0"

    lns += [
        "─" * 62,
        "  PASO 7 │ Polinomio Resultante (Forma Expandida)",
        "─" * 62,
        "",
        f"   P_{g}(x) = {polinomio_str}",
        "",
    ]

    # Función del polinomio
    def P(x_val):
        result = coefs[0]
        prod = 1.0
        for i in range(1, n):
            prod *= (x_val - xs[i-1])
            result += coefs[i] * prod
        return result

    # ── Evaluación ───────────────────────────────────────────────────────────
    eval_result = None
    if x_eval is not None:
        eval_result = P(x_eval)
        lns += [
            "═" * 62,
            f"  EVALUACIÓN  →  x = {_fmt(x_eval)}",
            "═" * 62,
            "",
            "   Aplicando el polinomio de Newton:",
            "",
        ]
        result = coefs[0]
        lns.append(f"   Término 0:  b₀ = {coefs[0]:.8g}")
        prod = 1.0
        for i in range(1, n):
            prod *= (x_eval - xs[i-1])
            term = coefs[i] * prod
            result += term
            xp = " · ".join([f"({_fmt(x_eval)} - {_fmt(xs[j])})" for j in range(i)])
            lns += [
                f"   Término {i}:  b{i} · {xp}",
                f"           =  {coefs[i]:.6g} × {prod:.6g}  =  {term:.8g}",
                f"           →  acumulado = {result:.8g}",
                "",
            ]
        lns += [
            f"   P_{g}({_fmt(x_eval)}) = {eval_result:.10g}",
            "",
        ]

    lns += [
        "═" * 62,
        "  RESULTADO FINAL",
        "═" * 62,
        f"   Grado del polinomio : {g}  ({nombre_grado})",
        f"   P_{g}(x) = {polinomio_str}",
    ]
    if eval_result is not None:
        lns.append(f"   P_{g}({_fmt(x_eval)}) ≈ {eval_result:.10g}")
    lns.append("═" * 62)

    # Tabla para IterationTable
    tabla_dd = []
    for i in range(n):
        row = [i, _fmt(xs[i]), _fmt(ys[i])]
        for j in range(1, n):
            row.append(f"{dd[i,j]:.6g}" if i + j < n else "─")
        tabla_dd.append(row)

    headers = ["i", "xᵢ", "f[xᵢ]"] + [f"Orden {j}" for j in range(1, n)]

    return {
        "polinomio":           P,
        "coeficientes":        coefs,
        "eval_result":         eval_result,
        "tabla_headers":       headers,
        "tabla":               tabla_dd,
        "procedimiento":       "\n".join(lns),
        "n_puntos":            n,
        "grado":               g,
        "nombre_grado":        nombre_grado,
        "polinomio_expandido": polinomio_str,
    }
