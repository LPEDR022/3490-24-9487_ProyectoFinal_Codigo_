"""
Vista del Módulo de Interpolación
  · Lagrange  : sin campo "evaluar en x", ejemplos Ej.1/Ej.2/Ej.3 del PDF,
                fórmulas propias, gráfica animada automática.
  · Newton    : con campo "evaluar en x", ejemplos propios, fórmulas propias.
  El encabezado (banner) cambia al seleccionar cada método.
"""
import tkinter as tk
import customtkinter as ctk
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.animation import FuncAnimation

from ui.themes import get_theme
from ui.components import (
    themed_frame, section_label, primary_button, danger_button, success_button,
    IterationTable, ProcedimientoBox, ResultadoBox, ModuleBanner,
)
from ui.ayuda_formulas import AyudaFormulasDialog
from interpolacion.lagrange import lagrange
from interpolacion.newton_interp import newton_interpolacion
from utils.validators import safe_float


# ─────────────────────────────────────────────────────────────────────────────
#  DATOS: ejemplos y fórmulas por método
# ─────────────────────────────────────────────────────────────────────────────

# Solo los 3 del PDF para Lagrange
EJEMPLOS_LAGRANGE = [
    {
        "nombre": "📗 Ej.1 – Lineal",
        "puntos": "1, 3\n2, 7",
        "desc": "Interpolación Lineal · grado 1 · puntos (1,3) y (2,7)",
    },
    {
        "nombre": "📘 Ej.2 – Cuadrático",
        "puntos": "0, 1\n1, 3\n2, 1",
        "desc": "Interpolación Cuadrática · grado 2 · puntos (0,1)(1,3)(2,1)",
    },
    {
        "nombre": "📙 Ej.3 – Cúbico (tarea)",
        "puntos": "1, 3\n2, 1\n4, 1\n5, -2",
        "desc": "Grado 3 · n+1=4 puntos · ejercicio del PDF de tarea",
    },
]

EJEMPLOS_NEWTON = [
    {
        "nombre": "📗 Lineal",
        "puntos": "1, 3\n2, 7",
        "xeval": "1.5",
        "desc": "Newton Lineal · P(1.5) = ?",
    },
    {
        "nombre": "📘 Cuadrático",
        "puntos": "0, 1\n1, 3\n2, 1",
        "xeval": "1.5",
        "desc": "Newton Cuadrático · P(1.5) = ?",
    },
    {
        "nombre": "📙 e^x en [0,3]",
        "puntos": "0, 1\n1, 2.71828\n2, 7.38906\n3, 20.0855",
        "xeval": "1.5",
        "desc": "Newton cúbico · e^x · P(1.5) ≈ 4.4817",
    },
    {
        "nombre": "🌡️ Temperatura",
        "puntos": "0, 20\n1, 22\n2, 27\n3, 35\n4, 30",
        "xeval": "2.5",
        "desc": "Newton grado 4 · datos de temperatura",
    },
]

# Fórmulas mostradas en el panel lateral de cada método

# Nombre del encabezado y subtítulo por método
BANNER_INFO = {
    "Lagrange": {
        "title":    "Interpolación con el Polinomio de Lagrange",
        "subtitle": "Método de Lagrange  ·  Procedimiento paso a paso",
        "icon":     "📈",
    },
    "Newton": {
        "title":    "Interpolación de Newton  (Diferencias Divididas)",
        "subtitle": "Método de Newton  ·  Tabla de diferencias divididas",
        "icon":     "📊",
    },
}

GRADO_NOMBRE = {1: "Lineal", 2: "Cuadrático", 3: "Cúbico",
                4: "Cuártico", 5: "Quíntico"}

BADGE_COLORS = {
    1: ("#1F6FEB", "#fff"),
    2: ("#2EA043", "#fff"),
    3: ("#9E6EFF", "#fff"),
    4: ("#D29922", "#fff"),
    5: ("#F78166", "#fff"),
}


# ─────────────────────────────────────────────────────────────────────────────
#  GRÁFICA ANIMADA
# ─────────────────────────────────────────────────────────────────────────────

class AnimatedGraphFrame(ctk.CTkFrame):
    """Gráfica matplotlib con animación automática al recibir nuevos datos."""

    def __init__(self, parent, **kwargs):
        t = get_theme()
        kwargs.setdefault("fg_color", t["bg_card"])
        kwargs.setdefault("corner_radius", 14)
        super().__init__(parent, **kwargs)
        self.t = t
        self._anim = None

        self.fig = plt.Figure(figsize=(8, 3.4), facecolor=t["graph_bg"])
        self.ax  = self.fig.add_subplot(111)
        self._style_ax()

        self.canvas = FigureCanvasTkAgg(self.fig, master=self)
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=(6, 2))

        tb_frame = tk.Frame(self, bg=t["bg_card"])
        tb_frame.pack(fill="x", padx=6, pady=(0, 4))
        tb = NavigationToolbar2Tk(self.canvas, tb_frame)
        tb.config(bg=t["bg_card"])
        tb.update()

    def _style_ax(self):
        t = self.t
        self.ax.set_facecolor(t["graph_bg"])
        self.ax.tick_params(colors=t["graph_fg"], labelsize=9)
        self.ax.xaxis.label.set_color(t["graph_fg"])
        self.ax.yaxis.label.set_color(t["graph_fg"])
        self.ax.title.set_color(t["graph_fg"])
        for sp in self.ax.spines.values():
            sp.set_color(t["border"])
        self.ax.grid(True, color=t["graph_grid"],
                     linestyle="--", linewidth=0.5, alpha=0.5)

    def clear(self):
        if self._anim is not None:
            try:
                self._anim.event_source.stop()
            except Exception:
                pass
            self._anim = None
        self.ax.cla()
        self._style_ax()
        self.canvas.draw()

    def plot_animated(self, xs, ys, P, x_eval, ev, grado, method):
        """Dibuja la curva con animación automática de izquierda a derecha."""
        self.clear()
        t      = self.t
        colors = t["graph_colors"]

        margin  = max((max(xs) - min(xs)) * 0.5, 0.5)
        xi_full = np.linspace(min(xs) - margin, max(xs) + margin, 500)
        yi_full = np.vectorize(P)(xi_full)

        # Puntos dados (estáticos desde el inicio)
        self.ax.scatter(xs, ys, color=colors[2], zorder=5, s=70,
                        label="Puntos dados",
                        edgecolors=t["text_primary"], linewidths=0.7)

        # Punto evaluado
        if x_eval is not None and ev is not None:
            self.ax.scatter([x_eval], [ev],
                            color=colors[1], zorder=7, s=120, marker="*",
                            label=f"P({x_eval}) = {ev:.4g}")

        nombre_g = GRADO_NOMBRE.get(grado, f"Grado {grado}")
        self.ax.set_title(
            f"{method}  –  Grado {grado} ({nombre_g})  ·  {len(xs)} puntos",
            color=t["graph_fg"], fontsize=11, fontweight="bold", pad=8,
        )
        self.ax.set_xlabel("x",    color=t["graph_fg"], fontsize=10)
        self.ax.set_ylabel("P(x)", color=t["graph_fg"], fontsize=10)

        y_rng = max(yi_full) - min(yi_full)
        pad_y = y_rng * 0.12 if y_rng > 0 else 1
        self.ax.set_ylim(min(yi_full) - pad_y, max(yi_full) + pad_y)
        self.ax.set_xlim(xi_full[0], xi_full[-1])

        line, = self.ax.plot([], [], color=colors[0], linewidth=2.2,
                             label=f"Polinomio interpolante")
        self.ax.legend(facecolor=t["bg_card"], edgecolor=t["border"],
                       labelcolor=t["text_primary"], fontsize=9)

        N      = 60
        frames = [xi_full[:max(2, int(len(xi_full) * k / N))]
                  for k in range(1, N + 1)]
        yframes= [yi_full[:max(2, int(len(yi_full) * k / N))]
                  for k in range(1, N + 1)]

        def update(frame):
            line.set_data(frames[frame], yframes[frame])
            return (line,)

        self._anim = FuncAnimation(
            self.fig, update, frames=N,
            interval=18, blit=True, repeat=False,
        )
        self.canvas.draw()


# ─────────────────────────────────────────────────────────────────────────────
#  VISTA PRINCIPAL
# ─────────────────────────────────────────────────────────────────────────────

class InterpolacionView(ctk.CTkFrame):

    def __init__(self, parent, export_callback=None):
        t = get_theme()
        super().__init__(parent, fg_color=t["bg_main"], corner_radius=0)
        self.t               = t
        self.export_callback = export_callback
        self._last_result    = None
        self._last_fig       = None
        self._ayuda_win      = None
        self._build()

    # ── Construcción de la UI ─────────────────────────────────────────────────
    def _build(self):
        t = self.t

        # ── Banner dinámico (contenedor que se actualiza) ──────────────────
        self._banner_cont = ctk.CTkFrame(self, fg_color=get_theme()["bg_card"],
                                         corner_radius=10)
        self._banner_cont.pack(fill="x", padx=12, pady=(6, 3))
        # Barra lateral de acento
        _bar = ctk.CTkFrame(self._banner_cont, width=4,
                            fg_color=get_theme()["accent"], corner_radius=2)
        _bar.pack(side="left", fill="y", padx=(14, 12), pady=8)
        _col = ctk.CTkFrame(self._banner_cont, fg_color="transparent")
        _col.pack(side="left", fill="x", expand=True)
        _row = ctk.CTkFrame(_col, fg_color="transparent")
        _row.pack(fill="x")
        self._banner_icon  = ctk.CTkLabel(_row, text="📈",
                                          font=ctk.CTkFont(size=18))
        self._banner_icon.pack(side="left", padx=(0, 8))
        self._banner_title = ctk.CTkLabel(_row,
                                          text=BANNER_INFO["Lagrange"]["title"],
                                          font=ctk.CTkFont(size=15, weight="bold"),
                                          text_color=get_theme()["text_primary"],
                                          anchor="w")
        self._banner_title.pack(side="left", fill="x")
        self._banner_sub   = ctk.CTkLabel(_col,
                                          text=BANNER_INFO["Lagrange"]["subtitle"],
                                          font=ctk.CTkFont(size=10),
                                          text_color=get_theme()["text_secondary"],
                                          anchor="w")
        self._banner_sub.pack(anchor="w", padx=(0, 4))

        scroll = ctk.CTkScrollableFrame(self, fg_color=t["bg_main"])
        scroll.pack(fill="both", expand=True, padx=12, pady=3)
        self._scroll = scroll

        # ── Selector de método ───────────────────────────────────────────────
        mf = themed_frame(scroll)
        mf.pack(fill="x", pady=(0, 6))
        section_label(mf, "Método:").pack(side="left", padx=12, pady=8)
        self.method_var = ctk.StringVar(value="Lagrange")
        for m in ["Lagrange", "Newton"]:
            ctk.CTkRadioButton(
                mf, text=m, value=m,
                variable=self.method_var,
                text_color=t["text_primary"],
                fg_color=t["accent"],
                font=ctk.CTkFont(size=13),
                radiobutton_width=18, radiobutton_height=18,
                command=self._on_method_change,
            ).pack(side="left", padx=14)


        # ── Ejemplos (contenedor dinámico) ──────────────────────────────────
        self._ej_outer = themed_frame(scroll)
        self._ej_outer.pack(fill="x", pady=(0, 6))

        # ── Puntos ──────────────────────────────────────────────────────────
        pts = themed_frame(scroll)
        pts.pack(fill="x", pady=(0, 4))

        top_row = ctk.CTkFrame(pts, fg_color="transparent")
        top_row.pack(fill="x", padx=14, pady=(10, 0))
        section_label(top_row,
                      "📌 Puntos  (formato: x, y — uno por línea)").pack(side="left")
        ctk.CTkButton(
            top_row, text="❓ Ayuda", width=80, height=26,
            fg_color=t["accent2"], hover_color=t["accent"],
            text_color="#fff", corner_radius=6, font=ctk.CTkFont(size=11),
            command=self._abrir_ayuda,
        ).pack(side="right", padx=4)

        self.points_text = ctk.CTkTextbox(
            pts, height=90, fg_color=t["bg_input"],
            text_color=t["text_primary"], border_color=t["border"],
            font=ctk.CTkFont(family="Courier New", size=12),
        )
        self.points_text.pack(fill="x", padx=12, pady=6)
        self.points_text.insert("0.0", "1, 3\n2, 7")

        # Campo "evaluar en x" — solo visible para Newton
        self._eval_frame = ctk.CTkFrame(pts, fg_color="transparent")
        self._eval_frame.pack(anchor="w", padx=8, pady=(0, 4))
        ctk.CTkLabel(
            self._eval_frame, text="Evaluar en x =",
            text_color=t["text_secondary"], font=ctk.CTkFont(size=12),
        ).pack(side="left", padx=(0, 6))
        self.entry_xeval = ctk.CTkEntry(
            self._eval_frame, placeholder_text="ej: 1.5", width=130,
            fg_color=t["bg_input"], border_color=t["border"],
            text_color=t["text_primary"], font=ctk.CTkFont(size=12),
        )
        self.entry_xeval.pack(side="left")

        # Botones
        btn_row = ctk.CTkFrame(pts, fg_color="transparent")
        btn_row.pack(anchor="w", padx=8, pady=(2, 8))
        primary_button(btn_row, "▶  Calcular",     self._calcular,  width=150).pack(side="left", padx=4)
        danger_button (btn_row, "🗑  Limpiar",      self._limpiar,   width=120).pack(side="left", padx=4)
        success_button(btn_row, "📄  Exportar PDF", self._exportar,  width=160).pack(side="left", padx=4)

        # ── Resultado + badge ────────────────────────────────────────────────
        res_header = ctk.CTkFrame(scroll, fg_color="transparent")
        res_header.pack(fill="x", pady=(5, 1))
        section_label(res_header, "✅ Resultado").pack(side="left")
        self._badge_frame = ctk.CTkFrame(res_header, fg_color="transparent")
        self._badge_frame.pack(side="left", padx=12)

        self.resultado_box = ResultadoBox(scroll)
        self.resultado_box.pack(fill="x", pady=(0, 4))

        # ── Contenedor de tablas (mantiene el orden en el scroll) ────────────
        self._tablas_cont = ctk.CTkFrame(scroll, fg_color="transparent")
        self._tablas_cont.pack(fill="x", pady=(0, 4))

        # Tabla de puntos (solo Lagrange)
        self._lbl_tabla_pts = section_label(self._tablas_cont, "📊 Tabla de Puntos  —  Lagrange")
        self._lbl_tabla_pts.pack(anchor="w", pady=(3, 1))
        self.tabla_puntos = IterationTable(
            self._tablas_cont, columns=["i", "xᵢ", "yᵢ", "Polinomio de Lagrange"]
        )
        self.tabla_puntos.pack(fill="x", pady=(0, 4))

        # Tabla diferencias divididas (solo Newton) — oculta al inicio
        self._lbl_tabla_met = section_label(self._tablas_cont, "📊 Tabla de Diferencias Divididas  —  Newton")
        self.tabla_poly = IterationTable(
            self._tablas_cont, columns=["i", "xᵢ", "f[xᵢ]", "Orden 1"]
        )

        # ── Procedimiento ────────────────────────────────────────────────────
        section_label(scroll, "🧾 Procedimiento Paso a Paso").pack(anchor="w", pady=(3, 1))
        self.proc_box = ProcedimientoBox(scroll)
        self.proc_box.pack(fill="x", pady=(0, 3))
        self.proc_box.configure(height=320)

        # ── Gráfica animada ──────────────────────────────────────────────────
        section_label(scroll, "📉 Gráfica — Animación Automática").pack(anchor="w", pady=(3, 1))
        self.graph = AnimatedGraphFrame(scroll)
        self.graph.pack(fill="x", pady=(0, 12))

        # Inicializar con Lagrange
        self._on_method_change()

    # ── Cambio de método ──────────────────────────────────────────────────────
    def _on_method_change(self):
        method = self.method_var.get()

        # 1. Actualizar banner (sin recrear widgets)
        info = BANNER_INFO[method]
        self._banner_icon.configure(text=info["icon"])
        self._banner_title.configure(text=info["title"])
        self._banner_sub.configure(text=info["subtitle"])


        # 3. Reconstruir ejemplos
        for w in self._ej_outer.winfo_children():
            w.destroy()

        ejemplos = EJEMPLOS_LAGRANGE if method == "Lagrange" else EJEMPLOS_NEWTON
        ej_lbl = section_label(self._ej_outer,
                               f"📂 Ejemplos – {method}:")
        ej_lbl.pack(anchor="w", padx=12, pady=(8, 4))

        ej_grid = ctk.CTkFrame(self._ej_outer, fg_color="transparent")
        ej_grid.pack(fill="x", padx=10, pady=(0, 8))
        t = self.t

        for idx, ej in enumerate(ejemplos):
            col = idx % 3
            row = idx // 3
            card = ctk.CTkFrame(
                ej_grid,
                fg_color=t["bg_input"],
                corner_radius=10,
                border_width=1,
                border_color=t["border"],
            )
            card.grid(row=row, column=col, padx=5, pady=4, sticky="ew")
            ej_grid.columnconfigure(col, weight=1)

            ctk.CTkLabel(
                card, text=ej["nombre"],
                text_color=t["text_primary"],
                font=ctk.CTkFont(size=11, weight="bold"),
                anchor="w",
            ).pack(anchor="w", padx=10, pady=(7, 0))

            ctk.CTkLabel(
                card, text=ej["desc"],
                text_color=t["text_secondary"],
                font=ctk.CTkFont(size=9),
                anchor="w", wraplength=200,
            ).pack(anchor="w", padx=10, pady=(1, 4))

            ctk.CTkButton(
                card, text="▶ Cargar",
                width=90, height=26,
                fg_color=t["accent"], hover_color=t["accent_hover"],
                text_color="#fff", corner_radius=7,
                font=ctk.CTkFont(size=11),
                command=lambda e=ej: self._cargar_ejemplo(e),
            ).pack(anchor="w", padx=10, pady=(0, 8))

        # 4. Mostrar/ocultar campo "evaluar en x"
        if method == "Lagrange":
            self._eval_frame.pack_forget()
        else:
            self._eval_frame.pack(anchor="w", padx=8, pady=(0, 4))

        # 5. Mostrar/ocultar tablas según el método
        if method == "Lagrange":
            # Lagrange: mostrar tabla de puntos, ocultar tabla de Newton
            self._lbl_tabla_pts.pack(anchor="w", pady=(3, 1))
            self.tabla_puntos.pack(fill="x", pady=(0, 4))
            self._lbl_tabla_met.pack_forget()
            self.tabla_poly.pack_forget()
        else:
            # Newton: ocultar tabla de puntos, mostrar solo tabla de diferencias divididas
            self._lbl_tabla_pts.pack_forget()
            self.tabla_puntos.pack_forget()
            self._lbl_tabla_met.pack(anchor="w", pady=(3, 1))
            self.tabla_poly.pack(fill="x", pady=(0, 4))

        # 6. Limpiar resultados anteriores
        self._limpiar_resultados()

    # ── Limpiar solo resultados (no los campos de entrada) ────────────────────
    def _limpiar_resultados(self):
        self.resultado_box.set_result("—")
        self.tabla_puntos.update_data([])
        self.tabla_poly.update_data([])
        self.proc_box.set_text("")
        self.graph.clear()
        self._last_result = None
        for w in self._badge_frame.winfo_children():
            w.destroy()

    # ── Cargar ejemplo ────────────────────────────────────────────────────────
    def _cargar_ejemplo(self, ej):
        self.points_text.delete("0.0", "end")
        self.points_text.insert("0.0", ej["puntos"])
        if "xeval" in ej:
            self.entry_xeval.delete(0, "end")
            self.entry_xeval.insert(0, ej["xeval"])
        self.after(80, self._calcular)

    # ── Ayuda ─────────────────────────────────────────────────────────────────
    def _abrir_ayuda(self):
        try:
            if self._ayuda_win is not None and self._ayuda_win.winfo_exists():
                self._ayuda_win.deiconify(); self._ayuda_win.lift()
                self._ayuda_win.focus_force(); return
        except Exception:
            pass
        self._ayuda_win = AyudaFormulasDialog(self, on_insert=self._on_insert,
                                               modulo="interpolacion", metodo=self.method_var.get())
        self._ayuda_win.protocol("WM_DELETE_WINDOW", self._cerrar_ayuda)

    def _cerrar_ayuda(self):
        try:
            if self._ayuda_win: self._ayuda_win.destroy()
        except Exception:
            pass
        self._ayuda_win = None

    def _on_insert(self, text):
        try:
            self.points_text.insert("insert", text)
        except Exception:
            cur = self.points_text.get("0.0", "end").strip()
            self.points_text.delete("0.0", "end")
            self.points_text.insert("0.0", (cur + "\n" + text).strip())

    # ── Parsear puntos ────────────────────────────────────────────────────────
    def _parse_points(self):
        text = self.points_text.get("0.0", "end").strip()
        xs, ys = [], []
        for line in text.replace(";", "\n").split("\n"):
            line = line.strip()
            if not line:
                continue
            parts = line.replace(",", " ").split()
            if len(parts) >= 2:
                x = safe_float(parts[0]); y = safe_float(parts[1])
                if x is not None and y is not None:
                    xs.append(x); ys.append(y)
        return xs, ys

    # ── Calcular ──────────────────────────────────────────────────────────────
    def _calcular(self):
        t = self.t
        xs, ys = self._parse_points()
        if len(xs) < 2:
            self.resultado_box.set_result(
                "⚠️ Ingrese al menos 2 puntos.", color=t["accent3"])
            return

        method  = self.method_var.get()
        x_eval  = None
        if method == "Newton":
            xv = self.entry_xeval.get().strip()
            if xv:
                x_eval = safe_float(xv)
                if x_eval is None:
                    self.resultado_box.set_result(
                        "⚠️ El valor de 'Evaluar en x' no es válido. Ingrese un número (ej: 1.5).",
                        color=t["accent3"])
                    return
            # x_eval puede quedar None si el campo está vacío (se calcula el polinomio sin evaluar)

        try:
            if method == "Lagrange":
                result = lagrange(xs, ys, x_eval=None)   # Lagrange no evalúa en x
            else:
                result = newton_interpolacion(xs, ys, x_eval)

            grado     = result.get("grado", len(xs) - 1)
            nombre_g  = GRADO_NOMBRE.get(grado, f"Grado {grado}")
            self._last_result = {**result, "metodo": method, "xs": xs, "ys": ys}

            # Badge de grado
            for w in self._badge_frame.winfo_children():
                w.destroy()
            fg_badge, txt_badge = BADGE_COLORS.get(grado, ("#8B949E", "#fff"))
            ctk.CTkLabel(
                self._badge_frame,
                text=f"  Grado {grado} – {nombre_g}  ",
                fg_color=fg_badge, text_color=txt_badge,
                corner_radius=8, font=ctk.CTkFont(size=12, weight="bold"),
            ).pack(side="left")

            # Resultado
            ev  = result.get("eval_result")
            if method == "Lagrange":
                nombre_g  = GRADO_NOMBRE.get(grado, f"Grado {grado}")
                msg = (f"Método: Lagrange  |  {len(xs)} puntos  |  "
                       f"Grado {grado} ({nombre_g})")
                # Lagrange: tabla de puntos con Lᵢ(x) — columnas: i, xᵢ, yᵢ, Lᵢ(x)
                self.tabla_puntos.update_data(
                    result["tabla"],
                    new_columns=["i", "xᵢ", "yᵢ", "Lᵢ(x)  (Polinomio base de Lagrange)"]
                )
                # tabla de diferencias divididas vacía (no aplica a Lagrange)
                self.tabla_poly.update_data([])
            else:
                nombre_g  = GRADO_NOMBRE.get(grado, f"Grado {grado}")
                msg = (f"Método: Newton (Dif. Divididas)  |  {len(xs)} puntos  |  "
                       f"Grado {grado} ({nombre_g})")
                if ev is not None:
                    msg += f"  |  P({x_eval}) = {ev:.10g}"
                # Newton: llenar solo tabla de diferencias divididas con columnas correctas
                self.tabla_puntos.update_data([])
                headers_dd = result.get("tabla_headers",
                    ["i", "xᵢ", "f[xᵢ]"] + [f"Orden {j}" for j in range(1, len(xs))])
                self.tabla_poly.update_data(result["tabla"], new_columns=headers_dd)

            if method == "Lagrange" and ev is None:
                pass  # ya formado arriba
            elif method == "Lagrange":
                msg += f"  |  P({x_eval}) = {ev:.10g}" if ev is not None else ""

            self.resultado_box.set_result(msg)

            # Procedimiento
            self.proc_box.set_text(result["procedimiento"])

            # Gráfica animada
            self.graph.plot_animated(
                xs, ys, result["polinomio"],
                x_eval, ev, grado, method,
            )
            self._last_fig = self.graph.fig

        except Exception as exc:
            import traceback
            self.resultado_box.set_result(f"❌ Error: {exc}", color=t["accent3"])
            self.proc_box.set_text(traceback.format_exc())

    # ── Limpiar todo ──────────────────────────────────────────────────────────
    def _limpiar(self):
        self.points_text.delete("0.0", "end")
        self.entry_xeval.delete(0, "end")
        self._limpiar_resultados()

    # ── Exportar ──────────────────────────────────────────────────────────────
    def _exportar(self):
        if self._last_result is None:
            self.resultado_box.set_result(
                "⚠️ Calcule primero.", color=self.t["accent3"])
            return
        if self.export_callback:
            self.export_callback(self._last_result, self._last_fig, "Interpolacion")
