"""
Interpolación de Lagrange
Procedimiento basado en el PDF del curso (Semana 7 + tarea del alumno)
"""
import numpy as np


def _fmt(v):
    """Formatea un número: si es entero exacto lo muestra sin decimales."""
    if isinstance(v, float) and v == int(v):
        return str(int(v))
    return f"{v:g}"


def lagrange(xs, ys, x_eval=None):
    """
    Construye el Polinomio de Lagrange con procedimiento paso a paso
    idéntico al mostrado en clase y en la tarea del alumno.

    Retorna dict con:
        polinomio, eval_result, tabla, procedimiento, grado,
        polinomio_expandido (str), n_puntos
    """
    n   = len(xs)
    g   = n - 1                        # grado
    lns = []                           # líneas del procedimiento

    nombre_grado = {1: "Lineal", 2: "Cuadrático", 3: "Cúbico",
                    4: "Cuártico", 5: "Quíntico"}.get(g, f"Grado {g}")

    # ═══════════════════════════════════════════════════════════
    lns += [
        "=" * 62,
        "   INTERPOLACIÓN CON EL POLINOMIO DE LAGRANGE",
        "=" * 62,
        "",
        f"   Número de puntos (n+1) : {n}   →   n = {g}",
        f"   Grado del polinomio    : {g}  ({nombre_grado})",
        "",
    ]

    # ── PASO 1: tabla de datos ───────────────────────────────────────────────
    lns += [
        "─" * 62,
        "  PASO 1 │ Identificar los puntos dados",
        "─" * 62,
        "",
        f"   {'i':>3}   {'x_i':>10}   {'y_i':>10}",
        f"   {'─'*3}   {'─'*10}   {'─'*10}",
    ]
    for i, (xi, yi) in enumerate(zip(xs, ys)):
        lns.append(f"   {i:>3}   {_fmt(xi):>10}   {_fmt(yi):>10}")
    lns += [
        "",
        f"   El polinomio será de grado n-1 = {g}",
        f"   ({'Una recta' if g==1 else 'Una parábola' if g==2 else f'Polinomio de grado {g}'})",
        "",
    ]

    # ── PASO 2: fórmula general ──────────────────────────────────────────────
    suma_str = " + ".join([f"y_{i}·L_{i}(x)" for i in range(n)])
    lns += [
        "─" * 62,
        "  PASO 2 │ Fórmula General del Polinomio de Lagrange",
        "─" * 62,
        "",
        "              n",
        "   P(x)  =   Σ   y_i · L_i(x)",
        "             i=0",
        "",
        "                    n        x - x_j",
        "   L_i(x)  =       Π      ──────────      (j ≠ i)",
        "                  j=0      x_i - x_j",
        "",
        f"   Para n = {g}  ({nombre_grado}):",
        f"   P_{g}(x) = {suma_str}",
        "",
    ]

    # ── PASOS 3…n+2: calcular cada L_i ──────────────────────────────────────
    L_funcs  = []
    tabla_Li = []

    for i in range(n):
        xi = xs[i]
        yi = ys[i]
        excluidos = [j for j in range(n) if j != i]

        num_factores = [f"(x - {_fmt(xs[j])})" for j in excluidos]
        den_factores = [f"({_fmt(xi)} - {_fmt(xs[j])})" for j in excluidos]
        den_valores  = [xi - xs[j] for j in excluidos]
        den_total    = 1.0
        for v in den_valores:
            den_total *= v

        num_str = " · ".join(num_factores)
        den_fac = " · ".join(den_factores)

        lns += [
            "─" * 62,
            f"  PASO {2+i+1} │ Calcular  L_{i}(x)   [constante i = {i},  x_{i} = {_fmt(xi)}]",
            "─" * 62,
            "",
            f"   Para i = {i}  excluimos  j = {excluidos}:",
            "",
        ]

        # Fracción con línea visual
        largo = max(len(num_str), len(den_fac))
        lns += [
            f"              {num_str}",
            f"   L_{i}(x) = {'─'*(largo+4)}",
            f"              {den_fac}",
            "",
            "   Calculamos el denominador:",
        ]
        for k, j in enumerate(excluidos):
            lns.append(f"     ({_fmt(xi)} - {_fmt(xs[j])}) = {_fmt(den_valores[k])}")

        # Producto parcial con pasos
        acum = 1.0
        prod_parts = []
        for v in den_valores:
            prod_parts.append(_fmt(v))
            acum *= v
        lns += [
            f"     Producto:  {' × '.join(prod_parts)} = {_fmt(den_total)}",
            "",
            "   Por lo tanto:",
            f"   L_{i}(x) = [{num_str}]",
            f"             ─────────────────────────────────────",
            f"                        {_fmt(den_total)}",
            "",
        ]

        # Verificación Kronecker δ
        lns.append(f"   Verificación  L_{i}(x_k) = δ_{{i,k}}:")
        for k in range(n):
            val = 1.0
            for j in range(n):
                if j != i:
                    val *= (xs[k] - xs[j]) / (xs[i] - xs[j])
            ok = "[✓]" if abs(val - (1 if k == i else 0)) < 1e-9 else "[✗]"
            lns.append(f"     L_{i}(x_{k}={_fmt(xs[k])}) = {val:.6g}  {ok}")
        lns.append("")

        # Closure L_i
        def _make(i=i):
            def Li(xv):
                r = 1.0
                for j in range(n):
                    if j != i:
                        r *= (xv - xs[j]) / (xs[i] - xs[j])
                return r
            return Li

        L_funcs.append(_make())
        tabla_Li.append([i, _fmt(xi), _fmt(yi),
                         f"[{num_str}] / {_fmt(den_total)}"])

    # ── Paso: Construir el polinomio ─────────────────────────────────────────
    paso_c = 3 + n
    lns += [
        "─" * 62,
        f"  PASO {paso_c} │ Construir el Polinomio Interpolante",
        "─" * 62,
        "",
        f"   P_{g}(x) = {suma_str}",
        "",
        "   Sustituyendo cada término:",
    ]
    for i in range(n):
        num_f = " · ".join([f"(x - {_fmt(xs[j])})" for j in range(n) if j != i])
        den_v = 1.0
        for j in range(n):
            if j != i:
                den_v *= (xs[i] - xs[j])
        lns.append(f"   y_{i}·L_{i}(x) = {_fmt(ys[i])} · [{num_f}] / {_fmt(den_v)}")
    lns.append("")

    # ── Polinomio expandido (numérico) ───────────────────────────────────────
    # Usamos numpy para expandir el polinomio
    coef_total = np.zeros(n)
    for i in range(n):
        # L_i(x) como polinomio: producto de (x-xj)/(xi-xj)
        den_v = 1.0
        for j in range(n):
            if j != i:
                den_v *= (xs[i] - xs[j])
        # numerador como polinomio
        p_num = np.array([1.0])
        for j in range(n):
            if j != i:
                p_num = np.polymul(p_num, [1.0, -xs[j]])
        coef_li = p_num / den_v
        # invertir: np.poly1d usa coef de mayor a menor
        coef_li_rev = coef_li[::-1]  # menor a mayor
        # yi * L_i
        for k in range(len(coef_li_rev)):
            if k < n:
                coef_total[k] += ys[i] * coef_li_rev[k]

    # Construir string del polinomio expandido
    terms_exp = []
    for k in range(n - 1, -1, -1):
        c = coef_total[k]
        if abs(c) < 1e-12:
            continue
        c_str = f"{c:.6g}"
        if k == 0:
            terms_exp.append(c_str)
        elif k == 1:
            terms_exp.append(f"{c_str}x")
        else:
            terms_exp.append(f"{c_str}x^{k}")
    polinomio_str = " + ".join(terms_exp).replace("+ -", "- ") if terms_exp else "0"

    lns += [
        "─" * 62,
        f"  PASO {paso_c+1} │ Polinomio Resultante (Forma Expandida)",
        "─" * 62,
        "",
        f"   P_{g}(x) = {polinomio_str}",
        "",
    ]

    # ── Función del polinomio ────────────────────────────────────────────────
    def P(xv):
        return sum(ys[i] * L_funcs[i](xv) for i in range(n))

    # ── Evaluación en x ─────────────────────────────────────────────────────
    eval_result = None
    if x_eval is not None:
        eval_result = P(x_eval)
        lns += [
            "═" * 62,
            f"  EVALUACIÓN  →  x = {_fmt(x_eval)}",
            "═" * 62,
            "",
        ]
        suma = 0.0
        for i in range(n):
            Lv = L_funcs[i](x_eval)
            contrib = ys[i] * Lv
            suma += contrib
            lns.append(
                f"   y_{i} · L_{i}({_fmt(x_eval)}) = {_fmt(ys[i])} × {Lv:.8g}"
                f"  =  {contrib:.8g}"
            )
        # Suma explícita
        parts_sum = " + ".join([f"{ys[i]*L_funcs[i](x_eval):.6g}" for i in range(n)])
        lns += [
            "",
            f"   P_{g}({_fmt(x_eval)}) = {parts_sum}",
            f"   P_{g}({_fmt(x_eval)}) = {suma:.10g}",
            "",
        ]

    lns += [
        "═" * 62,
        f"  RESULTADO FINAL",
        "═" * 62,
        f"   Grado del polinomio : {g}  ({nombre_grado})",
        f"   P_{g}(x) = {polinomio_str}",
    ]
    if eval_result is not None:
        lns.append(f"   P_{g}({_fmt(x_eval)}) ≈ {eval_result:.10g}")
    lns.append("═" * 62)

    return {
        "polinomio":           P,
        "eval_result":         eval_result,
        "tabla_headers":       ["i", "xᵢ", "yᵢ", "Lᵢ(x)"],
        "tabla":               tabla_Li,
        "procedimiento":       "\n".join(lns),
        "n_puntos":            n,
        "grado":               g,
        "nombre_grado":        nombre_grado,
        "polinomio_expandido": polinomio_str,
    }
