"""
Vista del Módulo de Cálculo de Raíces
Selector de método — delega en BiseccionView / NewtonRaphsonView / SecanteView
"""
import customtkinter as ctk
from ui.themes import get_theme
from ui.components import themed_frame, section_label, ModuleBanner

from raices.biseccion_view import BiseccionView
from raices.newton_raphson_view import NewtonRaphsonView
from raices.secante_view import SecanteView


class RaicesView(ctk.CTkFrame):
    def __init__(self, parent, export_callback=None):
        t = get_theme()
        super().__init__(parent, fg_color=t["bg_main"], corner_radius=0)
        self.t = t
        self.export_callback = export_callback
        self._views = {}
        self._current_view = None
        self._build()

    def _build(self):
        t = self.t

        banner = ModuleBanner(self, "Cálculo de Raíces",
                              "Bisección · Newton-Raphson · Secante", "🔢")
        banner.pack(fill="x", padx=12, pady=(6, 3))

        method_frame = themed_frame(self)
        method_frame.pack(fill="x", padx=12, pady=(0, 4))
        section_label(method_frame, "Método:").pack(side="left", padx=10, pady=6)

        self.method_var = ctk.StringVar(value="Bisección")
        for m in ["Bisección", "Newton-Raphson", "Secante"]:
            ctk.CTkRadioButton(
                method_frame, text=m, value=m,
                variable=self.method_var,
                text_color=t["text_primary"],
                fg_color=t["accent"],
                font=ctk.CTkFont(size=12),
                radiobutton_width=16, radiobutton_height=16,
                command=self._on_method_change
            ).pack(side="left", padx=10)

        self.content_frame = ctk.CTkFrame(self, fg_color=t["bg_main"], corner_radius=0)
        self.content_frame.pack(fill="both", expand=True)

        self._on_method_change()

    def _on_method_change(self):
        m = self.method_var.get()
        if self._current_view is not None:
            self._current_view.pack_forget()
        if m not in self._views:
            self._views[m] = self._make_view(m)
        self._current_view = self._views[m]
        self._current_view.pack(fill="both", expand=True)

    def _make_view(self, method: str):
        kwargs = dict(
            parent=self.content_frame,
            export_callback=self.export_callback,
        )
        if method == "Bisección":
            return BiseccionView(**kwargs)
        elif method == "Newton-Raphson":
            return NewtonRaphsonView(**kwargs)
        elif method == "Secante":
            return SecanteView(**kwargs)

