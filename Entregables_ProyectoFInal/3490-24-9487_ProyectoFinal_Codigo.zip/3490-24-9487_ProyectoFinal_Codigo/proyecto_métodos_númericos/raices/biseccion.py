"""
Método de Bisección
"""
import numpy as np
from utils.validators import absolute_error, relative_error


def biseccion(f, a, b, tol=1e-6, max_iter=100):
    """
    Método de bisección para encontrar raíces.

    Parámetros:
        f        : función
        a, b     : intervalo [a, b]
        tol      : tolerancia
        max_iter : máximo de iteraciones

    Retorna:
        resultado dict con 'raiz', 'iteraciones', 'tabla', 'procedimiento'
    """
    # Verificar condición de Bolzano
    if f(a) * f(b) > 0:
        raise ValueError(f"f(a) y f(b) deben tener signos opuestos.\n"
                         f"f({a}) = {f(a):.6g}, f({b}) = {f(b):.6g}")

    tabla = []
    procedimiento = []
    procedimiento.append("=" * 60)
    procedimiento.append("MÉTODO DE BISECCIÓN")
    procedimiento.append("=" * 60)
    procedimiento.append(f"\nFórmula:  c = (a + b) / 2\n")
    procedimiento.append(f"Intervalo inicial: [{a}, {b}]")
    procedimiento.append(f"Tolerancia: {tol}\n")
    procedimiento.append("-" * 60)

    c_prev = None
    raiz = None
    convergio = False

    for n in range(1, max_iter + 1):
        c = (a + b) / 2.0
        fc = f(c)
        fa = f(a)

        ea = absolute_error(c, c_prev) if c_prev is not None else float("inf")
        er = relative_error(c, c_prev) if c_prev is not None else float("inf")

        tabla.append([n, a, b, c, fc, ea, er])

        paso = (
            f"\n▶ Iteración {n}:\n"
            f"   a = {a:.8g},  b = {b:.8g}\n"
            f"   c = (a + b) / 2 = ({a:.8g} + {b:.8g}) / 2 = {c:.8g}\n"
            f"   f(c) = f({c:.8g}) = {fc:.8g}\n"
            f"   f(a) = {fa:.8g},  f(a)·f(c) = {fa*fc:.8g}\n"
        )

        if fa * fc < 0:
            paso += f"   → f(a)·f(c) < 0 ∴ b = c = {c:.8g}\n"
            b = c
        elif fa * fc > 0:
            paso += f"   → f(a)·f(c) > 0 ∴ a = c = {c:.8g}\n"
            a = c
        else:
            paso += f"   → f(c) = 0 exacto. Raíz encontrada.\n"
            procedimiento.append(paso)
            raiz = c
            convergio = True
            break

        if c_prev is not None:
            paso += f"   Error absoluto = {ea:.8g}\n"
            paso += f"   Error relativo = {er:.6g}%\n"

        procedimiento.append(paso)

        raiz = c
        c_prev = c

        if ea < tol:
            procedimiento.append(f"\n✅ Convergencia alcanzada en iteración {n}")
            procedimiento.append(f"   |Error| = {ea:.2e} < Tolerancia = {tol:.2e}")
            convergio = True
            break

    if not convergio:
        procedimiento.append(f"\n⚠️ Se alcanzó el máximo de iteraciones ({max_iter})")

    procedimiento.append(f"\n{'='*60}")
    procedimiento.append(f"RESULTADO FINAL: x ≈ {raiz:.10g}")
    procedimiento.append(f"f(x) = {f(raiz):.6e}")
    procedimiento.append("=" * 60)

    headers = ["n", "a", "b", "c (raíz)", "f(c)", "Error Abs.", "Error Rel. %"]

    return {
        "raiz": raiz,
        "f_raiz": f(raiz),
        "iteraciones": len(tabla),
        "convergio": convergio,
        "tabla_headers": headers,
        "tabla": tabla,
        "procedimiento": "\n".join(procedimiento),
    }
