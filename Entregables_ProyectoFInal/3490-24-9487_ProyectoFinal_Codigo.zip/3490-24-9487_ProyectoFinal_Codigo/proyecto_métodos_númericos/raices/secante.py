"""
Método de la Secante
"""
import numpy as np
from utils.validators import absolute_error, relative_error


def secante(f, x0, x1, tol=1e-6, max_iter=100):
    """
    Método de la Secante.

    Parámetros:
        f       : función
        x0, x1  : dos valores iniciales
        tol     : tolerancia
        max_iter: máximo de iteraciones
    """
    tabla = []
    procedimiento = []
    procedimiento.append("=" * 60)
    procedimiento.append("MÉTODO DE LA SECANTE")
    procedimiento.append("=" * 60)
    procedimiento.append(
        f"\nFórmula:  x_{{n+1}} = x_n - f(x_n) * (x_n - x_{{n-1}}) / (f(x_n) - f(x_{{n-1}}))\n"
    )
    procedimiento.append(f"x₀ = {x0},  x₁ = {x1}")
    procedimiento.append(f"Tolerancia: {tol}\n")
    procedimiento.append("-" * 60)

    raiz = None
    convergio = False

    for n in range(1, max_iter + 1):
        f0 = f(x0)
        f1 = f(x1)
        denom = f1 - f0

        if abs(denom) < 1e-14:
            raise ZeroDivisionError(f"f(x1) - f(x0) ≈ 0. División por cero en iteración {n}.")

        x2 = x1 - f1 * (x1 - x0) / denom
        ea = absolute_error(x2, x1)
        er = relative_error(x2, x1)

        tabla.append([n, x0, x1, f0, f1, x2, ea, er])

        paso = (
            f"\n▶ Iteración {n}:\n"
            f"   x_{n-1} = {x0:.8g},  f(x_{n-1}) = {f0:.8g}\n"
            f"   x_{n}   = {x1:.8g},  f(x_{n}) = {f1:.8g}\n"
            f"   x_{n+1} = {x1:.8g} - {f1:.8g} × ({x1:.8g} - {x0:.8g}) / ({f1:.8g} - {f0:.8g})\n"
            f"   x_{n+1} = {x1:.8g} - ({f1*(x1-x0):.8g}) / ({denom:.8g})\n"
            f"   x_{n+1} = {x2:.8g}\n"
            f"   Error absoluto = {ea:.8g}\n"
            f"   Error relativo = {er:.6g}%\n"
        )
        procedimiento.append(paso)

        x0, x1 = x1, x2
        raiz = x2

        if ea < tol:
            procedimiento.append(f"\n✅ Convergencia alcanzada en iteración {n}")
            procedimiento.append(f"   |Error| = {ea:.2e} < Tolerancia = {tol:.2e}")
            convergio = True
            break

    if not convergio:
        procedimiento.append(f"\n⚠️ Se alcanzó el máximo de iteraciones ({max_iter})")

    procedimiento.append(f"\n{'='*60}")
    procedimiento.append(f"RESULTADO FINAL: x ≈ {raiz:.10g}")
    procedimiento.append(f"f(x) = {f(raiz):.6e}")
    procedimiento.append("=" * 60)

    headers = ["n", "x_(n-1)", "x_n", "f(x_(n-1))", "f(x_n)", "x_(n+1)", "Error Abs.", "Error Rel. %"]

    return {
        "raiz": raiz,
        "f_raiz": f(raiz),
        "iteraciones": len(tabla),
        "convergio": convergio,
        "tabla_headers": headers,
        "tabla": tabla,
        "procedimiento": "\n".join(procedimiento),
    }
