"""
Método de Newton-Raphson
"""
import numpy as np
import sympy as sp
from utils.validators import absolute_error, relative_error


def newton_raphson(f, f_prime, x0, tol=1e-6, max_iter=100):
    """
    Método de Newton-Raphson.

    Parámetros:
        f       : función f(x)
        f_prime : derivada f'(x)
        x0      : valor inicial
        tol     : tolerancia
        max_iter: máximo de iteraciones

    Retorna:
        dict con 'raiz', 'tabla', 'procedimiento', ...
    """
    tabla = []
    procedimiento = []
    procedimiento.append("=" * 60)
    procedimiento.append("MÉTODO DE NEWTON-RAPHSON")
    procedimiento.append("=" * 60)
    procedimiento.append(f"\nFórmula:  x_{{n+1}} = x_n - f(x_n) / f'(x_n)\n")
    procedimiento.append(f"Valor inicial x₀ = {x0}")
    procedimiento.append(f"Tolerancia: {tol}\n")
    procedimiento.append("-" * 60)

    x = x0
    raiz = None
    convergio = False
    x_prev = None

    for n in range(1, max_iter + 1):
        fx = f(x)
        fpx = f_prime(x)

        if abs(fpx) < 1e-14:
            raise ZeroDivisionError(f"f'(x) ≈ 0 en x = {x:.6g}. División por cero.")

        x_new = x - fx / fpx
        ea = absolute_error(x_new, x)
        er = relative_error(x_new, x)

        tabla.append([n, x, fx, fpx, x_new, ea, er])

        paso = (
            f"\n▶ Iteración {n}:\n"
            f"   x_{n-1} = {x:.8g}\n"
            f"   f(x_{n-1}) = {fx:.8g}\n"
            f"   f'(x_{n-1}) = {fpx:.8g}\n"
            f"   x_{n} = {x:.8g} - ({fx:.8g}) / ({fpx:.8g})\n"
            f"   x_{n} = {x:.8g} - ({fx/fpx:.8g})\n"
            f"   x_{n} = {x_new:.8g}\n"
            f"   Error absoluto = {ea:.8g}\n"
            f"   Error relativo = {er:.6g}%\n"
        )
        procedimiento.append(paso)

        x = x_new
        raiz = x_new

        if ea < tol:
            procedimiento.append(f"\n✅ Convergencia alcanzada en iteración {n}")
            procedimiento.append(f"   |Error| = {ea:.2e} < Tolerancia = {tol:.2e}")
            convergio = True
            break

    if not convergio:
        procedimiento.append(f"\n⚠️ Se alcanzó el máximo de iteraciones ({max_iter})")

    procedimiento.append(f"\n{'='*60}")
    procedimiento.append(f"RESULTADO FINAL: x ≈ {raiz:.10g}")
    procedimiento.append(f"f(x) = {f(raiz):.6e}")
    procedimiento.append("=" * 60)

    headers = ["n", "x_n", "f(x_n)", "f'(x_n)", "x_(n+1)", "Error Abs.", "Error Rel. %"]

    return {
        "raiz": raiz,
        "f_raiz": f(raiz),
        "iteraciones": len(tabla),
        "convergio": convergio,
        "tabla_headers": headers,
        "tabla": tabla,
        "procedimiento": "\n".join(procedimiento),
    }


def derivada_simbolica(expr_str: str):
    """Calcula la derivada simbólica de una expresión."""
    try:
        x = sp.Symbol("x")
        expr = sp.sympify(expr_str)
        deriv = sp.diff(expr, x)
        f_prime = sp.lambdify(x, deriv, modules=["numpy"])
        return f_prime, str(deriv), None
    except Exception as e:
        return None, None, str(e)
