"""
Vista del Método de Bisección
"""
import tkinter as tk
import customtkinter as ctk
import numpy as np
from ui.themes import get_theme
from ui.components import (
    themed_frame, section_label, primary_button,
    danger_button, success_button, warning_button,
    IterationTable, ProcedimientoBox, ResultadoBox, GraphFrame
)
from ui.ayuda_formulas import AyudaFormulasDialog, EJEMPLOS
from raices.biseccion import biseccion
from utils.validators import parse_function, safe_float, safe_int


class BiseccionView(ctk.CTkFrame):
    def __init__(self, parent, export_callback=None):
        t = get_theme()
        super().__init__(parent, fg_color=t["bg_main"], corner_radius=0)
        self.t = t
        self.export_callback = export_callback
        self._last_result = None
        self._last_fig = None
        self._ayuda_win = None
        self._active_entry = None
        self._build()

    def _build(self):
        t = self.t

        scroll = ctk.CTkScrollableFrame(self, fg_color=t["bg_main"])
        scroll.pack(fill="both", expand=True, padx=12, pady=3)

        # ── Ejemplos ────────────────────────────────────────────────────────
        ej_frame = themed_frame(scroll)
        ej_frame.pack(fill="x", pady=(0, 4))
        section_label(ej_frame, "📂 Ejemplos predefinidos:").pack(side="left", padx=10, pady=4)
        for ej in EJEMPLOS["raices"]:
            ctk.CTkButton(ej_frame, text=ej["nombre"],
                          width=160, height=26,
                          fg_color=t["bg_input"], hover_color=t["accent"],
                          text_color=t["text_primary"], corner_radius=8,
                          font=ctk.CTkFont(size=11),
                          command=lambda e=ej: self._cargar_ejemplo(e)
                          ).pack(side="left", padx=4, pady=6)

        # ── Parámetros ──────────────────────────────────────────────────────
        params_frame = themed_frame(scroll)
        params_frame.pack(fill="x", pady=(0, 4))
        section_label(params_frame, "⚙️ Parámetros – Bisección").pack(anchor="w", padx=10, pady=(6, 2))

        grid = ctk.CTkFrame(params_frame, fg_color="transparent")
        grid.pack(fill="x", padx=8, pady=(0, 3))

        fx_row = ctk.CTkFrame(grid, fg_color="transparent")
        fx_row.grid(row=0, column=0, columnspan=5, sticky="w", padx=8, pady=(4, 0))
        ctk.CTkLabel(fx_row, text="f(x) =",
                     text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=12)).pack(side="left", padx=(0, 6))
        self.entry_fx = ctk.CTkEntry(fx_row, placeholder_text="ej: x**3 - x - 2",
                                     width=340, fg_color=t["bg_input"],
                                     border_color=t["border"], text_color=t["text_primary"])
        self.entry_fx.pack(side="left")
        self.entry_fx.bind("<FocusIn>", lambda e: self._set_active(self.entry_fx))

        ctk.CTkButton(fx_row, text="❓ Ayuda / Fórmulas", width=150, height=30,
                      fg_color=t["accent2"], hover_color=t["accent"],
                      text_color="#fff", corner_radius=8,
                      font=ctk.CTkFont(size=11),
                      command=self._abrir_ayuda
                      ).pack(side="left", padx=10)

        def make_entry(parent, label, placeholder, row, col):
            ctk.CTkLabel(parent, text=label, text_color=t["text_secondary"],
                         font=ctk.CTkFont(size=11)
                         ).grid(row=row, column=col, sticky="w", padx=8, pady=(6, 0))
            e = ctk.CTkEntry(parent, placeholder_text=placeholder, width=120,
                             fg_color=t["bg_input"], border_color=t["border"],
                             text_color=t["text_primary"])
            e.grid(row=row+1, column=col, sticky="w", padx=8, pady=(0, 4))
            return e

        self.entry_a     = make_entry(grid, "a (límite inf.)", "1.0",  2, 0)
        self.entry_b     = make_entry(grid, "b (límite sup.)", "2.0",  2, 1)
        self.entry_tol   = make_entry(grid, "Tolerancia",      "1e-6", 4, 0)
        self.entry_maxit = make_entry(grid, "Máx. Iteraciones","100",  4, 1)

        btn_row = ctk.CTkFrame(params_frame, fg_color="transparent")
        btn_row.pack(anchor="w", padx=8, pady=(3, 6))
        primary_button(btn_row, "▶  Calcular",    self._calcular,  width=150).pack(side="left", padx=4)
        danger_button (btn_row, "🗑  Limpiar",     self._limpiar,   width=120).pack(side="left", padx=4)
        success_button(btn_row, "📄  Exportar PDF",self._exportar,  width=160).pack(side="left", padx=4)

        # ── Resultado ───────────────────────────────────────────────────────
        section_label(scroll, "✅ Resultado").pack(anchor="w", pady=(5, 1))
        self.resultado_box = ResultadoBox(scroll)
        self.resultado_box.pack(fill="x", pady=(0, 4))

        # ── Tabla ───────────────────────────────────────────────────────────
        section_label(scroll, "📊 Tabla de Iteraciones").pack(anchor="w", pady=(3, 1))
        self.tabla = IterationTable(scroll, columns=["n","a","b","c/x","f(x)","Error Abs.","Error Rel.%"])
        self.tabla.pack(fill="x", pady=(0, 4))

        # ── Procedimiento ───────────────────────────────────────────────────
        section_label(scroll, "🧾 Procedimiento Paso a Paso").pack(anchor="w", pady=(3, 1))
        self.proc_box = ProcedimientoBox(scroll)
        self.proc_box.pack(fill="x", pady=(0, 3))
        self.proc_box.configure(height=190)

        # ── Gráfica ─────────────────────────────────────────────────────────
        section_label(scroll, "📉 Gráfica").pack(anchor="w", pady=(3, 1))
        self.graph = GraphFrame(scroll, figsize=(7, 2.9))
        self.graph.pack(fill="x", pady=(0, 6))

    # ── Helpers ──────────────────────────────────────────────────────────────
    def _cargar_ejemplo(self, ej: dict):
        self._set_entry(self.entry_fx, ej.get("fx", ""))
        self._set_entry(self.entry_a,  ej.get("a", ""))
        self._set_entry(self.entry_b,  ej.get("b", ""))
        self._set_entry(self.entry_tol, ej.get("tol", "1e-6"))
        self.proc_box.set_text(f"Ejemplo cargado: {ej['nombre']}\n{ej.get('desc','')}")

    def _set_entry(self, entry, value):
        entry.delete(0, "end")
        entry.insert(0, value)

    def _set_active(self, entry):
        self._active_entry = entry

    def _abrir_ayuda(self):
        try:
            if self._ayuda_win is not None and self._ayuda_win.winfo_exists():
                self._ayuda_win.deiconify(); self._ayuda_win.lift()
                self._ayuda_win.focus_force()
                self._ayuda_win.attributes("-topmost", True)
                self._ayuda_win.after(600, lambda: self._ayuda_win.attributes("-topmost", False)
                                      if self._ayuda_win.winfo_exists() else None)
                return
        except Exception:
            pass
        self._active_entry = self.entry_fx
        self._ayuda_win = AyudaFormulasDialog(self, on_insert=self._on_insert,
                                               modulo="raices", metodo="Bisección")
        self._ayuda_win.protocol("WM_DELETE_WINDOW", self._cerrar_ayuda)

    def _cerrar_ayuda(self):
        try:
            if self._ayuda_win is not None:
                self._ayuda_win.destroy()
        except Exception:
            pass
        finally:
            self._ayuda_win = None

    def _on_insert(self, text: str):
        target = self._active_entry or self.entry_fx
        try:
            pos = target.index(tk.INSERT)
            target.insert(pos, text)
        except Exception:
            target.delete(0, "end")
            target.insert(0, text)

    # ── Cálculo ──────────────────────────────────────────────────────────────
    def _calcular(self):
        t = self.t
        fx_str = self.entry_fx.get().strip()
        if not fx_str:
            self.resultado_box.set_result("⚠️ Ingrese f(x)", color=t["accent3"]); return

        f, _, err = parse_function(fx_str)
        if err:
            self.resultado_box.set_result(f"❌ Error en f(x): {err}", color=t["accent3"]); return

        tol    = safe_float(self.entry_tol.get())   or 1e-6
        max_it = safe_int(self.entry_maxit.get())   or 100

        try:
            a = safe_float(self.entry_a.get()); b = safe_float(self.entry_b.get())
            if a is None or b is None: raise ValueError("Ingrese a y b")
            result = biseccion(f, a, b, tol, max_it)

            self._last_result = result
            self._last_result["metodo"] = "Bisección"
            self._last_result["fx_str"] = fx_str

            raiz  = result["raiz"]; f_raiz = result["f_raiz"]
            its   = result["iteraciones"]
            conv  = "✅ Converge" if result["convergio"] else "⚠️ No convergió"
            self.resultado_box.set_result(
                f"{conv}   |   Raíz ≈ {raiz:.10g}   |   f(raíz) = {f_raiz:.4e}   |   {its} iteraciones"
            )
            self.tabla.update_data(result["tabla"])
            self.proc_box.set_text(result["procedimiento"])
            self._plot(f, raiz, fx_str)

        except Exception as exc:
            self.resultado_box.set_result(f"❌ Error: {exc}", color=t["accent3"])

    def _plot(self, f, raiz, fx_str):
        t = self.t; ax = self.graph.ax; self.graph.clear()
        delta = max(abs(raiz)*0.5, 2.0)
        xs = np.linspace(raiz-delta, raiz+delta, 500)
        try:
            ys = np.vectorize(f)(xs)
        except Exception:
            return
        colors = t["graph_colors"]
        ax.plot(xs, ys, color=colors[0], linewidth=2, label=f"f(x)={fx_str}")
        ax.axhline(0, color=t["graph_fg"], linewidth=0.8)
        ax.axvline(raiz, color=colors[1], linewidth=1.2, linestyle="--", alpha=0.7)
        ax.scatter([raiz], [f(raiz)], color=colors[2], zorder=5, s=80,
                   label=f"Raíz ≈ {raiz:.6g}")
        ax.set_title("Método: Bisección", color=t["graph_fg"])
        ax.set_xlabel("x"); ax.set_ylabel("f(x)")
        ax.legend(facecolor=t["bg_card"], edgecolor=t["border"],
                  labelcolor=t["text_primary"], fontsize=9)
        self._last_fig = self.graph.fig
        self.graph.refresh()

    def _limpiar(self):
        for e in [self.entry_fx, self.entry_a, self.entry_b,
                  self.entry_tol, self.entry_maxit]:
            e.delete(0, "end")
        self.resultado_box.set_result("—")
        self.tabla.update_data([])
        self.proc_box.set_text("")
        self.graph.clear(); self.graph.refresh()
        self._last_result = None

    def _exportar(self):
        if self._last_result is None:
            self.resultado_box.set_result("⚠️ Calcule primero", color=self.t["accent3"]); return
        if self.export_callback:
            self.export_callback(self._last_result, self._last_fig, "Calculo de Raices")


    # ── API pública para RaicesView ──────────────────────────────────────────
    def get_params(self):
        return {
            "fx_str": self.entry_fx.get().strip(),
            "a": self.entry_a.get(),
            "b": self.entry_b.get(),
            "tol": self.entry_tol.get(),
            "max_it": self.entry_maxit.get(),
        }
