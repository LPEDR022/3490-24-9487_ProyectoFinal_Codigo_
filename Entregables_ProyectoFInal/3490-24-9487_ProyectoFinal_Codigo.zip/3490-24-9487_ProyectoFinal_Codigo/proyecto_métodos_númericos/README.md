# 🧮 Métodos Numéricos con Python
**Universidad Mariano Gálvez de Guatemala**
Desarrollado por: Luis Pedro Ramírez Segura y Gerson Samuel Guzmán Franco

---

## 📋 Módulos Incluidos

| Módulo | Métodos |
|--------|---------|
| 🔢 Cálculo de Raíces | Bisección, Newton-Raphson, Secante |
| 📈 Interpolación | Lagrange, Newton (Dif. Divididas) |
| 🧩 Sistemas de Ecuaciones | Gauss-Seidel, Factorización LU |
| ∫ Integración y Derivación | Trapecio, Simpson 1/3, Dif. Finitas |
| 📉 Ecuaciones Diferenciales | Euler, Runge-Kutta 4 |

---

## ⚙️ Requisitos

- **Python 3.9 o superior**
- Librerías: `customtkinter`, `numpy`, `matplotlib`, `scipy`, `sympy`, `reportlab`, `Pillow`

---

## 🚀 Instalación

### Opción 1 — Automática (recomendada)
```bash
python instalar_y_ejecutar.py
```

### Opción 2 — Manual
```bash
pip install -r requirements.txt
python main.py
```

---

## 🗂️ Estructura del Proyecto

```
proyecto_metodos_fixed/
├── main.py                    ← Punto de entrada y navegación
├── requirements.txt           ← Dependencias
├── instalar_y_ejecutar.py     ← Instalación automática
├── ui/
│   ├── themes.py              ← Sistema de temas (Dark/Light/Custom)
│   ├── components.py          ← Componentes reutilizables
│   └── ayuda_formulas.py      ← Ventana de ayuda
├── raices/
│   ├── biseccion.py           ← Algoritmo Bisección
│   ├── newton_raphson.py      ← Algoritmo Newton-Raphson
│   ├── secante.py             ← Algoritmo Secante
│   ├── biseccion_view.py      ← Vista Bisección
│   ├── newton_raphson_view.py ← Vista Newton-Raphson
│   ├── secante_view.py        ← Vista Secante
│   └── raices_view.py         ← Vista contenedora
├── interpolacion/
│   ├── lagrange.py            ← Interpolación de Lagrange
│   ├── newton_interp.py       ← Diferencias divididas de Newton
│   └── interp_view.py         ← Vista de Interpolación
├── sistemas/
│   ├── gauss_seidel.py        ← Método de Gauss-Seidel
│   ├── factorizacion_lu.py    ← Factorización LU (Doolittle)
│   └── sistemas_view.py       ← Vista de Sistemas
├── integracion/
│   ├── metodos.py             ← Trapecio, Simpson, Dif. Finitas
│   └── integracion_view.py    ← Vista de Integración
├── diferenciales/
│   ├── metodos_edo.py         ← Euler, Runge-Kutta 4
│   └── diferenciales_view.py  ← Vista de EDOs
├── export_pdf/
│   └── exporter.py            ← Generador de PDF
└── utils/
    └── validators.py          ← Validación y errores numéricos
```

---

## 🎨 Temas Visuales

| Tema | Descripción |
|------|-------------|
| 🌙 Oscuro | Fondo oscuro, acentos azules (predeterminado) |
| ☀️ Claro | Fondo blanco, colores suaves |
| 🎨 Personalizado | Fondo púrpura oscuro, neon |

Cambia el tema desde el menú **"Tema"** en la barra superior.

---

## 📄 Exportar a PDF

Cada módulo tiene el botón **"📄 Exportar PDF"** que genera:
- Encabezado con datos de entrada
- Resultado principal destacado
- Tabla completa de iteraciones
- Procedimiento paso a paso
- Gráfica embebida

---

## ✏️ Personalizar nombres

Editar `main.py`, variables al inicio:
```python
DEV1 = "Tu Nombre Aquí"
DEV2 = "Segundo Desarrollador"
```
