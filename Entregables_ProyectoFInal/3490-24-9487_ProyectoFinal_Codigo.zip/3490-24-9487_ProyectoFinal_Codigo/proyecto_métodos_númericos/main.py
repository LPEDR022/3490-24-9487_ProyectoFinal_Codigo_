"""
main.py - Punto de entrada
Metodos Numericos con Python
Universidad Mariano Galvez
"""
import sys
import os
import tkinter.messagebox as msgbox
import tkinter.filedialog as fdialog
import customtkinter as ctk

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import ui.themes as theme_module
from ui.themes import get_theme, set_theme, THEMES
from ui.components import themed_frame

from raices.raices_view               import RaicesView
from interpolacion.interp_view        import InterpolacionView
from sistemas.sistemas_view           import SistemasView
from integracion.integracion_view     import IntegracionView
from diferenciales.diferenciales_view import DiferencialesView
from export_pdf.exporter              import exportar_pdf

# ── Nombres fijos de desarrolladores ─────────────────────────────────────────
DEV1 = "Luis Pedro Ramirez Segura"
DEV2 = "Gerson Samuel Guzman Franco"

# ══════════════════════════════════════════════════
#  SIDEBAR ITEM
# ══════════════════════════════════════════════════

class SidebarItem(ctk.CTkFrame):
    def __init__(self, parent, icon, text, command, **kwargs):
        t = get_theme()
        kwargs.setdefault("fg_color", "transparent")
        kwargs.setdefault("corner_radius", 8)
        super().__init__(parent, **kwargs)
        self._active = False
        self.command = command
        self.configure(cursor="hand2")

        # Barra de acento izquierda (3px, color del acento cuando activo)
        self.bar = ctk.CTkFrame(self, width=3, fg_color="transparent", corner_radius=2)
        self.bar.pack(side="left", fill="y", padx=(3, 0), pady=5)

        # Icono con tamaño fijo para alineacion uniforme
        self.icon_lbl = ctk.CTkLabel(self, text=icon,
                                     font=ctk.CTkFont(size=14), width=24,
                                     anchor="center")
        self.icon_lbl.pack(side="left", padx=(6, 4))

        # Texto del modulo con fuente uniforme en todos los items
        self.text_lbl = ctk.CTkLabel(self, text=text,
                                     font=ctk.CTkFont(size=12),
                                     text_color=t["text_secondary"],
                                     anchor="w")
        self.text_lbl.pack(side="left", fill="x", expand=True, padx=(0, 4))

        for w in (self, self.icon_lbl, self.text_lbl):
            w.bind("<Button-1>", lambda e: self.command())
            w.bind("<Enter>",    self._on_hover)
            w.bind("<Leave>",    self._on_leave)

    def set_active(self, active: bool):
        t = get_theme()
        self._active = active
        if active:
            self.configure(fg_color=t["sidebar_active"])
            self.bar.configure(fg_color=t["sidebar_active_bar"])
            self.text_lbl.configure(text_color=t["text_accent"],
                                    font=ctk.CTkFont(size=12, weight="bold"))
            self.icon_lbl.configure(text_color=t["text_accent"])
        else:
            self.configure(fg_color="transparent")
            self.bar.configure(fg_color="transparent")
            self.text_lbl.configure(text_color=get_theme()["text_secondary"],
                                    font=ctk.CTkFont(size=12))
            self.icon_lbl.configure(text_color=get_theme()["text_secondary"])

    def _on_hover(self, e):
        if not self._active:
            self.configure(fg_color=get_theme()["sidebar_active"])

    def _on_leave(self, e):
        if not self._active:
            self.configure(fg_color="transparent")


# ══════════════════════════════════════════════════
#  MENU
# ══════════════════════════════════════════════════

MENU_ITEMS = [
    ("raices",        "🔢", "Cálculo de Raíces"),
    ("interpolacion", "📈", "Interpolación"),
    ("sistemas",      "🧩", "Sistemas de Ecuaciones"),
    ("integracion",   "∫",  "Integración y Derivación"),
    ("diferenciales", "📉", "Ecuaciones Diferenciales"),
]

VIEW_CLASSES = {
    "raices":        RaicesView,
    "interpolacion": InterpolacionView,
    "sistemas":      SistemasView,
    "integracion":   IntegracionView,
    "diferenciales": DiferencialesView,
}


# ══════════════════════════════════════════════════
#  APLICACION PRINCIPAL
# ══════════════════════════════════════════════════

class App(ctk.CTk):
    def __init__(self):
        t = get_theme()
        ctk.set_appearance_mode("Dark" if t["mode"] == "dark" else "Light")
        ctk.set_default_color_theme("blue")
        super().__init__()

        self.title("Métodos Numéricos con Python – UMG")
        self.geometry("1300x820")
        self.minsize(1000, 660)
        self.configure(fg_color=t["bg_main"])

        self._views         = {}
        self._current_key   = None
        self._sidebar_items = {}

        self._build_layout()
        self._navigate("raices")

    # ── Layout ───────────────────────────────────────────────────────────────
    def _build_layout(self):
        t = get_theme()

        # HEADER
        self.header_frame = ctk.CTkFrame(self, height=46, fg_color=t["bg_sidebar"], corner_radius=0)
        self.header_frame.pack(fill="x", side="top")
        self.header_frame.pack_propagate(False)
        self._build_header()

        # BODY
        self.body_frame = ctk.CTkFrame(self, fg_color=t["bg_main"], corner_radius=0)
        self.body_frame.pack(fill="both", expand=True)

        # Contenedor externo del sidebar (fija el ancho)
        self._sidebar_container = ctk.CTkFrame(self.body_frame, width=210,
                                               fg_color=t["bg_sidebar"], corner_radius=0)
        self._sidebar_container.pack(side="left", fill="y")
        self._sidebar_container.pack_propagate(False)

        # Frame scrollable interno para que los items nunca se corten
        self.sidebar_frame = ctk.CTkScrollableFrame(
            self._sidebar_container,
            fg_color=t["bg_sidebar"],
            corner_radius=0,
            scrollbar_button_color=t["border"],
            scrollbar_button_hover_color=t["accent"],
        )
        self.sidebar_frame.pack(fill="both", expand=True)
        self._build_sidebar()

        ctk.CTkFrame(self.body_frame, width=1, fg_color=t["border"]
                     ).pack(side="left", fill="y")

        self.content = ctk.CTkFrame(self.body_frame, fg_color=t["bg_main"], corner_radius=0)
        self.content.pack(side="left", fill="both", expand=True)

        # FOOTER
        self.footer_frame = ctk.CTkFrame(self, height=26, fg_color=t["bg_sidebar"], corner_radius=0)
        self.footer_frame.pack(fill="x", side="bottom")
        self.footer_frame.pack_propagate(False)
        self._build_footer()

    def _build_header(self):
        t = get_theme()
        for w in self.header_frame.winfo_children():
            w.destroy()

        logo_row = ctk.CTkFrame(self.header_frame, fg_color="transparent")
        logo_row.pack(side="left", padx=14)
        ctk.CTkLabel(logo_row, text="🧮", font=ctk.CTkFont(size=18)).pack(side="left")
        ctk.CTkLabel(logo_row, text="  Métodos Numéricos con Python",
                     font=ctk.CTkFont(size=14, weight="bold"),
                     text_color=t["text_primary"]).pack(side="left")

        right_row = ctk.CTkFrame(self.header_frame, fg_color="transparent")
        right_row.pack(side="right", padx=12)

        # Solo selector de tema - SIN boton de desarrolladores
        ctk.CTkLabel(right_row, text="Tema:",
                     text_color=t["text_secondary"],
                     font=ctk.CTkFont(size=11)).pack(side="left", padx=4)
        self.theme_var = ctk.StringVar(value=theme_module.current_theme)
        theme_menu = ctk.CTkOptionMenu(
            right_row,
            values=list(THEMES.keys()),
            variable=self.theme_var,
            command=self._change_theme,
            fg_color=t["bg_input"],
            button_color=t["accent"],
            button_hover_color=t["accent_hover"],
            text_color=t["text_primary"],
            width=130,
            height=28,
        )
        theme_menu.pack(side="left", padx=4)

    def _build_sidebar(self):
        t = get_theme()
        for w in self.sidebar_frame.winfo_children():
            w.destroy()
        self._sidebar_items = {}

        # Espaciado superior
        ctk.CTkFrame(self.sidebar_frame, height=8, fg_color="transparent").pack()

        # Etiqueta seccion con estilo mas limpio
        ctk.CTkLabel(self.sidebar_frame, text="MÓDULOS",
                     font=ctk.CTkFont(size=9, weight="bold"),
                     text_color=t["text_secondary"]
                     ).pack(anchor="w", padx=16, pady=(6, 6))

        # Items de modulos: todos con el mismo alto uniforme (40px)
        for key, icon, text in MENU_ITEMS:
            item = SidebarItem(self.sidebar_frame, icon, text,
                               command=lambda k=key: self._navigate(k),
                               height=40)
            item.pack(fill="x", padx=6, pady=2)
            self._sidebar_items[key] = item

        # Sin seccion Herramientas (Exportar PDF removido del sidebar)
        if self._current_key and self._current_key in self._sidebar_items:
            self._sidebar_items[self._current_key].set_active(True)

    def _build_footer(self):
        t = get_theme()
        for w in self.footer_frame.winfo_children():
            w.destroy()
        self.footer_lbl = ctk.CTkLabel(
            self.footer_frame,
            text=f"Universidad Mariano Gálvez   |   Métodos Numéricos con Python   |   "
                 f"Desarrollado por: {DEV1}  y  {DEV2}",
            font=ctk.CTkFont(size=9),
            text_color=t["text_secondary"],
        )
        self.footer_lbl.pack(side="left", padx=12, pady=3)

    # ── Navegación ────────────────────────────────────────────────────────────
    def _navigate(self, key: str):
        if self._current_key and self._current_key in self._sidebar_items:
            self._sidebar_items[self._current_key].set_active(False)
        if key in self._sidebar_items:
            self._sidebar_items[key].set_active(True)
        self._current_key = key

        # Ocultar todas las vistas activas
        for v in list(self._views.values()):
            try:
                v.pack_forget()
            except Exception:
                pass

        # Verificar si la vista existe y es valida; si no, borrarla para recrear
        if key in self._views:
            try:
                if not self._views[key].winfo_exists():
                    del self._views[key]
            except Exception:
                del self._views[key]

        # Crear la vista si no existe (con manejo de errores)
        if key not in self._views:
            try:
                cls = VIEW_CLASSES[key]
                self._views[key] = cls(self.content, export_callback=self._export_callback)
            except Exception as e:
                import tkinter.messagebox as _mb
                _mb.showerror(
                    "Error al cargar modulo",
                    f"No se pudo cargar el modulo '{key}':\n{e}\n\n"
                    "Revise la consola para mas detalles."
                )
                import traceback
                traceback.print_exc()
                return

        # Mostrar la vista
        try:
            self._views[key].pack(fill="both", expand=True)
        except Exception:
            pass

    # ── Cambio de tema EN VIVO ────────────────────────────────────────────────
    def _change_theme(self, theme_name: str):
        set_theme(theme_name)
        t = get_theme()
        ctk.set_appearance_mode("Dark" if t["mode"] == "dark" else "Light")

        for v in self._views.values():
            v.destroy()
        self._views = {}

        self.configure(fg_color=t["bg_main"])
        self._build_header()
        self._build_sidebar()
        self._build_footer()

        self.body_frame.configure(fg_color=t["bg_main"])
        self.sidebar_frame.configure(fg_color=t["bg_sidebar"])
        if hasattr(self, "_sidebar_container"):
            self._sidebar_container.configure(fg_color=t["bg_sidebar"])
        self.content.configure(fg_color=t["bg_main"])
        self.footer_frame.configure(fg_color=t["bg_sidebar"])
        self.header_frame.configure(fg_color=t["bg_sidebar"])

        key = self._current_key or "raices"
        self._current_key = None
        self._navigate(key)

        if hasattr(self, "theme_var"):
            self.theme_var.set(theme_name)

    # ── Exportar PDF ──────────────────────────────────────────────────────────
    def _export_callback(self, result: dict, fig, modulo: str):
        filepath = fdialog.asksaveasfilename(
            defaultextension=".pdf",
            filetypes=[("PDF files", "*.pdf")],
            initialfile=f"metodos_numericos_{modulo.replace(' ', '_').lower()}.pdf",
            title="Guardar PDF",
        )
        if not filepath:
            return
        try:
            datos = {}
            if "metodo"  in result: datos["Metodo"]  = result["metodo"]
            if "fx_str"  in result: datos["f(x)"]    = result["fx_str"]
            if "fxy_str" in result: datos["f(x,y)"]  = result["fxy_str"]

            if "raiz" in result:
                res_str = f"Raiz aprox. = {result['raiz']:.10g}   |   f(raiz) = {result.get('f_raiz','?'):.4e}"
            elif "resultado" in result:
                res_str = f"Resultado = {result['resultado']:.10g}"
            elif "solucion" in result:
                res_str = "  |  ".join([f"x{i+1}={v:.8g}" for i, v in enumerate(result["solucion"])])
            else:
                res_str = "Ver tabla y procedimiento"

            exportar_pdf(
                metodo=result.get("metodo", modulo),
                datos_entrada=datos,
                resultado_str=res_str,
                tabla_headers=result.get("tabla_headers", []),
                tabla_rows=result.get("tabla", [])[:100],
                procedimiento=result.get("procedimiento", ""),
                fig=fig,
                nombre_archivo=filepath,
                desarrolladores=(DEV1, DEV2),
            )
            msgbox.showinfo("PDF Exportado", f"✅ PDF guardado:\n{filepath}")
        except Exception as exc:
            msgbox.showerror("Error al exportar", f"No se pudo generar el PDF:\n{exc}")

    def _exportar_activo(self):
        # Metodo conservado por compatibilidad interna pero ya no expuesto en UI
        pass


# ══════════════════════════════════════════════════
#  ENTRY POINT
# ══════════════════════════════════════════════════

if __name__ == "__main__":
    app = App()
    app.mainloop()
