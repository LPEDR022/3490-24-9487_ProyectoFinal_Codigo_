#!/usr/bin/env python3
"""
instalar_y_ejecutar.py
Instala dependencias y lanza la aplicacion.
Ejecutar con:  python instalar_y_ejecutar.py
"""
import subprocess
import sys
import os

REQS = [
    "customtkinter>=5.2.0",
    "numpy>=1.24.0",
    "matplotlib>=3.7.0",
    "scipy>=1.11.0",
    "sympy>=1.12",
    "reportlab>=4.0.0",
    "Pillow>=10.0.0",
]

def install():
    print("=" * 55)
    print("  Instalando dependencias...")
    print("=" * 55)
    for pkg in REQS:
        print(f"  Instalando: {pkg}")
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "--quiet"])
    print("\n✅ Dependencias instaladas.\n")

def run():
    main_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "main.py")
    print("Iniciando Metodos Numericos con Python...\n")
    os.chdir(os.path.dirname(main_path))
    subprocess.call([sys.executable, main_path])

if __name__ == "__main__":
    install()
    run()
