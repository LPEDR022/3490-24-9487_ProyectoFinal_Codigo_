"""
Vista de Ecuaciones Diferenciales – con ejemplos y ayuda
"""
import tkinter as tk
import customtkinter as ctk
import numpy as np
from ui.themes import get_theme
from ui.components import (
    themed_frame, section_label, primary_button, danger_button, success_button,
    labeled_entry, IterationTable, ProcedimientoBox, ResultadoBox, GraphFrame, ModuleBanner
)
from ui.ayuda_formulas import AyudaFormulasDialog, EJEMPLOS
from diferenciales.metodos_edo import euler, runge_kutta4
from utils.validators import parse_function_xy, safe_float


class DiferencialesView(ctk.CTkFrame):
    def __init__(self, parent, export_callback=None):
        t = get_theme()
        super().__init__(parent, fg_color=t["bg_main"], corner_radius=0)
        self.t = t
        self.export_callback = export_callback
        self._last_result = None
        self._last_fig = None
        self._ayuda_win = None
        self._active_entry = None
        self._build()

    def _build(self):
        t = self.t
        banner = ModuleBanner(self, "Ecuaciones Diferenciales",
                              "Euler · Runge-Kutta Orden 4", "📉")
        banner.pack(fill="x", padx=12, pady=(6, 3))

        scroll = ctk.CTkScrollableFrame(self, fg_color=t["bg_main"])
        scroll.pack(fill="both", expand=True, padx=12, pady=3)

        # Método
        mf = themed_frame(scroll)
        mf.pack(fill="x", pady=(0, 4))
        section_label(mf, "Método:").pack(side="left", padx=10, pady=6)
        self.method_var = ctk.StringVar(value="Euler")
        for m in ["Euler", "Runge-Kutta 4"]:
            ctk.CTkRadioButton(
                    mf, text=m, value=m,
                    variable=self.method_var,
                    text_color=t["text_primary"],
                    fg_color=t["accent"],
                    font=ctk.CTkFont(size=12),
                    radiobutton_width=16, radiobutton_height=16,
                    command=self._on_method_change,
                ).pack(side="left", padx=10)

        # Ejemplos (frame persistente, se reconstruye al cambiar método)
        self.ej_frame = themed_frame(scroll)
        self.ej_frame.pack(fill="x", pady=(0, 4))
        self._rebuild_ejemplos()

        # Parámetros
        pf = themed_frame(scroll)
        pf.pack(fill="x", pady=(0, 4))
        section_label(pf, "⚙️ Parámetros").pack(anchor="w", padx=10, pady=(6, 2))
        grid = ctk.CTkFrame(pf, fg_color="transparent")
        grid.pack(fill="x", padx=8, pady=(0, 3))

        fxy_row = ctk.CTkFrame(grid, fg_color="transparent")
        fxy_row.grid(row=0, column=0, columnspan=5, sticky="w", padx=8, pady=(4, 6))
        ctk.CTkLabel(fxy_row, text="dy/dx = f(x,y) =",
                     text_color=t["text_secondary"], font=ctk.CTkFont(size=12)
                     ).pack(side="left", padx=(0, 6))
        self.entry_fxy = ctk.CTkEntry(fxy_row, placeholder_text="ej: x + y  o  -2*x*y",
                                      width=300, fg_color=t["bg_input"],
                                      border_color=t["border"], text_color=t["text_primary"])
        self.entry_fxy.pack(side="left")
        self.entry_fxy.insert(0, "x + y")
        self.entry_fxy.bind("<FocusIn>", lambda e: self._set_active(self.entry_fxy))
        ctk.CTkButton(fxy_row, text="❓ Ayuda", width=80, height=30,
                      fg_color=t["accent2"], hover_color=t["accent"],
                      text_color="#fff", corner_radius=6, font=ctk.CTkFont(size=11),
                      command=self._abrir_ayuda).pack(side="left", padx=10)

        def mk(lbl, ph, row, col):
            ctk.CTkLabel(grid, text=lbl, text_color=t["text_secondary"],
                         font=ctk.CTkFont(size=11)).grid(row=row, column=col, sticky="w", padx=8, pady=(4,0))
            e = ctk.CTkEntry(grid, placeholder_text=ph, width=110,
                             fg_color=t["bg_input"], border_color=t["border"],
                             text_color=t["text_primary"])
            e.grid(row=row+1, column=col, sticky="w", padx=8, pady=(0, 4))
            return e

        self.entry_x0 = mk("x₀ (inicio)", "0",   2, 0)
        self.entry_y0 = mk("y₀ (cond.ini.)","1",  2, 1)
        self.entry_xf = mk("xf (fin)",     "2",   2, 2)
        self.entry_h  = mk("h (paso)",     "0.1", 2, 3)

        btn_row = ctk.CTkFrame(pf, fg_color="transparent")
        btn_row.pack(anchor="w", padx=8, pady=(3, 6))
        primary_button(btn_row, "▶  Calcular",    self._calcular,  width=150).pack(side="left", padx=4)
        danger_button (btn_row, "🗑  Limpiar",     self._limpiar,   width=120).pack(side="left", padx=4)
        success_button(btn_row, "📄  Exportar PDF",self._exportar,  width=160).pack(side="left", padx=4)

        section_label(scroll, "✅ Resultado").pack(anchor="w", pady=(5, 1))
        self.resultado_box = ResultadoBox(scroll)
        self.resultado_box.pack(fill="x", pady=(0, 4))

        section_label(scroll, "📊 Tabla de Iteraciones").pack(anchor="w", pady=(3, 1))
        # Columnas iniciales para Euler; se actualizan dinamicamente al calcular RK4
        self.tabla = IterationTable(scroll, columns=["n", "x_n", "y_n", "f(x_n,y_n)", "h"])
        self.tabla.pack(fill="x", pady=(0, 4))

        section_label(scroll, "🧾 Procedimiento Paso a Paso").pack(anchor="w", pady=(3, 1))
        self.proc_box = ProcedimientoBox(scroll)
        self.proc_box.pack(fill="x", pady=(0, 3))
        self.proc_box.configure(height=190)

        section_label(scroll, "📉 Gráfica de la Solución Aproximada").pack(anchor="w", pady=(3, 1))
        self.graph = GraphFrame(scroll, figsize=(7, 2.9))
        self.graph.pack(fill="x", pady=(0, 6))

    def _rebuild_ejemplos(self):
        t = self.t
        key = "diferenciales_euler" if self.method_var.get() == "Euler" else "diferenciales_rk4"
        for w in self.ej_frame.winfo_children():
            w.destroy()
        section_label(self.ej_frame, "📂 Ejemplos:").pack(side="left", padx=10, pady=4)
        for ej in EJEMPLOS[key]:
            nm = ej["nombre"]
            ctk.CTkButton(self.ej_frame,
                          text=nm[:22]+"…" if len(nm) > 22 else nm,
                          width=185, height=26,
                          fg_color=t["bg_input"], hover_color=t["accent"],
                          text_color=t["text_primary"], corner_radius=8,
                          font=ctk.CTkFont(size=11),
                          command=lambda e=ej: self._cargar_ejemplo(e)
                          ).pack(side="left", padx=4, pady=6)

    def _on_method_change(self):
        self._rebuild_ejemplos()

    def _cargar_ejemplo(self, ej):
        self.entry_fxy.delete(0, "end"); self.entry_fxy.insert(0, ej.get("fxy", ""))
        self.entry_x0.delete(0, "end");  self.entry_x0.insert(0, ej.get("x0", "0"))
        self.entry_y0.delete(0, "end");  self.entry_y0.insert(0, ej.get("y0", "1"))
        self.entry_xf.delete(0, "end");  self.entry_xf.insert(0, ej.get("xf", "2"))
        self.entry_h.delete(0, "end");   self.entry_h.insert(0, ej.get("h", "0.1"))
        self.proc_box.set_text(f"Ejemplo cargado: {ej['nombre']}\n{ej.get('desc','')}")

    def _set_active(self, e): self._active_entry = e

    def _abrir_ayuda(self):
        """Abre la ventana de ayuda de forma robusta."""
        try:
            if self._ayuda_win is not None and self._ayuda_win.winfo_exists():
                self._ayuda_win.deiconify()
                self._ayuda_win.lift()
                self._ayuda_win.focus_force()
                self._ayuda_win.attributes("-topmost", True)
                self._ayuda_win.after(600, lambda: self._ayuda_win.attributes("-topmost", False)
                                      if self._ayuda_win.winfo_exists() else None)
                return
        except Exception:
            pass
        self._active_entry = self.entry_fxy
        self._ayuda_win = AyudaFormulasDialog(self, on_insert=self._on_insert,
                                               modulo="diferenciales", metodo=self.method_var.get())
        self._ayuda_win.protocol("WM_DELETE_WINDOW", self._cerrar_ayuda)

    def _cerrar_ayuda(self):
        """Cierra y limpia la referencia a la ventana de ayuda."""
        try:
            if self._ayuda_win is not None:
                self._ayuda_win.destroy()
        except Exception:
            pass
        finally:
            self._ayuda_win = None

    def _on_insert(self, text):
        target = self._active_entry or self.entry_fxy
        try:
            pos = target.index(tk.INSERT); target.insert(pos, text)
        except Exception:
            target.delete(0, "end"); target.insert(0, text)

    def _get_params(self):
        fxy_str = self.entry_fxy.get().strip()
        f, _, err = parse_function_xy(fxy_str)
        if err: raise ValueError(f"Error en f(x,y): {err}")
        x0 = safe_float(self.entry_x0.get())
        y0 = safe_float(self.entry_y0.get())
        xf = safe_float(self.entry_xf.get())
        h  = safe_float(self.entry_h.get())
        if None in (x0, y0, xf, h): raise ValueError("Complete todos los parámetros")
        if h <= 0 or xf <= x0:      raise ValueError("Verifique: h > 0 y xf > x0")
        return f, fxy_str, x0, y0, xf, h

    def _calcular(self):
        t = self.t
        try:
            f, fxy_str, x0, y0, xf, h = self._get_params()
            method = self.method_var.get()
            result = euler(f, x0, y0, xf, h) if method == "Euler" \
                     else runge_kutta4(f, x0, y0, xf, h)
            self._last_result = result
            self._last_result["metodo"] = method
            self._last_result["fxy_str"] = fxy_str
            self.resultado_box.set_result(
                f"✅ {method}  |  y({xf}) ≈ {result['resultado']:.10g}  |  Pasos: {len(result['tabla'])-1}"
            )
            # Actualizar tabla con las columnas correctas segun el metodo
            self.tabla.update_data(result["tabla"], new_columns=result["tabla_headers"])
            self.proc_box.set_text(result["procedimiento"])
            self._plot([result], [method])
        except Exception as exc:
            self.resultado_box.set_result(f"❌ Error: {exc}", color=t["accent3"])

    def _plot(self, results, labels):
        t = self.t; self.graph.clear(); ax = self.graph.ax; colors = t["graph_colors"]
        for i, (r, lbl) in enumerate(zip(results, labels)):
            ax.plot(r["xs"], r["ys"], color=colors[i % len(colors)],
                    linewidth=2, marker="o", markersize=3, label=lbl)
        ax.set_title("Solución aproximada EDO", color=t["graph_fg"])
        ax.set_xlabel("x"); ax.set_ylabel("y")
        ax.legend(facecolor=t["bg_card"], edgecolor=t["border"],
                  labelcolor=t["text_primary"], fontsize=9)
        self._last_fig = self.graph.fig; self.graph.refresh()

    def _limpiar(self):
        self.resultado_box.set_result("—"); self.tabla.update_data([])
        self.proc_box.set_text(""); self.graph.clear(); self.graph.refresh()
        self._last_result = None

    def _exportar(self):
        if self._last_result is None:
            self.resultado_box.set_result("⚠️ Calcule primero", color=self.t["accent3"]); return
        if self.export_callback:
            self.export_callback(self._last_result, self._last_fig, "Ecuaciones Diferenciales")
