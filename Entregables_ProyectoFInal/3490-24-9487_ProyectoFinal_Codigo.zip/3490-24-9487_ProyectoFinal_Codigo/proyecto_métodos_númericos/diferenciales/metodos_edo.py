"""
Métodos para EDO (Ecuaciones Diferenciales Ordinarias):
- Método de Euler
- Método de Runge-Kutta de orden 4
"""
import numpy as np


def euler(f, x0, y0, xf, h):
    """
    Método de Euler para dy/dx = f(x, y).

    Parámetros:
        f  : función f(x, y)
        x0 : valor inicial de x
        y0 : valor inicial de y
        xf : valor final de x
        h  : tamaño de paso
    """
    xs = [x0]
    ys = [y0]
    tabla = [[0, x0, y0, f(x0, y0), "—"]]

    procedimiento = []
    procedimiento.append("=" * 60)
    procedimiento.append("MÉTODO DE EULER")
    procedimiento.append("=" * 60)
    procedimiento.append(f"\nFórmula: y_{{n+1}} = y_n + h · f(x_n, y_n)")
    procedimiento.append(f"\nCondición inicial: y({x0}) = {y0}")
    procedimiento.append(f"Intervalo: [{x0}, {xf}],  h = {h}")
    procedimiento.append(f"Pasos: {int(round((xf-x0)/h))}\n")
    procedimiento.append("-" * 60)

    n = 0
    x, y = x0, y0

    while x < xf - 1e-10:
        k = f(x, y)
        y_new = y + h * k
        x_new = x + h

        procedimiento.append(
            f"\n▶ Paso {n+1}:  x_{n} = {x:.6g},  y_{n} = {y:.8g}"
        )
        procedimiento.append(
            f"   f(x_{n}, y_{n}) = f({x:.6g}, {y:.6g}) = {k:.8g}"
        )
        procedimiento.append(
            f"   y_{n+1} = {y:.8g} + {h} · {k:.8g} = {y_new:.8g}"
        )
        procedimiento.append(f"   x_{n+1} = {x:.6g} + {h} = {x_new:.6g}")

        x, y = x_new, y_new
        n += 1
        xs.append(x)
        ys.append(y)
        tabla.append([n, x, y, f(x, y), h])

    procedimiento.append(f"\n{'='*60}")
    procedimiento.append(f"RESULTADO FINAL: y({xf}) ≈ {ys[-1]:.10g}")
    procedimiento.append("=" * 60)

    headers = ["n", "x_n", "y_n", "f(x_n,y_n)", "h"]

    return {
        "xs": np.array(xs),
        "ys": np.array(ys),
        "resultado": ys[-1],
        "tabla_headers": headers,
        "tabla": tabla,
        "procedimiento": "\n".join(procedimiento),
    }


def runge_kutta4(f, x0, y0, xf, h):
    """
    Método de Runge-Kutta de orden 4 (RK4).

    Parámetros iguales que euler().
    """
    xs = [x0]
    ys = [y0]
    tabla = [[0, x0, y0, "—", "—", "—", "—"]]

    procedimiento = []
    procedimiento.append("=" * 60)
    procedimiento.append("MÉTODO DE RUNGE-KUTTA ORDEN 4 (RK4)")
    procedimiento.append("=" * 60)
    procedimiento.append(f"\nFórmulas:")
    procedimiento.append(f"   k₁ = h · f(x_n, y_n)")
    procedimiento.append(f"   k₂ = h · f(x_n + h/2, y_n + k₁/2)")
    procedimiento.append(f"   k₃ = h · f(x_n + h/2, y_n + k₂/2)")
    procedimiento.append(f"   k₄ = h · f(x_n + h, y_n + k₃)")
    procedimiento.append(f"   y_{{n+1}} = y_n + (1/6)(k₁ + 2k₂ + 2k₃ + k₄)")
    procedimiento.append(f"\nCondición inicial: y({x0}) = {y0}")
    procedimiento.append(f"Intervalo: [{x0}, {xf}],  h = {h}\n")
    procedimiento.append("-" * 60)

    n = 0
    x, y = x0, y0

    while x < xf - 1e-10:
        k1 = h * f(x,           y)
        k2 = h * f(x + h / 2,   y + k1 / 2)
        k3 = h * f(x + h / 2,   y + k2 / 2)
        k4 = h * f(x + h,        y + k3)

        y_new = y + (k1 + 2 * k2 + 2 * k3 + k4) / 6
        x_new = x + h

        procedimiento.append(
            f"\n▶ Paso {n+1}: x_{n} = {x:.6g},  y_{n} = {y:.8g}"
        )
        procedimiento.append(f"   k₁ = {h}·f({x:.4g}, {y:.4g}) = {k1:.8g}")
        procedimiento.append(
            f"   k₂ = {h}·f({x+h/2:.4g}, {y+k1/2:.4g}) = {k2:.8g}"
        )
        procedimiento.append(
            f"   k₃ = {h}·f({x+h/2:.4g}, {y+k2/2:.4g}) = {k3:.8g}"
        )
        procedimiento.append(
            f"   k₄ = {h}·f({x+h:.4g}, {y+k3:.4g}) = {k4:.8g}"
        )
        procedimiento.append(
            f"   y_{n+1} = {y:.8g} + (1/6)·({k1:.4g} + 2·{k2:.4g} + 2·{k3:.4g} + {k4:.4g})"
        )
        procedimiento.append(f"   y_{n+1} = {y_new:.8g}")

        x, y = x_new, y_new
        n += 1
        xs.append(x)
        ys.append(y)
        tabla.append([n, x, y, k1, k2, k3, k4])

    procedimiento.append(f"\n{'='*60}")
    procedimiento.append(f"RESULTADO FINAL: y({xf}) ≈ {ys[-1]:.10g}")
    procedimiento.append("=" * 60)

    headers = ["n", "x_n", "y_n", "k₁", "k₂", "k₃", "k₄"]

    return {
        "xs": np.array(xs),
        "ys": np.array(ys),
        "resultado": ys[-1],
        "tabla_headers": headers,
        "tabla": tabla,
        "procedimiento": "\n".join(procedimiento),
    }
